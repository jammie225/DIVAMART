# DIVAMART — Full-stack online store

Perfumes, fragrances, cosmetics, face creams, body oils, clothing, groceries and household needs.
**14/16 Brass Street** · Nationwide delivery · **24 hours within Abia State**, **3–5 days** elsewhere.

| Part | Language | Folder | What it does |
|---|---|---|---|
| Database | **SQL** (PostgreSQL) | `database/` | Tables, indexes for 100,000+ customers, starting products |
| Backend API | **Python** (FastAPI) | `backend/` | Accounts, products, orders, payments, admin, support, chatbot |
| Website + Admin | **JavaScript / React** | `web/` | The shop with animations, cart, checkout, and the admin dashboard |
| Mobile app | **Dart** (Flutter) | `mobile/` | Android/iPhone shopping app using the same API |

### Where AI is used (and where it isn't)
Everything is ordinary, rule-based code **except the customer-care chatbot**:

- Prices, totals, delivery times, stock, orders, payments, logins, admin: **plain code, no AI**. Prices are
  always read from the database, never trusted from the phone or browser.
- **Chatbot** (`backend/app/services/assistant.py`): if you add an Anthropic API key, it asks Claude. Before each
  reply it gives Claude the real store facts: delivery rules, address, WhatsApp, the matching products with
  live prices and stock, and the signed-in customer's recent orders. That way it doesn't guess.
  With **no key**, or if the AI service is down, it answers from built-in rules instead, so the chat never breaks.
  Every chat is saved and visible to staff under **Admin → Chat logs**.

---

## 1. Quick start (Docker — easiest)

You need [Docker Desktop](https://www.docker.com/products/docker-desktop/).

```bash
cp backend/.env.example backend/.env      # then open backend/.env and set JWT_SECRET
docker compose up --build
```

- Shop: **http://localhost:8080**
- Admin: **http://localhost:8080/admin** (the first visit asks you to create the **owner** account)
- API documentation: **http://localhost:8000/docs**

The database is created automatically from `database/schema.sql` and filled from `database/seed.sql`.

## 2. Running without Docker (for development)

**Database:** install PostgreSQL 14+, then:
```bash
createdb divamart
psql -d divamart -f database/schema.sql
psql -d divamart -f database/seed.sql
```

**Backend (Python 3.11+):**
```bash
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
cp .env.example .env                                    # set DATABASE_URL and JWT_SECRET
uvicorn app.main:app --reload --port 8000
pytest -q                                               # runs the automatic tests
```

**Website (Node 18+):**
```bash
cd web
npm install
npm run dev        # http://localhost:5173  (forwards /api to the backend on port 8000)
```

**Mobile app (Flutter 3.22+):**
```bash
cd mobile
flutter create --platforms=android,ios .     # generates the android/ and ios/ folders once
flutter pub get
flutter run --dart-define=API_URL=http://10.0.2.2:8000      # Android emulator talking to your PC
```
For Android, add the internet permission shown in `mobile/android_snippets/AndroidManifest_additions.xml`.
For a real phone or the Play Store build, point it at your live server:
`flutter build apk --dart-define=API_URL=https://yourdomain.ng`

---

## 3. First things to do as the owner

1. Open **/admin** and create the owner account (strong password: 8+ characters, letters and numbers).
2. **Store settings:** put in your real **WhatsApp number** (e.g. `2348012345678`), the shown number,
   bank transfer details, delivery fees (leave 0 if your team confirms them), the deal of the week,
   and upload a **hero image**.
3. **Products:** tap **Edit** on each product, then **Upload photo**, and set the real name, price and description.
   Use **+ Add product** for new items, the **In stock** switch for sold-out items, and **Visible** to hide one.
4. **Staff & admins:** add staff accounts. Staff can manage products and orders, but only owners can change
   settings or add admins.

## 4. Features

**Shop (web + mobile):** animated hero section, a section for each product category, search, product quick view,
cart with a fly-to-cart animation, sign-up and log-in with email, checkout with a delivery-time estimate per state,
pay on delivery / bank transfer / card (Paystack), order tracking (Received → Confirmed → Dispatched → Delivered),
WhatsApp ordering for any product or the whole cart, newsletter, FAQ, support tickets, and the AI customer-care chat.

**Admin dashboard (`/admin`):** products with photo upload, orders with status and payment updates, customers
(search, filter by state, CSV export), support tickets, chat logs, newsletter subscribers, store settings,
staff accounts and password change.

**Security:**
- Customer and admin passwords are hashed with bcrypt, never stored as plain text.
- Customer and admin sign-in tokens are separate, so a customer token can never open the admin API.
- An admin account locks for 5 minutes after 5 wrong passwords.
- Admin sessions end after 8 hours, or after 30 minutes with no activity.
- Paystack webhooks are checked with HMAC signatures.
- Uploaded images are checked, resized and re-saved as JPEG.
- The chat is limited to 20 messages per minute per user, to stop abuse.

## 5. Built for 100,000+ customers

- Every search and list the admin uses has a database index, including fast "contains" search on name, email
  and phone (`pg_trgm`).
- Admin lists load 50 rows at a time, so they never pull every customer at once. CSV export streams in batches.
- **Tested:** with 100,000 customers loaded into PostgreSQL, one page of the customer list loaded in about
  60–120 ms, and a name or email search took about 5–15 ms.
- PostgreSQL itself can hold millions of rows. For heavy traffic, run more API copies behind the same database
  (for example `uvicorn --workers 4`).

## 6. Going live checklist

- [ ] A long random `JWT_SECRET` in `backend/.env` (`python -c "import secrets;print(secrets.token_urlsafe(48))"`)
- [ ] A strong `DB_PASSWORD` (in a `.env` file next to `docker-compose.yml`)
- [ ] Your domain with **HTTPS** (e.g. Caddy or Cloudflare in front of port 8080), and `CORS_ORIGINS` set to it
- [ ] **Paystack:** put the live secret key in `PAYSTACK_SECRET_KEY`, and set `PAYSTACK_CALLBACK_URL=https://yourdomain/payment/callback`.
      In the Paystack dashboard, set the webhook URL to `https://yourdomain/api/payments/paystack/webhook`.
- [ ] **AI chatbot:** put a key from console.anthropic.com in `ANTHROPIC_API_KEY` (optional; without it the chat uses built-in answers)
- [ ] Daily database backups (`pg_dump`), plus a backup of the `uploads` volume
- [ ] Replace the sample products and prices with your real stock

## 7. Project layout

```
database/   schema.sql (tables + indexes) · seed.sql (categories, sample products, settings)
backend/    app/main.py · models.py · schemas.py · security.py
            routers/shop.py (public API) · routers/admin.py (admin API)
            services/assistant.py (AI chatbot) · paystack.py · images.py · store.py
            tests/test_api.py
web/        src/Shop.jsx · components/ (sections, cart, checkout, chat) · admin/ (dashboard)
mobile/     lib/main.dart · state.dart · api.dart · screens/ · widgets/
```
