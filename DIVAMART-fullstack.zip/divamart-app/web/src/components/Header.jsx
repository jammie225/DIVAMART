import { useEffect, useState } from "react";
import { useShop } from "../lib/ShopContext.jsx";
import { BagIcon, CartIcon, MenuIcon, SearchIcon } from "./Icons.jsx";

export function AnnouncementBar() {
  const { info } = useShop();
  const home = info?.home_state || "Abia";
  const items = [
    <>🚚 <b>Nationwide delivery</b> — anywhere in Nigeria</>,
    <>⚡ <b>24-hour delivery</b> within {home} State</>,
    <>📦 Outside {home}: <b>3–5 days</b></>,
    <>💬 Order easily on <b>WhatsApp</b></>,
    info && <>✨ {info.deal_line1.replace(/\s*[-—]\s*$/, "")}: <b>{info.deal_line2}</b> {info.deal_line3}</>,
  ].filter(Boolean);
  return (
    <div className="strip"><div className="track">
      {[...items, ...items].map((x, i) => <span key={i}>{x}</span>)}
    </div></div>
  );
}

export default function Header({ search, setSearch }) {
  const { customer, cartCount, setOverlay, requireAuth } = useShop();
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const f = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);
  return (
    <header className={`nav ${scrolled ? "scrolled" : ""}`}>
      <div className="wrap">
        <a href="#top" className="brand"><span className="dot" />DIVAMART</a>
        <nav className="links">
          <a href="#shop">Shop</a><a href="#deals">Deals</a><a href="#delivery">Delivery</a><a href="#support">Support</a>
        </nav>
        <div className="spacer" />
        <label className="searchbox">
          <SearchIcon /><span className="sr">Search products</span>
          <input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search perfumes, creams, rice…" />
        </label>
        <button className="iconbtn" title="My orders" aria-label="My orders" onClick={() => requireAuth(() => setOverlay("orders"))}><BagIcon /></button>
        <button className="iconbtn" id="cartBtn" title="Cart" aria-label="Cart" onClick={() => setOverlay("cart")}>
          <CartIcon /><span className={`badge ${cartCount ? "on" : ""}`}>{cartCount}</span>
        </button>
        <button className="userchip" onClick={() => setOverlay(customer ? "account" : "auth")}>
          <span className="avatar">{customer ? customer.full_name.trim()[0].toUpperCase() : "?"}</span>
          <span className="nm">{customer ? customer.full_name.split(" ")[0] : "Sign in"}</span>
        </button>
        <button className="iconbtn burger" aria-label="Menu" onClick={() => setOverlay("menu")}><MenuIcon /></button>
      </div>
    </header>
  );
}
