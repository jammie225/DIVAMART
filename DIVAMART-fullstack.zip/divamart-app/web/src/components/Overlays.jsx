import { useEffect, useState } from "react";
import { api, naira, PAY_LABEL, STEPS, waLink } from "../lib/api.js";
import { catStyle } from "../lib/art.js";
import { confetti, ripple } from "../lib/hooks.js";
import { useShop } from "../lib/ShopContext.jsx";
import { WaIcon } from "./Icons.jsx";
import { ProductImage } from "./ProductCard.jsx";

export function Modal({ open, onClose, title, wide, children }) {
  useEffect(() => {
    if (!open) return;
    const k = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", k);
    return () => document.removeEventListener("keydown", k);
  }, [open, onClose]);
  return (
    <div className={`modal ${open ? "on" : ""}`} onClick={(e) => e.target === e.currentTarget && onClose()} aria-hidden={!open}>
      <div className={`mbox ${wide ? "wide" : ""}`} role="dialog" aria-modal="true" aria-label={title}>
        <div className="mhead"><h3>{title}</h3><button className="iconbtn" onClick={onClose} aria-label="Close">✕</button></div>
        <div className="mbody">{open && children}</div>
      </div>
    </div>
  );
}

function OrderCard({ o }) {
  const idx = o.status === "cancelled" ? -1 : STEPS.indexOf(o.status);
  return (
    <div className="order">
      <div className="top">
        <div><b>{o.order_number}</b><div style={{ color: "var(--muted)", fontSize: 12 }}>{new Date(o.created_at).toLocaleString("en-NG")}</div></div>
        <div style={{ textAlign: "right" }}><b>{naira(o.total)}</b><div><span className="status">{o.status}</span> <span className="status" style={{ background: o.payment_status === "paid" ? "#E3F5EA" : undefined, color: o.payment_status === "paid" ? "var(--ok)" : undefined }}>{o.payment_status}</span></div></div>
      </div>
      {o.status === "cancelled" ? <p style={{ color: "var(--red)", fontWeight: 700, margin: "10px 0" }}>This order was cancelled.</p> :
        <div className="steps">{STEPS.map((s, i) => <div key={s} className={i <= idx ? "done" : ""}>{s[0].toUpperCase() + s.slice(1)}</div>)}</div>}
      <div style={{ fontSize: 13, color: "var(--muted)", marginTop: 8 }}>
        {o.items.map((i) => `${i.quantity} × ${i.product_name}`).join(" · ")}<br />
        📍 {o.address}, {o.city}, {o.state} · {PAY_LABEL[o.payment_method]} · 🚚 Delivery {o.delivery_estimate}
      </div>
    </div>
  );
}

export default function Overlays() {
  const shop = useShop();
  const { overlay, setOverlay, toasts } = shop;
  const close = () => setOverlay(null);
  const is = (k) => overlay === k;
  const drawerOpen = is("cart") || is("menu");
  useEffect(() => { document.body.style.overflow = overlay ? "hidden" : ""; }, [overlay]);
  return (
    <>
      <div className={`scrim ${drawerOpen ? "on" : ""}`} onClick={close} />
      <CartDrawer open={is("cart")} />
      <div className={`mmenu ${is("menu") ? "on" : ""}`}>
        <button className="iconbtn" style={{ alignSelf: "flex-end" }} onClick={close} aria-label="Close">✕</button>
        {[["#shop", "Shop"], ["#deals", "Deals"], ["#delivery", "Delivery"], ["#newsletter", "Newsletter"], ["#support", "Support"]].map(([h, l], i) =>
          <a key={h} href={h} onClick={close} style={{ transitionDelay: `${0.08 + i * 0.06}s` }}>{l}</a>)}
      </div>
      <Modal open={is("auth")} onClose={close} title="Welcome"><AuthForm /></Modal>
      <Modal open={is("account")} onClose={close} title="My account"><Account /></Modal>
      <Modal open={is("checkout")} onClose={close} title="Checkout"><Checkout /></Modal>
      <Modal open={is("orders")} onClose={close} title="My orders"><MyOrders /></Modal>
      <Modal open={!!overlay?.product} onClose={close} title={overlay?.product?.name || ""}><QuickView p={overlay?.product} /></Modal>
      <div id="toasts">{toasts.map((t) => <div key={t.id} className="toast">{t.msg}</div>)}</div>
    </>
  );
}

function CartDrawer({ open }) {
  const { info, cartLines, cartCount, cartTotal, setQty, setOverlay, requireAuth } = useShop();
  const waText = () => `Hello ${info?.store_name}, I'd like to order:\n` +
    cartLines.map(({ p, q }) => `• ${q} × ${p.name} — ${naira(p.price * q)}`).join("\n") + `\nTotal: ${naira(cartTotal)}`;
  return (
    <aside className={`drawer ${open ? "on" : ""}`} aria-label="Shopping cart">
      <div className="dhead"><h3>Your cart</h3><button className="iconbtn" onClick={() => setOverlay(null)} aria-label="Close">✕</button></div>
      <div className="dbody">
        {!cartLines.length ? (
          <div style={{ textAlign: "center", padding: "60px 10px", color: "var(--muted)" }}><div style={{ fontSize: 54 }}>🛍️</div>
            <h3 style={{ color: "var(--ink)", margin: "10px 0 6px" }}>Your cart is empty</h3><p>Browse our categories and add something lovely.</p></div>
        ) : cartLines.map(({ p, q }) => (
          <div className="line" key={p.id}>
            <div className="thumb" style={{ background: catStyle(p.category).bg }}><ProductImage p={p} /></div>
            <div><b>{p.name}</b><small>{naira(p.price)} each</small>
              <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                <div className="qty"><button onClick={() => setQty(p.id, q - 1)} aria-label="Decrease">−</button><span>{q}</span><button onClick={() => setQty(p.id, q + 1)} aria-label="Increase">+</button></div>
                <button className="rm" onClick={() => setQty(p.id, 0)}>Remove</button></div></div>
            <b>{naira(p.price * q)}</b>
          </div>
        ))}
      </div>
      <div className="dfoot">
        {cartLines.length ? <>
          <div className="sum"><span>Subtotal ({cartCount} items)</span><b>{naira(cartTotal)}</b></div>
          <div className="sum"><span>Delivery</span><span>Calculated at checkout</span></div>
          <div style={{ display: "grid", gap: 8, marginTop: 12 }}>
            <button className="btn btn-red btn-block" onPointerDown={ripple} onClick={() => requireAuth(() => setOverlay("checkout"))}>Checkout securely</button>
            {info && <a className="btn btn-wa btn-block" target="_blank" rel="noopener noreferrer" href={waLink(info.whatsapp, waText())}><WaIcon size={18} /> Order cart via WhatsApp</a>}
          </div>
        </> : <a href="#shop" className="btn btn-red btn-block" onClick={() => setOverlay(null)}>Continue shopping</a>}
      </div>
    </aside>
  );
}

function AuthForm() {
  const { signup, login, toast } = useShop();
  const [tab, setTab] = useState("signup");
  const [f, setF] = useState({ full_name: "", email: "", phone: "", password: "", newsletter: true });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setErr(""); setBusy(true);
    try {
      if (tab === "signup") { await signup(f); toast(`Welcome to DIVAMART, ${f.full_name.split(" ")[0]}! 🎉`); }
      else { await login({ email: f.email, password: f.password }); toast("Welcome back!"); }
    } catch (e2) { setErr(e2.message); } finally { setBusy(false); }
  };
  return (
    <>
      <div className="tabs">{[["signup", "Sign up"], ["login", "Log in"]].map(([k, l]) => <button key={k} className={tab === k ? "on" : ""} onClick={() => { setTab(k); setErr(""); }}>{l}</button>)}</div>
      <form onSubmit={submit}>
        {tab === "signup" && <div className="field"><label htmlFor="aName">Full name</label><input id="aName" required minLength={2} autoComplete="name" value={f.full_name} onChange={set("full_name")} /></div>}
        <div className="field"><label htmlFor="aEmail">Email</label><input id="aEmail" type="email" required autoComplete="email" value={f.email} onChange={set("email")} /></div>
        {tab === "signup" && <div className="field"><label htmlFor="aPhone">Phone number</label><input id="aPhone" type="tel" required placeholder="080…" autoComplete="tel" value={f.phone} onChange={set("phone")} /></div>}
        <div className="field"><label htmlFor="aPass">Password</label><input id="aPass" type="password" required minLength={6} autoComplete={tab === "signup" ? "new-password" : "current-password"} value={f.password} onChange={set("password")} /></div>
        {tab === "signup" && <label style={{ display: "flex", gap: 8, alignItems: "center", fontSize: 13, marginBottom: 12 }}><input type="checkbox" checked={f.newsletter} onChange={set("newsletter")} style={{ accentColor: "var(--red)" }} /> Send me deals and new arrivals</label>}
        <div className="err">{err}</div>
        <button className="btn btn-red btn-block" disabled={busy} onPointerDown={ripple}>{busy ? "Please wait…" : tab === "signup" ? "Create account" : "Log in"}</button>
      </form>
    </>
  );
}

function Account() {
  const { customer, logout, setOverlay } = useShop();
  if (!customer) return null;
  return (
    <>
      <div style={{ display: "flex", gap: 14, alignItems: "center", marginBottom: 18 }}>
        <div className="avatar" style={{ width: 56, height: 56, fontSize: 22 }}>{customer.full_name[0].toUpperCase()}</div>
        <div><b style={{ fontSize: 18 }}>{customer.full_name}</b><div style={{ color: "var(--muted)", fontSize: 14 }}>{customer.email} · {customer.phone}</div></div>
      </div>
      <div style={{ display: "grid", gap: 8 }}>
        <button className="btn btn-red btn-block" onClick={() => setOverlay("orders")}>View my orders</button>
        <button className="btn btn-block" style={{ border: "1px solid var(--line)" }} onClick={logout}>Sign out</button>
      </div>
    </>
  );
}

function Checkout() {
  const { info, customer, token, cartLines, cartTotal, clearCart, setOverlay, toast, reload } = useShop();
  const [f, setF] = useState({ full_name: customer?.full_name || "", phone: customer?.phone || "", state: customer?.state || "",
    city: customer?.city || "", address: customer?.address || "", note: "", payment_method: "pod" });
  const [est, setEst] = useState(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(null);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  useEffect(() => {
    if (!f.state) { setEst(null); return; }
    api.get(`/api/delivery-estimate?state=${encodeURIComponent(f.state)}`).then(setEst).catch(() => setEst(null));
  }, [f.state]);

  const submit = async (e) => {
    e.preventDefault(); setErr(""); setBusy(true);
    try {
      const order = await api.post("/api/orders", { ...f, items: cartLines.map(({ p, q }) => ({ product_id: p.id, quantity: q })) }, { token });
      clearCart();
      if (f.payment_method === "card") {
        const pay = await api.post(`/api/payments/paystack/${order.order_number}`, {}, { token });
        window.location.href = pay.authorization_url;   // Paystack's secure page, then back to /payment/callback
        return;
      }
      setDone(order); confetti();
    } catch (e2) { setErr(e2.message); if (e2.status === 400) reload(); } finally { setBusy(false); }
  };

  if (done) {
    const msg = `Hello ${info.store_name}, I just placed order ${done.order_number}.\n` + done.items.map((i) => `• ${i.quantity} × ${i.product_name}`).join("\n") +
      `\nTotal: ${naira(done.total)}\nPayment: ${PAY_LABEL[done.payment_method]}\nDeliver to: ${done.address}, ${done.city}, ${done.state}\nName: ${done.full_name} (${done.phone})`;
    return (
      <div className="success">
        <svg className="check" viewBox="0 0 90 90"><circle cx="45" cy="45" r="40" fill="none" stroke="var(--red)" strokeWidth="5" /><path d="M27 46l12 12 25-25" fill="none" stroke="var(--red)" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" /></svg>
        <h3 style={{ fontSize: 26 }}>Order placed!</h3>
        <p style={{ color: "var(--muted)", margin: "8px 0 4px" }}>Order number</p>
        <p style={{ fontFamily: "Fraunces", fontSize: 24, color: "var(--red)", fontWeight: 800 }}>{done.order_number}</p>
        <div className="eta" style={{ justifyContent: "center", margin: "16px 0" }}>🚚 Delivery {done.delivery_estimate} to {done.state}</div>
        {done.payment_method === "transfer" && info.bank_details && <div className="panel" style={{ textAlign: "left", marginBottom: 14, whiteSpace: "pre-line" }}><b>Bank transfer details</b><br />{info.bank_details}<br /><small>Use {done.order_number} as the payment reference.</small></div>}
        <div style={{ display: "grid", gap: 8 }}>
          <a className="btn btn-wa btn-block" target="_blank" rel="noopener noreferrer" href={waLink(info.whatsapp, msg)}><WaIcon size={18} /> Send order on WhatsApp</a>
          <button className="btn btn-block" style={{ border: "1px solid var(--line)" }} onClick={() => setOverlay("orders")}>Track my orders</button>
        </div>
      </div>
    );
  }
  if (!cartLines.length) return <div className="empty">Your cart is empty.</div>;
  const fee = est?.fee || 0;
  return (
    <form onSubmit={submit}>
      <div className="row2"><div className="field"><label htmlFor="cName">Full name</label><input id="cName" required minLength={2} value={f.full_name} onChange={set("full_name")} /></div>
        <div className="field"><label htmlFor="cPhone">Phone</label><input id="cPhone" type="tel" required minLength={10} value={f.phone} onChange={set("phone")} /></div></div>
      <div className="row2"><div className="field"><label htmlFor="cState">State</label><select id="cState" required value={f.state} onChange={set("state")}><option value="">Select…</option>{info?.states.map((s) => <option key={s}>{s}</option>)}</select></div>
        <div className="field"><label htmlFor="cCity">City / Town</label><input id="cCity" required minLength={2} value={f.city} onChange={set("city")} /></div></div>
      <div className="field"><label htmlFor="cAddr">Delivery address</label><input id="cAddr" required minLength={5} placeholder="House number, street, landmark" value={f.address} onChange={set("address")} /></div>
      <div className="eta">🚚 {est ? `Delivery ${est.estimate} to ${f.state}` : "Choose your state to see delivery time"}</div>
      <div className="field"><label>Payment method</label><div className="paym">
        {[["pod", "Pay on delivery", "Cash or transfer when your order arrives"], ["transfer", "Bank transfer", "Account details shown after you order"],
          ...(info?.card_payments ? [["card", "Card payment", "Pay securely with Paystack"]] : [])].map(([v, t, s]) => (
          <label key={v}><input type="radio" name="pay" value={v} checked={f.payment_method === v} onChange={set("payment_method")} /><div><b>{t}</b><small>{s}</small></div></label>))}
      </div></div>
      <div className="field"><label htmlFor="cNote">Order note (optional)</label><input id="cNote" maxLength={500} placeholder="Size, colour, preferred delivery time…" value={f.note} onChange={set("note")} /></div>
      <div style={{ borderTop: "1px solid var(--line)", paddingTop: 12, marginTop: 6 }}>
        {cartLines.map(({ p, q }) => <div className="sum" key={p.id}><span>{q} × {p.name}</span><span>{naira(p.price * q)}</span></div>)}
        <div className="sum"><span>Delivery fee</span><span>{fee ? naira(fee) : "Confirmed by our team"}</span></div>
        <div className="sum t"><span>Total</span><span>{naira(cartTotal + fee)}</span></div>
      </div>
      <div className="err" style={{ marginTop: 10 }}>{err}</div>
      <button className="btn btn-red btn-block" disabled={busy} onPointerDown={ripple}>{busy ? "Placing order…" : f.payment_method === "card" ? "Continue to payment" : "Place order"}</button>
    </form>
  );
}

function MyOrders() {
  const { token } = useShop();
  const [orders, setOrders] = useState(null);
  const [err, setErr] = useState("");
  useEffect(() => { api.get("/api/orders/mine", { token }).then(setOrders).catch((e) => setErr(e.message)); }, [token]);
  if (err) return <div className="err">{err}</div>;
  if (!orders) return <p>Loading…</p>;
  return orders.length ? orders.map((o) => <OrderCard key={o.order_number} o={o} />) : <div className="empty">You haven't placed any orders yet.</div>;
}

function QuickView({ p }) {
  const { info, addToCart } = useShop();
  if (!p) return null;
  return (
    <>
      <div style={{ background: catStyle(p.category).bg, borderRadius: 18, aspectRatio: "16/10", display: "grid", placeItems: "center", marginBottom: 16, overflow: "hidden" }}>
        <div className={p.image_url ? "qv-photo" : "qv-art"}><ProductImage p={p} /></div>
      </div>
      <span className="kicker">{p.category_name}</span>
      <p style={{ margin: "8px 0 14px", lineHeight: 1.6, color: "var(--muted)" }}>{p.description}</p>
      <div className="price" style={{ padding: "0 0 16px" }}><b style={{ fontSize: 26 }}>{naira(p.price)}</b>{p.old_price && <s>{naira(p.old_price)}</s>}</div>
      <div className="eta">🚚 24hrs within {info?.home_state} · 3–5 days nationwide</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        {p.in_stock ? <button className="btn btn-red" onPointerDown={ripple} onClick={() => addToCart(p.id)}>Add to cart</button> : <button className="btn oosbtn" disabled>Out of stock</button>}
        {info && <a className="btn btn-wa" target="_blank" rel="noopener noreferrer" href={waLink(info.whatsapp, `Hello ${info.store_name}, I'd like to order: ${p.name} (${naira(p.price)})`)}>WhatsApp order</a>}
      </div>
    </>
  );
}
