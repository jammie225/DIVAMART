import { Fragment, useEffect, useRef, useState } from "react";
import { api, imgUrl, waLink } from "../lib/api.js";
import { artSvg, catStyle, dealBottle, heroBottle, heroDrop, heroJar } from "../lib/art.js";
import { confetti, ripple, useCountdown, useReveal } from "../lib/hooks.js";
import { useShop } from "../lib/ShopContext.jsx";
import { ArrowIcon, WaIcon } from "./Icons.jsx";
import ProductCard from "./ProductCard.jsx";

const Svg = ({ html, style }) => <span style={{ display: "block", ...style }} dangerouslySetInnerHTML={{ __html: html }} />;

function Counter({ to }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    const t0 = performance.now(); let raf;
    const step = (t) => { const p = Math.min(1, (t - t0) / 1400); setN(Math.round(to * (1 - Math.pow(1 - p, 3)))); if (p < 1) raf = requestAnimationFrame(step); };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [to]);
  return <b>{n}</b>;
}

export function Hero() {
  const { info, categories } = useShop();
  const stage = useRef(null);
  useEffect(() => {
    const move = (e) => {
      if (!stage.current || window.scrollY > innerHeight) return;
      const x = e.clientX / innerWidth - 0.5, y = e.clientY / innerHeight - 0.5;
      stage.current.querySelectorAll(".float").forEach((f) => {
        const d = +f.dataset.depth, base = f.classList.contains("f1") ? "translate(-50%,-55%) " : "";
        f.style.transform = `${base}translate(${x * d}px,${y * d}px)`;
      });
    };
    window.addEventListener("pointermove", move);
    return () => window.removeEventListener("pointermove", move);
  }, []);
  const words = [["Smell"], ["divine."], null, ["Look"], ["radiant.", true], null, ["Live"], ["easy."]];
  let wi = 0;
  return (
    <section className="hero" id="top">
      <div className="wrap">
        <div>
          <span className="eyebrow fade-up"><i /> Nationwide delivery · 24hrs within {info?.home_state || "Abia"}</span>
          <h1>{words.map((w, i) => w === null ? <br key={i} /> : (
            <Fragment key={i}><span className="w"><span style={{ transitionDelay: `${0.1 + (wi++) * 0.09}s` }}>{w[1] ? <em>{w[0]}</em> : w[0]}</span></span>{" "}</Fragment>))}
          </h1>
          <p className="lead fade-up d1">Perfumes, fragrances, cosmetics, face creams, body oils, clothing, groceries and household needs — all in one store, delivered to your door anywhere in Nigeria.</p>
          <div className="ctas fade-up d2">
            <a href="#shop" className="btn btn-white" onPointerDown={ripple}>Start shopping <ArrowIcon /></a>
            {info && <a className="btn btn-ghost" target="_blank" rel="noopener noreferrer" onPointerDown={ripple}
              href={waLink(info.whatsapp, `Hello ${info.store_name}, I'd like to place an order.`)}><WaIcon size={18} /> Order on WhatsApp</a>}
          </div>
          <div className="stats fade-up d3">
            <div><Counter to={categories.length || 8} /><span>Product categories</span></div>
            <div><b>24<small style={{ fontSize: 18 }}>hrs</small></b><span>Delivery in {info?.home_state || "Abia"}</span></div>
            <div><Counter to={36} /><span>States + FCT covered</span></div>
          </div>
        </div>
        <div className="stage fade-up d2" ref={stage}>
          <div className="ring" /><div className="orb a" />
          <div className="float f1" data-depth="18"><div className="bob">
            {info?.hero_image ? <img className="hero-img" src={imgUrl(info.hero_image)} alt={info.store_name} /> : <Svg html={heroBottle()} style={{ width: 210 }} />}
          </div></div>
          {!info?.hero_image && <>
            <div className="float f2" data-depth="34"><div className="bob"><Svg html={heroJar()} style={{ width: 130 }} /></div></div>
            <div className="float f3" data-depth="26"><div className="bob"><Svg html={heroDrop()} style={{ width: 84 }} /></div></div>
          </>}
          <div className="tagcard t1"><div className="ic">🚚</div><div>Same-day dispatch<small>Within {info?.home_state || "Abia"} State</small></div></div>
          <div className="tagcard t2"><div className="ic">✨</div><div>Original products<small>Perfumes &amp; beauty</small></div></div>
        </div>
      </div>
      <svg className="wave" viewBox="0 0 1440 70" preserveAspectRatio="none"><path fill="#fff" d="M0 40c240 40 480 40 720 10s480-30 720 10v30H0z" /></svg>
    </section>
  );
}

export function CategoryRail() {
  const { categories } = useShop();
  const head = useReveal(), grid = useReveal();
  return (
    <section className="rail" id="shop">
      <div className="wrap">
        <div className="shead rv" ref={head}><div><div className="kicker">Shop by category</div><h2>Everything you need,<br />one trusted store.</h2></div></div>
        <div className="grid stagger" ref={grid}>
          {categories.map((c) => (
            <a key={c.slug} className="cat" href={`#cat-${c.slug}`}>
              <div className="ico" style={{ background: catStyle(c.slug).bg }}><Svg html={artSvg(c.slug, `c${c.id}`)} style={{ width: 40, height: 40 }} /></div>
              <b>{c.name}</b><small>{c.subtitle}</small>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

export function CategorySection({ cat, items }) {
  const { info } = useShop();
  const head = useReveal(), grid = useReveal();
  if (!items.length) return null;
  return (
    <section className="block catsec" id={`cat-${cat.slug}`}>
      <div className="wrap">
        <div className="shead rv" ref={head}>
          <div><div className="kicker">{cat.subtitle}</div><h2>{cat.name}</h2></div>
          {info && <a className="more" target="_blank" rel="noopener noreferrer"
            href={waLink(info.whatsapp, `Hello ${info.store_name}, what ${cat.name.toLowerCase()} do you have in stock?`)}>Ask about more {cat.name.toLowerCase()} →</a>}
        </div>
        <div className="pgrid stagger" ref={grid}>{items.map((p) => <ProductCard key={p.id} p={p} />)}</div>
      </div>
    </section>
  );
}

export function SearchResults({ query, onClear }) {
  const { info } = useShop();
  const [res, setRes] = useState(null);
  const box = useRef(null);
  useEffect(() => {
    let live = true;
    api.get(`/api/products?q=${encodeURIComponent(query)}&limit=60`).then((r) => live && setRes(r)).catch(() => live && setRes({ items: [], total: 0 }));
    box.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    return () => { live = false; };
  }, [query]);
  return (
    <section className="block" ref={box} style={{ paddingBottom: 20 }}>
      <div className="wrap">
        <div className="shead"><div><div className="kicker">Search</div><h2>{res ? `${res.total} result${res.total === 1 ? "" : "s"}` : "Searching…"} for “{query}”</h2></div>
          <button className="more" onClick={onClear}>Clear search ✕</button></div>
        {res && (res.items.length
          ? <div className="pgrid stagger in">{res.items.map((p) => <ProductCard key={p.id} p={p} />)}</div>
          : <div className="empty">No products found. {info && <a style={{ color: "var(--red)", fontWeight: 800 }} target="_blank" rel="noopener noreferrer" href={waLink(info.whatsapp, `Hello, do you have: ${query}?`)}>Ask us on WhatsApp</a>} — we may have it in store.</div>)}
      </div>
    </section>
  );
}

export function DealBanner() {
  const { info, categories } = useShop();
  const ref = useReveal();
  const [d, h, m, s] = useCountdown(info?.deal_ends);
  if (!info) return null;
  const cat = categories.find((c) => c.slug === info.deal_category);
  return (
    <section className="block" id="deals">
      <div className="wrap">
        <div className="deal rv" ref={ref}>
          <div style={{ position: "relative" }}>
            <div className="kicker" style={{ color: "var(--gold)" }}>Deal of the week</div>
            <h2>{info.deal_line1}<br /><em>{info.deal_line2}</em> {info.deal_line3}</h2>
            <div className="timer">{[[d, "Days"], [h, "Hrs"], [m, "Min"], [s, "Sec"]].map(([v, l]) => <div key={l}><b>{String(v).padStart(2, "0")}</b><small>{l}</small></div>)}</div>
            <a href={`#cat-${info.deal_category}`} className="btn btn-white" onPointerDown={ripple}>Shop {cat ? cat.name.toLowerCase() : "now"}</a>
          </div>
          <div style={{ position: "relative", display: "grid", placeItems: "center" }}>
            <div className="bob" style={{ animation: "bob 6s ease-in-out infinite" }}>
              {info.deal_image ? <img className="hero-img" style={{ width: "min(260px,60vw)", aspectRatio: 1 }} src={imgUrl(info.deal_image)} alt="" /> : <Svg html={dealBottle()} style={{ width: 200 }} />}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Delivery() {
  const { info } = useShop();
  const head = useReveal(), grid = useReveal(), check = useReveal();
  const [state, setState] = useState("");
  const [est, setEst] = useState(null);
  useEffect(() => {
    if (!state) { setEst(null); return; }
    api.get(`/api/delivery-estimate?state=${encodeURIComponent(state)}`).then(setEst).catch(() => setEst(null));
  }, [state]);
  const home = info?.home_state || "Abia";
  return (
    <section className="block" id="delivery" style={{ paddingTop: 20 }}>
      <div className="wrap">
        <div className="shead rv" ref={head}><div><div className="kicker">Delivery information</div><h2>We deliver nationwide.</h2></div>
          <p>Order today from anywhere in Nigeria. Within {home} State your order arrives in 24 hours; other states take 3–5 days.</p></div>
        <div className="dgrid stagger" ref={grid}>
          <div className="dcard hl"><div className="big">24h</div><h3>Within {home} State</h3><p>Every LGA in {home} — delivered within 24 hours of order confirmation.</p><div className="road"><i /></div></div>
          <div className="dcard"><div className="big">3–5</div><h3>Days outside {home}</h3><p>Lagos, Abuja, Port Harcourt, Enugu, Owerri, Kano and every other state.</p><div className="road"><i /></div></div>
          <div className="dcard"><div className="big">💬</div><h3>Track your order</h3><p>Every order gets an order number. Track it under “My orders” or ask us on WhatsApp.</p><div className="road"><i /></div></div>
        </div>
        <div className="checker rv" ref={check}>
          <b>Check your delivery time:</b>
          <select value={state} onChange={(e) => setState(e.target.value)} aria-label="Your state">
            <option value="">Select your state…</option>
            {info?.states.map((s) => <option key={s}>{s}</option>)}
          </select>
          {est && <span className="out" style={{ color: state === home ? "var(--ok)" : "var(--red)" }}>→ Delivery {est.estimate}</span>}
        </div>
        <div className="pays">
          <div className="pay">💵 Pay on delivery</div><div className="pay">🏦 Bank transfer</div>
          {info?.card_payments && <div className="pay">💳 Card (Paystack)</div>}<div className="pay">🔒 Secure checkout</div>
        </div>
      </div>
    </section>
  );
}

export function Newsletter() {
  const { toast } = useShop();
  const ref = useReveal();
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const bubbles = useRef(Array.from({ length: 14 }, () => ({ s: 10 + Math.random() * 50, l: Math.random() * 100, d: 6 + Math.random() * 8, dl: -Math.random() * 10 })));
  const submit = async (e) => {
    e.preventDefault(); setBusy(true);
    try {
      const r = await api.post("/api/newsletter", { email });
      toast(r.already ? "You're already subscribed 💌" : "Subscribed! Watch your inbox for deals 💌");
      if (!r.already) confetti();
      setEmail("");
    } catch (err) { toast(err.message); } finally { setBusy(false); }
  };
  return (
    <section className="block" id="newsletter" style={{ paddingTop: 10 }}>
      <div className="wrap">
        <div className="news rv" ref={ref}>
          <div className="bubbles">{bubbles.current.map((b, i) => <span key={i} style={{ left: `${b.l}%`, width: b.s, height: b.s, animationDuration: `${b.d}s`, animationDelay: `${b.dl}s` }} />)}</div>
          <div style={{ position: "relative" }}>
            <div className="kicker" style={{ color: "var(--gold)" }}>Newsletter</div>
            <h2>Be first to the deals.</h2>
            <p>New arrivals, weekly discounts and restock alerts — straight to your inbox. No spam, unsubscribe any time.</p>
            <form onSubmit={submit}>
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Your email address" aria-label="Email" />
              <button className="btn btn-red" disabled={busy} onPointerDown={ripple}>{busy ? "…" : "Subscribe"}</button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

const FAQ = [
  ["How long does delivery take?", (h) => `Within ${h} State, delivery is within 24 hours. Outside ${h}, delivery takes 3–5 days depending on your location.`],
  ["How do I pay?", () => "Pay on delivery, by bank transfer, or by card (Paystack). Our team confirms your order on WhatsApp or by phone."],
  ["Can I order on WhatsApp?", () => "Yes. Tap the WhatsApp button on any product, or send your whole cart to us on WhatsApp from the cart."],
  ["Are your perfumes and cosmetics original?", () => "We stock quality products from trusted suppliers. If anything arrives damaged or not as described, open a ticket and we'll make it right."],
  ["How do I track my order?", () => "Sign in and open “My orders” (the bag icon at the top) to see your order status, or message us with your order number."],
];

export function Support() {
  const { info, customer, token, toast } = useShop();
  const a = useReveal(), b = useReveal(), head = useReveal();
  const empty = { name: "", email: "", topic: "Order issue", order_number: "", message: "" };
  const [f, setF] = useState(empty);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (customer) setF((x) => ({ ...x, name: x.name || customer.full_name, email: x.email || customer.email })); }, [customer]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setBusy(true);
    try {
      const t = await api.post("/api/support/tickets", { ...f, order_number: f.order_number || null }, { token });
      toast(`Ticket ${t.ticket_number} received — we'll reply soon`);
      setF({ ...empty, name: f.name, email: f.email });
    } catch (err) { toast(err.message); } finally { setBusy(false); }
  };
  return (
    <section className="block" id="support" style={{ paddingTop: 10 }}>
      <div className="wrap">
        <div className="shead rv" ref={head}><div><div className="kicker">Customer support</div><h2>We're here to help.</h2></div><p>Find quick answers, open a support ticket, or chat with our assistant.</p></div>
        <div className="sgrid">
          <div className="faq rv" ref={a}>
            {FAQ.map(([q, ans], i) => <details key={q} open={i === 0}><summary>{q}</summary><p>{ans(info?.home_state || "Abia")}</p></details>)}
            {info && <div className="panel" style={{ marginTop: 16 }}>
              <div className="contactline"><div className="ic">📍</div><div><b>Visit our store</b><small>{info.address}</small></div></div>
              <div className="contactline"><div className="ic">💬</div><div><b>WhatsApp</b><small><a href={waLink(info.whatsapp, "Hello!")} target="_blank" rel="noopener noreferrer">{info.whatsapp_display}</a></small></div></div>
              <div className="contactline" style={{ border: 0 }}><div className="ic">🕘</div><div><b>Support hours</b><small>{info.support_hours}</small></div></div>
            </div>}
          </div>
          <div className="panel rv" ref={b}>
            <h3 style={{ fontSize: 24, marginBottom: 4 }}>Open a support ticket</h3>
            <p style={{ color: "var(--muted)", marginBottom: 18, fontSize: 14 }}>Tell us what's wrong and we'll get back to you.</p>
            <form onSubmit={submit}>
              <div className="row2"><div className="field"><label htmlFor="tName">Name</label><input id="tName" required value={f.name} onChange={set("name")} /></div>
                <div className="field"><label htmlFor="tEmail">Email</label><input id="tEmail" type="email" required value={f.email} onChange={set("email")} /></div></div>
              <div className="row2"><div className="field"><label htmlFor="tTopic">Topic</label><select id="tTopic" value={f.topic} onChange={set("topic")}>
                {["Order issue", "Delivery", "Payment", "Returns & refunds", "Product question", "Other"].map((t) => <option key={t}>{t}</option>)}</select></div>
                <div className="field"><label htmlFor="tOrder">Order no. (optional)</label><input id="tOrder" placeholder="DVM-…" value={f.order_number} onChange={set("order_number")} /></div></div>
              <div className="field"><label htmlFor="tMsg">Message</label><textarea id="tMsg" required minLength={5} value={f.message} onChange={set("message")} /></div>
              <button className="btn btn-red btn-block" disabled={busy} onPointerDown={ripple}>{busy ? "Sending…" : "Submit ticket"}</button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  const { info, categories, setOverlay, requireAuth } = useShop();
  return (
    <footer>
      <div className="wrap">
        <div className="grid">
          <div><a className="brand" href="#top"><span className="dot" />DIVAMART</a>
            <p style={{ color: "#bda6a8", lineHeight: 1.6, marginTop: 14, fontSize: 14, maxWidth: 320 }}>Perfumes, fragrances, cosmetics, clothing, face creams, body oils, groceries and household needs. We deliver nationwide.</p></div>
          <div><h4>Shop</h4>{categories.map((c) => <a key={c.slug} href={`#cat-${c.slug}`}>{c.name}</a>)}</div>
          <div><h4>Help</h4><a href="#delivery">Delivery information</a><a href="#support">FAQs</a><a href="#support">Support ticket</a>
            <a href="#top" onClick={(e) => { e.preventDefault(); requireAuth(() => setOverlay("orders")); }}>Track my order</a></div>
          <div><h4>Contact</h4>{info && <><li>📍 {info.address}</li><a href={waLink(info.whatsapp, "Hello!")} target="_blank" rel="noopener noreferrer">💬 {info.whatsapp_display}</a></>}
            <a href="/admin">🔒 Admin login</a></div>
        </div>
        <div className="legal"><span>© {new Date().getFullYear()} DIVAMART. All rights reserved.</span><span>Delivery within {info?.home_state || "Abia"}: 24hrs · Outside: 3–5 days</span></div>
      </div>
    </footer>
  );
}
