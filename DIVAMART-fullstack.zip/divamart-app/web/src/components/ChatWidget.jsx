import { useEffect, useRef, useState } from "react";
import { api, store, waLink } from "../lib/api.js";
import { useShop } from "../lib/ShopContext.jsx";
import { ArrowIcon, ChatIcon } from "./Icons.jsx";

// Customer-care chat. Answers come from the backend: AI (Claude) when configured, otherwise built-in rules.
const sessionId = (() => {
  let id = store.get("dvm_chat_session", null);
  if (!id) { id = "s" + Math.random().toString(36).slice(2) + Date.now().toString(36); store.set("dvm_chat_session", id); }
  return id;
})();

function linkify(text) {
  return text.split(/(https?:\/\/[^\s)]+)/g).map((part, i) =>
    /^https?:\/\//.test(part) ? <a key={i} href={part} target="_blank" rel="noopener noreferrer" style={{ color: "inherit", fontWeight: 800, textDecoration: "underline" }}>{part.includes("wa.me") ? "Open WhatsApp" : part}</a> : part);
}

export default function ChatWidget() {
  const { info, token } = useShop();
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState(() => store.get("dvm_chat", []));
  const [text, setText] = useState("");
  const [typing, setTyping] = useState(false);
  const box = useRef(null);

  useEffect(() => {
    if (open && !msgs.length && info) setMsgs([{ role: "assistant", content: `Hi there 👋 I'm the ${info.store_name} assistant. Ask me about products, delivery, payment or your order.` }]);
  }, [open, info]); // eslint-disable-line
  useEffect(() => { store.set("dvm_chat", msgs.slice(-30)); box.current && (box.current.scrollTop = 1e9); }, [msgs, typing]);

  const send = async (content) => {
    content = content.trim();
    if (!content || typing) return;
    const next = [...msgs, { role: "user", content }];
    setMsgs(next); setText(""); setTyping(true);
    try {
      const r = await api.post("/api/chat", { session_id: sessionId, messages: next.slice(-12) }, { token });
      setMsgs((m) => [...m, { role: "assistant", content: r.reply }]);
    } catch (e) {
      setMsgs((m) => [...m, { role: "assistant", content: `${e.message} You can also reach us on WhatsApp: ${info ? `https://wa.me/${info.whatsapp}` : ""}` }]);
    } finally { setTyping(false); }
  };

  return (
    <>
      <button className="chatfab" onClick={() => setOpen((o) => !o)} aria-label="Chat with customer care"><ChatIcon /></button>
      <div className={`chat ${open ? "on" : ""}`} role="dialog" aria-label="Customer care chat">
        <div className="ch">
          <div className="avatar" style={{ background: "#fff", color: "var(--red)" }}>D</div>
          <div><b>DIVAMART Customer Care</b><small><span className="online" />Usually replies instantly</small></div>
          <button className="iconbtn" style={{ marginLeft: "auto", color: "#fff" }} onClick={() => setOpen(false)} aria-label="Close chat">✕</button>
        </div>
        <div className="msgs" ref={box}>
          {msgs.map((m, i) => <div key={i} className={`msg ${m.role === "user" ? "me" : "bot"}`}>{linkify(m.content)}</div>)}
          {typing && <div className="msg bot"><span className="typing"><span /><span /><span /></span></div>}
        </div>
        <div className="quickrep">
          {["Delivery time", "Payment options", "Track my order", "Talk to a person"].map((q) => <button key={q} onClick={() => send(q)}>{q}</button>)}
          {info && <a href={waLink(info.whatsapp, "Hello, I need help.")} target="_blank" rel="noopener noreferrer"><button>WhatsApp</button></a>}
        </div>
        <form onSubmit={(e) => { e.preventDefault(); send(text); }}>
          <input value={text} onChange={(e) => setText(e.target.value)} maxLength={1500} placeholder="Type a message…" aria-label="Message" />
          <button type="submit" aria-label="Send" disabled={typing}><ArrowIcon /></button>
        </form>
      </div>
    </>
  );
}
