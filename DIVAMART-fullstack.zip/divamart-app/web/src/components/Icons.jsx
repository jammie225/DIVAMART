const S = { fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" };
export const SearchIcon = (p) => <svg width="18" height="18" viewBox="0 0 24 24" {...S} {...p}><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg>;
export const BagIcon = (p) => <svg width="22" height="22" viewBox="0 0 24 24" {...S} {...p}><path d="M3 7h18l-2 13H5L3 7Z" /><path d="M8 7a4 4 0 0 1 8 0" /></svg>;
export const CartIcon = (p) => <svg width="22" height="22" viewBox="0 0 24 24" {...S} {...p}><circle cx="9" cy="20" r="1.5" /><circle cx="18" cy="20" r="1.5" /><path d="M2 3h3l2.6 12.2a2 2 0 0 0 2 1.6h7.9a2 2 0 0 0 2-1.5L21 8H6" /></svg>;
export const MenuIcon = (p) => <svg width="22" height="22" viewBox="0 0 24 24" {...S} {...p}><path d="M4 7h16M4 12h16M4 17h10" /></svg>;
export const ArrowIcon = (p) => <svg width="18" height="18" viewBox="0 0 24 24" {...S} strokeWidth="2.4" {...p}><path d="M5 12h14M13 6l6 6-6 6" /></svg>;
export const EyeIcon = (p) => <svg width="18" height="18" viewBox="0 0 24 24" {...S} {...p}><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z" /><circle cx="12" cy="12" r="3" /></svg>;
export const ChatIcon = (p) => <svg width="26" height="26" viewBox="0 0 24 24" {...S} {...p}><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z" /></svg>;
export const WaIcon = ({ size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.1c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.6-4-4.7-4.2-.1-.2-1.1-1.5-1.1-2.8 0-1.4.7-2 1-2.3.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.4 0 .5l-.3.5-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.6-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z" /></svg>
);
