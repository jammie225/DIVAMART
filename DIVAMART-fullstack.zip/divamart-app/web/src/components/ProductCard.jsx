import { imgUrl, naira, waLink } from "../lib/api.js";
import { artSvg, catStyle } from "../lib/art.js";
import { flyToCart, ripple, useTilt } from "../lib/hooks.js";
import { useShop } from "../lib/ShopContext.jsx";
import { EyeIcon, WaIcon } from "./Icons.jsx";

export function ProductImage({ p, className = "" }) {
  return p.image_url
    ? <img className={`pimg ${className}`} src={imgUrl(p.image_url)} alt={p.name} loading="lazy" />
    : <span className="artwrap" dangerouslySetInnerHTML={{ __html: artSvg(p.category, `p${p.id}`) }} />;
}

export default function ProductCard({ p }) {
  const { info, addToCart, setOverlay } = useShop();
  const tilt = useTilt();
  const oos = !p.in_stock;
  return (
    <article className={`card ${oos ? "oos" : ""}`} ref={tilt}>
      <div className="art" style={{ background: catStyle(p.category).bg }}>
        {oos ? <span className="ptag new">Out of stock</span> : p.badge && <span className={`ptag ${p.badge === "New" ? "new" : ""}`}>{p.badge}</span>}
        <button className="quick" onClick={() => setOverlay({ product: p })} aria-label="Quick view"><EyeIcon /></button>
        <ProductImage p={p} />
      </div>
      <div className="body">
        <span className="cat-l">{p.category_name}</span>
        <h3>{p.name}</h3>
        <p className="desc">{p.description}</p>
        <div className="price"><b>{naira(p.price)}</b>{p.old_price && <s>{naira(p.old_price)}</s>}</div>
        <div className="acts">
          {oos
            ? <button className="btn oosbtn" disabled>Out of stock</button>
            : <button className="btn btn-red" onPointerDown={ripple} onClick={(e) => { flyToCart(e.currentTarget); addToCart(p.id); }}>Add to cart</button>}
          {info && (
            <a className="wa-mini" target="_blank" rel="noopener noreferrer" aria-label="Order on WhatsApp"
               href={waLink(info.whatsapp, `Hello ${info.store_name}, I'd like to order: ${p.name} (${naira(p.price)})`)}>
              <WaIcon />
            </a>
          )}
        </div>
      </div>
    </article>
  );
}
