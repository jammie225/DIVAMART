import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { api } from "./lib/api.js";

// Paystack sends the customer back here after card payment: /payment/callback?reference=...
export default function PaymentCallback() {
  const [params] = useSearchParams();
  const [state, setState] = useState({ status: "checking" });
  useEffect(() => {
    const ref = params.get("reference") || params.get("trxref");
    if (!ref) { setState({ status: "error", msg: "No payment reference found." }); return; }
    api.get(`/api/payments/paystack/verify/${encodeURIComponent(ref)}`)
      .then((r) => setState({ status: r.payment_status, order: r.order_number }))
      .catch((e) => setState({ status: "error", msg: e.message }));
  }, [params]);
  const paid = state.status === "paid";
  return (
    <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", background: "var(--cream)", padding: 20 }}>
      <div className="panel" style={{ background: "#fff", maxWidth: 440, textAlign: "center" }}>
        <h2 style={{ fontSize: 30, marginBottom: 10 }}>{state.status === "checking" ? "Confirming payment…" : paid ? "Payment successful 🎉" : "Payment not confirmed"}</h2>
        {state.order && <p>Order <b style={{ color: "var(--red)" }}>{state.order}</b></p>}
        <p style={{ color: "var(--muted)", margin: "10px 0 20px" }}>
          {paid ? "Thank you! Your order is confirmed. Track it under My orders." : state.status === "checking" ? "Please wait a moment." : state.msg || "If you were charged, contact support with your order number and we'll sort it out."}
        </p>
        <Link to="/" className="btn btn-red">Back to the shop</Link>
      </div>
    </div>
  );
}
