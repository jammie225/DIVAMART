import { useEffect, useMemo, useState } from "react";
import ChatWidget from "./components/ChatWidget.jsx";
import Header, { AnnouncementBar } from "./components/Header.jsx";
import Overlays from "./components/Overlays.jsx";
import { CategoryRail, CategorySection, DealBanner, Delivery, Footer, Hero, Newsletter, SearchResults, Support } from "./components/Sections.jsx";
import { SearchIcon } from "./components/Icons.jsx";
import { useDebounced } from "./lib/hooks.js";
import { useShop } from "./lib/ShopContext.jsx";

export default function Shop() {
  const { categories, products, loadError, reload, info } = useShop();
  const [search, setSearch] = useState("");
  const q = useDebounced(search.trim(), 300);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!info && !loadError) return;
    const t = setTimeout(() => { setReady(true); document.body.classList.add("ready"); }, 500);
    return () => clearTimeout(t);
  }, [info, loadError]);

  const byCat = useMemo(() => {
    const m = {};
    products.forEach((p) => (m[p.category] ||= []).push(p));
    return m;
  }, [products]);

  return (
    <>
      <div id="loader" className={ready ? "done" : ""}>
        <div><div className="logo">{[..."DIVAMART"].map((l, i) => <span key={i} style={{ animationDelay: `${i * 0.07}s` }}>{l}</span>)}</div><div className="bar"><i /></div></div>
      </div>
      <AnnouncementBar />
      <Header search={search} setSearch={setSearch} />
      <main>
        <Hero />
        <div className="msearch"><label className="searchbox"><SearchIcon /><input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search products…" aria-label="Search products" /></label></div>
        {loadError && <div className="wrap" style={{ padding: "30px 0" }}><div className="empty">{loadError} <button className="more" onClick={reload}>Try again</button></div></div>}
        <CategoryRail />
        {q && <SearchResults query={q} onClear={() => setSearch("")} />}
        {categories.map((c) => <CategorySection key={c.slug} cat={c} items={byCat[c.slug] || []} />)}
        <DealBanner />
        <Delivery />
        <Newsletter />
        <Support />
      </main>
      <Footer />
      <Overlays />
      <ChatWidget />
    </>
  );
}
