import { useCallback, useEffect, useState } from "react";
import { api, naira, PAY_LABEL } from "../lib/api.js";
import { useDebounced } from "../lib/hooks.js";
import { PwField } from "./PwField.jsx";
import { ImageDrop } from "./ProductsPanel.jsx";

const fmtDate = (d) => new Date(d).toLocaleString("en-NG", { dateStyle: "medium", timeStyle: "short" });

function Pager({ page, pages, total, onPage, extra }) {
  return (
    <div className="pager">
      <span>{total.toLocaleString()} records{extra}</span>
      <button disabled={page <= 1} onClick={() => onPage(page - 1)}>← Prev</button>
      <span>Page {page.toLocaleString()} of {pages.toLocaleString()}</span>
      <button disabled={page >= pages} onClick={() => onPage(page + 1)}>Next →</button>
    </div>
  );
}

/** Generic paged list loader. */
function usePaged(path, token, onAuthError, params) {
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);
  const [ms, setMs] = useState(0);
  const key = JSON.stringify(params);
  useEffect(() => setPage(1), [key]);
  const load = useCallback(() => {
    const qs = new URLSearchParams({ page, ...Object.fromEntries(Object.entries(params).filter(([, v]) => v)) });
    const t0 = performance.now();
    api.get(`${path}?${qs}`, { token }).then((d) => { setData(d); setMs(performance.now() - t0); }).catch(onAuthError);
  }, [path, page, key, token, onAuthError]); // eslint-disable-line
  useEffect(() => { load(); }, [load]);
  return { data, page, setPage, reload: load, ms };
}

// ===================== customers =====================
export function CustomersPanel({ token, onAuthError, notify }) {
  const [q, setQ] = useState("");
  const [state, setState] = useState("");
  const [states, setStates] = useState([]);
  const dq = useDebounced(q, 300);
  const { data, page, setPage, ms } = usePaged("/api/admin/customers", token, onAuthError, { q: dq, state });
  useEffect(() => { api.get("/api/store").then((s) => setStates(s.states)); }, []);
  const exportCsv = async () => {
    try { await api.download(`/api/admin/customers/export.csv?${new URLSearchParams({ q: dq, state })}`, token, "divamart-customers.csv"); notify("Download started"); }
    catch (e) { onAuthError(e); }
  };
  return (
    <>
      <div className="toolbar">
        <input placeholder="Search name, email or phone…" value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={state} onChange={(e) => setState(e.target.value)} style={{ height: 42, border: "1px solid var(--line)", borderRadius: 999, padding: "0 14px" }}>
          <option value="">All states</option>{states.map((s) => <option key={s}>{s}</option>)}</select>
        <button className="btn btn-sm" style={{ border: "1px solid var(--line)" }} onClick={exportCsv}>Export CSV</button>
      </div>
      <div className="tblwrap"><table className="tbl">
        <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>State</th><th>Orders</th><th>Spent</th><th>Joined</th></tr></thead>
        <tbody>{!data ? <tr><td colSpan="7">Loading…</td></tr> : !data.items.length ? <tr><td colSpan="7" style={{ textAlign: "center", padding: 30, color: "var(--muted)" }}>No customers yet</td></tr> :
          data.items.map((c) => <tr key={c.id}><td>{c.full_name}</td><td>{c.email}</td><td>{c.phone}</td><td>{c.state || "—"}</td><td>{c.orders}</td><td>{naira(c.spent)}</td><td>{new Date(c.created_at).toLocaleDateString("en-NG")}</td></tr>)}</tbody>
      </table></div>
      {data && <Pager {...data} page={page} onPage={setPage} extra={` · loaded in ${ms.toFixed(0)} ms`} />}
    </>
  );
}

// ===================== orders =====================
const STATUSES = ["received", "confirmed", "dispatched", "delivered", "cancelled"];
export function OrdersPanel({ token, onAuthError, notify, refreshStats }) {
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const dq = useDebounced(q, 300);
  const { data, page, setPage, reload } = usePaged("/api/admin/orders", token, onAuthError, { q: dq, status });
  const update = async (o, body) => {
    try { await api.patch(`/api/admin/orders/${o.order_number}`, body, { token }); notify(`${o.order_number} updated`); reload(); refreshStats(); }
    catch (e) { onAuthError(e); }
  };
  return (
    <>
      <div className="toolbar">
        <input placeholder="Search order number, name or phone…" value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={status} onChange={(e) => setStatus(e.target.value)} style={{ height: 42, border: "1px solid var(--line)", borderRadius: 999, padding: "0 14px" }}>
          <option value="">All statuses</option>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select>
      </div>
      {!data ? <p>Loading…</p> : !data.items.length ? <div className="empty">No orders yet.</div> : data.items.map((o) => (
        <div className="order" key={o.order_number}>
          <div className="top">
            <div><b>{o.order_number}</b><div style={{ color: "var(--muted)", fontSize: 12 }}>{fmtDate(o.created_at)} · {o.full_name} · {o.phone}{o.customer_email ? ` · ${o.customer_email}` : ""}</div></div>
            <div style={{ textAlign: "right" }}><b>{naira(o.total)}</b><div style={{ fontSize: 12, color: "var(--muted)" }}>{PAY_LABEL[o.payment_method]}</div></div>
          </div>
          <div style={{ fontSize: 13, color: "var(--muted)", margin: "8px 0" }}>
            {o.items.map((i) => `${i.quantity} × ${i.product_name} (${naira(i.unit_price)})`).join(" · ")}<br />
            📍 {o.address}, {o.city}, {o.state} · delivery {o.delivery_estimate}{o.note && <><br />📝 {o.note}</>}
          </div>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center", fontSize: 13 }}>
            <label>Status <select value={o.status} onChange={(e) => update(o, { status: e.target.value })}>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select></label>
            <label>Payment <select value={o.payment_status} onChange={(e) => update(o, { payment_status: e.target.value })}>{["pending", "paid", "failed"].map((s) => <option key={s}>{s}</option>)}</select></label>
          </div>
        </div>
      ))}
      {data && <Pager {...data} page={page} onPage={setPage} />}
    </>
  );
}

// ===================== tickets =====================
export function TicketsPanel({ token, onAuthError, refreshStats }) {
  const [status, setStatus] = useState("open");
  const { data, page, setPage, reload } = usePaged("/api/admin/tickets", token, onAuthError, { status });
  const toggle = async (t) => { try { await api.patch(`/api/admin/tickets/${t.ticket_number}`, {}, { token }); reload(); refreshStats(); } catch (e) { onAuthError(e); } };
  return (
    <>
      <div className="atabs">{[["open", "Open"], ["resolved", "Resolved"], ["", "All"]].map(([k, l]) => <button key={l} className={status === k ? "on" : ""} onClick={() => setStatus(k)}>{l}</button>)}</div>
      <div className="tblwrap"><table className="tbl">
        <thead><tr><th>Ticket</th><th>From</th><th>Topic</th><th>Message</th><th></th></tr></thead>
        <tbody>{!data ? <tr><td colSpan="5">Loading…</td></tr> : !data.items.length ? <tr><td colSpan="5" style={{ textAlign: "center", padding: 30, color: "var(--muted)" }}>No tickets</td></tr> :
          data.items.map((t) => <tr key={t.ticket_number}>
            <td><b>{t.ticket_number}</b><br /><small>{fmtDate(t.created_at)}</small></td>
            <td>{t.name}<br /><small><a href={`mailto:${t.email}`}>{t.email}</a></small></td>
            <td>{t.topic}{t.order_number && <><br /><small>{t.order_number}</small></>}</td>
            <td style={{ maxWidth: 360, whiteSpace: "pre-wrap" }}>{t.message}</td>
            <td><button className="mini-btn" onClick={() => toggle(t)}>{t.status === "open" ? "Mark resolved" : "Reopen"}</button></td></tr>)}</tbody>
      </table></div>
      {data && <Pager {...data} page={page} onPage={setPage} />}
    </>
  );
}

// ===================== chat logs =====================
export function ChatsPanel({ token, onAuthError }) {
  const [rows, setRows] = useState(null);
  useEffect(() => { api.get("/api/admin/chats?limit=200", { token }).then(setRows).catch(onAuthError); }, [token, onAuthError]);
  if (!rows) return <p>Loading…</p>;
  if (!rows.length) return <div className="empty">No chats yet.</div>;
  const sessions = {};
  rows.slice().reverse().forEach((r) => (sessions[r.session_id] ||= []).push(r));
  return (
    <>
      <p className="note" style={{ marginTop: 0 }}>Recent customer-care conversations. <span className="src">ai</span> = answered by the AI assistant, <span className="src">rules</span> = built-in answers.</p>
      {Object.entries(sessions).reverse().map(([sid, msgs]) => (
        <div className="chatlog" key={sid}>
          <small style={{ color: "var(--muted)" }}>Chat {sid.slice(0, 10)} · {fmtDate(msgs[0].created_at)}</small>
          {msgs.map((m, i) => <p key={i} style={{ margin: "8px 0" }}><span className="r">{m.role === "user" ? "Customer" : "Assistant"}</span>{m.role === "assistant" && <span className="src">{m.source}</span>}<br />{m.content}</p>)}
        </div>
      ))}
    </>
  );
}

// ===================== subscribers =====================
export function SubscribersPanel({ token, onAuthError, notify }) {
  const { data, page, setPage } = usePaged("/api/admin/subscribers", token, onAuthError, {});
  const copyAll = async () => {
    try { await navigator.clipboard.writeText(data.items.map((s) => s.email).join(", ")); notify("Emails on this page copied"); } catch { notify("Copy blocked by the browser"); }
  };
  return (
    <>
      <div className="toolbar"><button className="btn btn-sm" style={{ border: "1px solid var(--line)" }} onClick={copyAll} disabled={!data?.items.length}>Copy emails on this page</button></div>
      <div className="tblwrap"><table className="tbl"><thead><tr><th>Email</th><th>Source</th><th>Subscribed</th></tr></thead>
        <tbody>{!data ? <tr><td colSpan="3">Loading…</td></tr> : !data.items.length ? <tr><td colSpan="3" style={{ textAlign: "center", padding: 30, color: "var(--muted)" }}>No subscribers yet</td></tr> :
          data.items.map((s) => <tr key={s.email}><td>{s.email}</td><td>{s.source}</td><td>{fmtDate(s.created_at)}</td></tr>)}</tbody></table></div>
      {data && <Pager {...data} page={page} onPage={setPage} />}
    </>
  );
}

// ===================== store settings (owner) =====================
export function SettingsPanel({ token, onAuthError, notify }) {
  const [s, setS] = useState(null);
  const [cats, setCats] = useState([]);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => { api.get("/api/store").then(setS); api.get("/api/categories").then(setCats); }, []);
  if (!s) return <p>Loading…</p>;
  const set = (k) => (e) => setS({ ...s, [k]: e.target.value });
  const F = ({ k, label, type = "text", ...rest }) => <div className="field"><label htmlFor={`s_${k}`}>{label}</label><input id={`s_${k}`} type={type} value={s[k] ?? ""} onChange={set(k)} {...rest} /></div>;
  const save = async (e) => {
    e.preventDefault(); setErr(""); setBusy(true);
    const keys = ["store_name", "address", "whatsapp", "whatsapp_display", "support_hours", "delivery_fee_home", "delivery_fee_other",
      "deal_line1", "deal_line2", "deal_line3", "deal_category", "deal_ends", "bank_details"];
    try { setS({ ...s, ...(await api.put("/api/admin/settings", Object.fromEntries(keys.map((k) => [k, String(s[k] ?? "")])), { token })) }); notify("Settings saved ✓"); }
    catch (e2) { setErr(e2.message); onAuthError(e2); } finally { setBusy(false); }
  };
  const uploadImg = async (key, file) => {
    try { setS({ ...s, ...(await api.upload(`/api/admin/settings/image/${key}`, file, { token })) }); notify("Image uploaded ✓"); } catch (e) { onAuthError(e); }
  };
  const clearImg = async (key) => { try { setS({ ...s, ...(await api.del(`/api/admin/settings/image/${key}`, { token })) }); } catch (e) { onAuthError(e); } };
  return (
    <form onSubmit={save}>
      <div className="sgrid" style={{ gap: 22 }}>
        <div>
          <h3 style={{ fontSize: 20, marginBottom: 12 }}>Contact details</h3>
          {F({ k: "store_name", label: "Store name" })}
          {F({ k: "whatsapp", label: "WhatsApp number (with country code, e.g. 2348012345678)", inputMode: "numeric" })}
          {F({ k: "whatsapp_display", label: "WhatsApp number as shown on the site" })}
          {F({ k: "address", label: "Store address" })}
          {F({ k: "support_hours", label: "Support hours" })}
          <div className="field"><label htmlFor="s_bank">Bank transfer details (shown after a transfer order)</label><textarea id="s_bank" value={s.bank_details} onChange={set("bank_details")} placeholder={"Bank: …\nAccount name: …\nAccount number: …"} /></div>
          <h3 style={{ fontSize: 20, margin: "22px 0 12px" }}>Delivery fees (₦, 0 = confirmed by your team)</h3>
          <div className="row2">{F({ k: "delivery_fee_home", label: `Within ${s.home_state}`, type: "number", min: 0 })}{F({ k: "delivery_fee_other", label: "Other states", type: "number", min: 0 })}</div>
          <h3 style={{ fontSize: 20, margin: "22px 0 12px" }}>Deal of the week</h3>
          {F({ k: "deal_line1", label: "First line" })}
          <div className="row2">{F({ k: "deal_line2", label: "Highlighted text (gold)" })}{F({ k: "deal_line3", label: "After highlight" })}</div>
          <div className="row2">
            <div className="field"><label htmlFor="s_dc">Button links to</label><select id="s_dc" value={s.deal_category} onChange={set("deal_category")}>{cats.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}</select></div>
            {F({ k: "deal_ends", label: "Deal ends (empty = weekly)", type: "datetime-local" })}
          </div>
        </div>
        <div>
          <h3 style={{ fontSize: 20, marginBottom: 12 }}>Images</h3>
          {[["hero_image", "Hero image (top of the home page)", "3/4"], ["deal_image", "Deal of the week image", "1/1"]].map(([k, l, r]) => (
            <div key={k} style={{ marginBottom: 18 }}>
              <label style={{ fontSize: 13, fontWeight: 700 }}>{l}</label>
              <div style={{ maxWidth: 300, marginTop: 6 }}><ImageDrop url={s[k]} ratio={r} label="Upload image" onFile={(f) => uploadImg(k, f)} /></div>
              {s[k] && <button type="button" className="mini-btn del" style={{ marginTop: 6 }} onClick={() => clearImg(k)}>Use default artwork</button>}
            </div>
          ))}
        </div>
      </div>
      <div className="err">{err}</div>
      <button className="btn btn-red" disabled={busy}>{busy ? "Saving…" : "Save settings"}</button>
    </form>
  );
}

// ===================== staff (owner) =====================
export function StaffPanel({ token, admin, onAuthError, notify }) {
  const [list, setList] = useState(null);
  const [f, setF] = useState({ full_name: "", email: "", role: "staff", password: "" });
  const [err, setErr] = useState("");
  const [resetFor, setResetFor] = useState(null);
  const [newPw, setNewPw] = useState("");
  const load = useCallback(() => api.get("/api/admin/staff", { token }).then(setList).catch(onAuthError), [token, onAuthError]);
  useEffect(() => { load(); }, [load]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const add = async (e) => {
    e.preventDefault(); setErr("");
    try { await api.post("/api/admin/staff", f, { token }); notify("Admin added ✓"); setF({ full_name: "", email: "", role: "staff", password: "" }); load(); }
    catch (e2) { setErr(e2.message); onAuthError(e2); }
  };
  const patch = async (id, body, msg) => { try { await api.patch(`/api/admin/staff/${id}`, body, { token }); notify(msg); load(); } catch (e) { onAuthError(e); } };
  return (
    <div className="sgrid" style={{ gap: 20 }}>
      <div>
        <div className="tblwrap"><table className="tbl"><thead><tr><th>Name</th><th>Role</th><th>Last sign-in</th><th></th></tr></thead>
          <tbody>{(list || []).map((a) => <tr key={a.id}>
            <td><b>{a.full_name}</b><br /><small>{a.email}</small>{a.disabled && <span className="testpill">DISABLED</span>}</td>
            <td><span className={`role ${a.role}`}>{a.role === "owner" ? "Owner" : "Staff"}</span></td>
            <td>{a.last_login_at ? fmtDate(a.last_login_at) : "Never"}</td>
            <td style={{ whiteSpace: "nowrap" }}>{a.id === admin.id ? <small>You</small> : resetFor === a.id ? (
              <form style={{ display: "flex", gap: 6 }} onSubmit={(e) => { e.preventDefault(); patch(a.id, { new_password: newPw }, `Password reset for ${a.full_name}`); setResetFor(null); setNewPw(""); }}>
                <input style={{ height: 32, border: "1px solid var(--line)", borderRadius: 8, padding: "0 8px", width: 150 }} placeholder="New temp password" minLength={8} required value={newPw} onChange={(e) => setNewPw(e.target.value)} />
                <button className="mini-btn">Save</button></form>
            ) : <>
              <button className="mini-btn" onClick={() => setResetFor(a.id)}>Reset password</button>{" "}
              <button className="mini-btn" onClick={() => patch(a.id, { disabled: !a.disabled }, a.disabled ? "Admin enabled" : "Admin disabled")}>{a.disabled ? "Enable" : "Disable"}</button>
            </>}</td></tr>)}</tbody></table></div>
        <p className="note">Staff can manage products, orders, customers, tickets and subscribers. Only owners can change store settings and manage admins.</p>
      </div>
      <form className="panel" onSubmit={add}>
        <h3 style={{ fontSize: 20, marginBottom: 12 }}>Add an admin</h3>
        <div className="field"><label htmlFor="sfN">Full name</label><input id="sfN" required minLength={2} value={f.full_name} onChange={set("full_name")} /></div>
        <div className="field"><label htmlFor="sfE">Email</label><input id="sfE" type="email" required value={f.email} onChange={set("email")} /></div>
        <div className="field"><label htmlFor="sfR">Role</label><select id="sfR" value={f.role} onChange={set("role")}><option value="staff">Staff</option><option value="owner">Owner (full access)</option></select></div>
        <PwField id="sfP" label="Temporary password" value={f.password} onChange={set("password")} autoComplete="new-password" minLength={8} />
        <div className="err">{err}</div>
        <button className="btn btn-red btn-block">Add admin</button>
        <p className="note">Share the temporary password privately. They can change it under “My password”.</p>
      </form>
    </div>
  );
}

// ===================== my password =====================
export function PasswordPanel({ token, onAuthError, notify }) {
  const [f, setF] = useState({ current_password: "", new_password: "", confirm: "" });
  const [err, setErr] = useState("");
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setErr("");
    if (f.new_password !== f.confirm) return setErr("Passwords don't match.");
    try { await api.post("/api/admin/me/password", { current_password: f.current_password, new_password: f.new_password }, { token }); notify("Password updated 🔐"); setF({ current_password: "", new_password: "", confirm: "" }); }
    catch (e2) { setErr(e2.message); if (e2.status === 401) onAuthError(e2); }
  };
  return (
    <form className="panel" style={{ maxWidth: 440 }} onSubmit={submit}>
      <h3 style={{ fontSize: 20, marginBottom: 12 }}>Change my password</h3>
      <PwField id="cp1" label="Current password" value={f.current_password} onChange={set("current_password")} />
      <PwField id="cp2" label="New password" value={f.new_password} onChange={set("new_password")} autoComplete="new-password" minLength={8} />
      <PwField id="cp3" label="Confirm new password" value={f.confirm} onChange={set("confirm")} autoComplete="new-password" />
      <div className="err">{err}</div>
      <button className="btn btn-red">Update password</button>
    </form>
  );
}
