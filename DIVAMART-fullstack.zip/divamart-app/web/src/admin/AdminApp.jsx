import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { api, naira, store } from "../lib/api.js";
import { ChatsPanel, CustomersPanel, OrdersPanel, PasswordPanel, SettingsPanel, StaffPanel, SubscribersPanel, TicketsPanel } from "./Panels.jsx";
import ProductsPanel from "./ProductsPanel.jsx";
import { PwField } from "./PwField.jsx";

const IDLE_MINUTES = 30;
const SHIELD = <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2"><path d="M12 3 4 6v6c0 5 3.4 8.5 8 9 4.6-.5 8-4 8-9V6l-8-3Z" /><rect x="9" y="11" width="6" height="5" rx="1" /><path d="M10 11V9.5a2 2 0 0 1 4 0V11" /></svg>;

function Login({ onToken }) {
  const [needsSetup, setNeedsSetup] = useState(null);
  const [f, setF] = useState({ full_name: "", email: "", password: "", password2: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const form = useRef(null);
  useEffect(() => { api.get("/api/admin/setup-status").then((r) => setNeedsSetup(r.needs_setup)).catch((e) => setErr(e.message)); }, []);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const fail = (m) => { setErr(m); form.current?.classList.remove("shake"); void form.current?.offsetWidth; form.current?.classList.add("shake"); };
  const submit = async (e) => {
    e.preventDefault(); setErr("");
    if (needsSetup && f.password !== f.password2) return fail("Passwords don't match.");
    setBusy(true);
    try {
      const r = needsSetup
        ? await api.post("/api/admin/setup", { full_name: f.full_name, email: f.email, password: f.password })
        : await api.post("/api/admin/login", { email: f.email, password: f.password });
      onToken(r.token, r.admin);
    } catch (e2) { fail(e2.message); } finally { setBusy(false); }
  };
  return (
    <div className="admin-login"><div className="box"><div className="alog">
      <div className="side">
        <div><div className="shield">{SHIELD}</div><h4>DIVAMART<br />Admin</h4><p>Manage products, customers, orders, support tickets and newsletter subscribers.</p></div>
        <ul><li>Encrypted passwords (bcrypt)</li><li>Auto sign-out after {IDLE_MINUTES} min idle</li><li>Lockout after 5 wrong tries</li></ul><div className="glow" />
      </div>
      <form className="form" ref={form} onSubmit={submit}>
        {needsSetup === null && !err ? <p>Loading…</p> : <>
          <h4>{needsSetup ? "Set up the owner account" : "Admin sign in"}</h4>
          <p className="sub">{needsSetup ? "No admin exists yet. The first account becomes the Owner, who can add and remove staff." : "Staff only. Sign in with your admin email and password."}</p>
          {needsSetup && <div className="field"><label htmlFor="adName">Full name</label><input id="adName" required minLength={2} value={f.full_name} onChange={set("full_name")} /></div>}
          <div className="field"><label htmlFor="adEmail">Email</label><input id="adEmail" type="email" required autoComplete="username" value={f.email} onChange={set("email")} /></div>
          <PwField id="adPass" label="Password" value={f.password} onChange={set("password")} autoComplete={needsSetup ? "new-password" : "current-password"} minLength={needsSetup ? 8 : undefined} />
          {needsSetup && <PwField id="adPass2" label="Confirm password" value={f.password2} onChange={set("password2")} autoComplete="new-password" />}
          {needsSetup && <p className="note" style={{ margin: "-4px 0 10px" }}>At least 8 characters, with letters and numbers.</p>}
          <div className="err">{err}</div>
          <button className="btn btn-red btn-block" disabled={busy}>{busy ? "Please wait…" : needsSetup ? "Create owner account" : "Sign in"}</button>
          <p className="note" style={{ textAlign: "center" }}><Link to="/">← Back to the shop</Link></p>
        </>}
      </form>
    </div></div></div>
  );
}

const TABS = [
  ["products", "Products"], ["orders", "Orders"], ["customers", "Customers"], ["tickets", "Support tickets"],
  ["chats", "Chat logs"], ["subscribers", "Newsletter"], ["settings", "Store settings", true], ["staff", "Staff & admins", true], ["password", "My password"],
];

export default function AdminApp() {
  const [token, setToken] = useState(() => store.get("dvm_admin_token", null));
  const [admin, setAdmin] = useState(null);
  const [tab, setTab] = useState(() => (location.hash.slice(1) || "products"));
  const [stats, setStats] = useState(null);
  const [toast, setToast] = useState("");

  const logout = useCallback((msg) => {
    store.del("dvm_admin_token"); setToken(null); setAdmin(null);
    if (msg) { setToast(msg); setTimeout(() => setToast(""), 3000); }
  }, []);
  const notify = useCallback((m) => { setToast(m); setTimeout(() => setToast(""), 2800); }, []);

  useEffect(() => {
    if (!token) return;
    api.get("/api/admin/me", { token }).then(setAdmin).catch(() => logout("Please sign in again"));
  }, [token, logout]);

  const refreshStats = useCallback(() => token && api.get("/api/admin/stats", { token }).then(setStats).catch(() => {}), [token]);
  useEffect(() => { if (admin) refreshStats(); }, [admin, refreshStats]);

  // auto sign-out after inactivity
  useEffect(() => {
    if (!admin) return;
    let last = Date.now();
    const touch = () => (last = Date.now());
    ["pointerdown", "keydown"].forEach((ev) => document.addEventListener(ev, touch));
    const t = setInterval(() => { if (Date.now() - last > IDLE_MINUTES * 60000) logout("Signed out after inactivity"); }, 30000);
    return () => { clearInterval(t); ["pointerdown", "keydown"].forEach((ev) => document.removeEventListener(ev, touch)); };
  }, [admin, logout]);

  useEffect(() => { location.hash = tab; }, [tab]);
  // An expired session shows up as a 401 from any request
  const onAuthError = useCallback((e) => { if (e.status === 401) logout("Session expired — please sign in again"); else notify(e.message); }, [logout, notify]);

  if (!token || !admin) {
    return <>{token ? <p style={{ padding: 40 }}>Loading…</p> : <Login onToken={(t, a) => { store.set("dvm_admin_token", t); setToken(t); setAdmin(a); }} />}
      {toast && <div id="toasts"><div className="toast">{toast}</div></div>}</>;
  }
  const isOwner = admin.role === "owner";
  const visible = TABS.filter(([, , ownerOnly]) => !ownerOnly || isOwner);
  const current = visible.some(([k]) => k === tab) ? tab : "products";
  const ctx = { token, admin, notify, refreshStats, onAuthError };

  return (
    <div className="admin-shell">
      <div className="admin-top"><div className="wrap">
        <Link to="/" className="brand"><span className="dot" />DIVAMART</Link><span className="role">Admin</span>
        <div style={{ flex: 1 }} />
        <div className="who" style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <div className="avatar">{admin.full_name[0].toUpperCase()}</div>
          <div style={{ fontSize: 13 }}><b>{admin.full_name}</b> <span className={`role ${admin.role}`}>{isOwner ? "Owner" : "Staff"}</span></div>
        </div>
        <button className="btn btn-sm" style={{ border: "1px solid var(--line)" }} onClick={() => logout("Signed out")}>Sign out</button>
      </div></div>
      <div className="admin-main">
        {stats && <div className="kpis">
          <div className="kpi"><b>{stats.customers.toLocaleString()}</b><small>Customers (+{stats.new_customers_7d.toLocaleString()} this week)</small></div>
          <div className="kpi"><b>{stats.orders.toLocaleString()}</b><small>Orders</small></div>
          <div className="kpi"><b>{naira(stats.revenue)}</b><small>Order value (excl. cancelled)</small></div>
          <div className="kpi"><b>{stats.open_tickets}</b><small>Open support tickets</small></div>
        </div>}
        <div className="atabs">{visible.map(([k, l]) => <button key={k} className={current === k ? "on" : ""} onClick={() => setTab(k)}>{l}</button>)}</div>
        <div className="whitebox">
          {current === "products" && <ProductsPanel {...ctx} />}
          {current === "orders" && <OrdersPanel {...ctx} />}
          {current === "customers" && <CustomersPanel {...ctx} />}
          {current === "tickets" && <TicketsPanel {...ctx} />}
          {current === "chats" && <ChatsPanel {...ctx} />}
          {current === "subscribers" && <SubscribersPanel {...ctx} />}
          {current === "settings" && <SettingsPanel {...ctx} />}
          {current === "staff" && <StaffPanel {...ctx} />}
          {current === "password" && <PasswordPanel {...ctx} />}
        </div>
      </div>
      {toast && <div id="toasts"><div className="toast">{toast}</div></div>}
    </div>
  );
}
