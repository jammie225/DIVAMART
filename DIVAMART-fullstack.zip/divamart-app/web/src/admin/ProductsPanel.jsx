import { useCallback, useEffect, useRef, useState } from "react";
import { ProductImage } from "../components/ProductCard.jsx";
import { api, imgUrl, naira } from "../lib/api.js";
import { catStyle } from "../lib/art.js";

/** Drop zone: tap to choose a photo or drag one in. Calls onFile(file). */
export function ImageDrop({ url, onFile, ratio = "1/1", label = "Upload product photo" }) {
  const input = useRef(null);
  const [over, setOver] = useState(false);
  const take = (f) => f && onFile(f);
  return (
    <div className={`drop ${over ? "over" : ""}`} style={{ aspectRatio: ratio }} onClick={() => input.current.click()}
      onDragOver={(e) => { e.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)}
      onDrop={(e) => { e.preventDefault(); setOver(false); take(e.dataTransfer.files[0]); }}>
      {url ? <img src={imgUrl(url)} alt="" /> : <div className="hint"><div style={{ fontSize: 34 }}>📷</div><b>{label}</b>Tap to choose, or drag &amp; drop an image here</div>}
      <input ref={input} type="file" accept="image/*" hidden onChange={(e) => { take(e.target.files[0]); e.target.value = ""; }} />
    </div>
  );
}

function Editor({ product, categories, token, onDone, notify, onAuthError }) {
  const isNew = !product.id;
  const [f, setF] = useState({ category: product.category || categories[0]?.slug, name: product.name || "", description: product.description || "",
    price: product.price ?? "", old_price: product.old_price ?? "", badge: product.badge || "", in_stock: product.in_stock ?? true, visible: product.visible ?? true,
    sort_order: product.sort_order ?? 0 });
  const [img, setImg] = useState(product.image_url || null);     // current saved url
  const [pending, setPending] = useState(null);                  // file chosen but not uploaded yet (new products)
  const [preview, setPreview] = useState(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });

  const upload = async (pid, file) => (await api.upload(`/api/admin/products/${pid}/image`, file, { token })).image_url;
  const chooseFile = async (file) => {
    if (!file.type.startsWith("image/")) return setErr("Please choose an image file (JPG, PNG or WebP).");
    setErr("");
    if (isNew) { setPending(file); setPreview(URL.createObjectURL(file)); return; }
    setBusy(true);
    try { setImg(await upload(product.id, file)); notify("Photo uploaded ✓"); } catch (e) { setErr(e.message); onAuthError(e); } finally { setBusy(false); }
  };
  const removeImage = async () => {
    if (isNew) { setPending(null); setPreview(null); return; }
    try { await api.del(`/api/admin/products/${product.id}/image`, { token }); setImg(null); notify("Photo removed"); } catch (e) { onAuthError(e); }
  };
  const save = async (e) => {
    e.preventDefault(); setErr(""); setBusy(true);
    const body = { ...f, price: +f.price, old_price: f.old_price === "" ? null : +f.old_price, badge: f.badge.trim() || null, sort_order: +f.sort_order || 0 };
    try {
      const saved = isNew ? await api.post("/api/admin/products", body, { token }) : await api.put(`/api/admin/products/${product.id}`, body, { token });
      if (pending) await upload(saved.id, pending);
      notify(isNew ? "Product added ✓" : "Changes saved ✓");
      onDone(true);
    } catch (e2) { setErr(e2.message); if (e2.status === 401) onAuthError(e2); } finally { setBusy(false); }
  };
  const shown = preview || img;
  return (
    <>
      <button className="mini-btn" onClick={() => onDone(false)} style={{ marginBottom: 14 }}>← Back to products</button>
      <form className="pedit" onSubmit={save}>
        <div>
          {preview ? <div className="drop" onClick={() => document.getElementById("pfile").click()}><img src={preview} alt="" /><input id="pfile" type="file" accept="image/*" hidden onChange={(e) => e.target.files[0] && chooseFile(e.target.files[0])} /></div>
            : <ImageDrop url={shown} onFile={chooseFile} />}
          {shown && <button type="button" className="mini-btn del" style={{ marginTop: 8 }} onClick={removeImage}>Remove photo</button>}
          <p className="note">JPG, PNG or WebP up to 10 MB. Square photos look best. Large photos are resized automatically.</p>
        </div>
        <div>
          <h3 style={{ fontSize: 22, marginBottom: 14 }}>{isNew ? "Add a product" : "Edit product"}</h3>
          <div className="field"><label htmlFor="pfName">Product name</label><input id="pfName" required minLength={2} value={f.name} onChange={set("name")} /></div>
          <div className="row2">
            <div className="field"><label htmlFor="pfCat">Category</label><select id="pfCat" value={f.category} onChange={set("category")}>{categories.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}</select></div>
            <div className="field"><label htmlFor="pfBadge">Badge (optional)</label><input id="pfBadge" list="badges" maxLength={30} placeholder="New, Bestseller, -20%…" value={f.badge} onChange={set("badge")} />
              <datalist id="badges"><option>New</option><option>Bestseller</option><option>Hot deal</option><option>Limited</option></datalist></div>
          </div>
          <div className="row2">
            <div className="field"><label htmlFor="pfPrice">Price (₦)</label><input id="pfPrice" type="number" min="0" required value={f.price} onChange={set("price")} /></div>
            <div className="field"><label htmlFor="pfOld">Old price (₦, optional)</label><input id="pfOld" type="number" min="0" value={f.old_price} onChange={set("old_price")} /></div>
          </div>
          <div className="field"><label htmlFor="pfDesc">Description</label><textarea id="pfDesc" maxLength={2000} value={f.description} onChange={set("description")} /></div>
          <div className="row2">
            <div className="field"><label htmlFor="pfSort">Position in category (lower shows first)</label><input id="pfSort" type="number" value={f.sort_order} onChange={set("sort_order")} /></div>
            <div style={{ display: "flex", gap: 20, alignItems: "center" }}>
              <label className="sw"><input type="checkbox" checked={f.in_stock} onChange={set("in_stock")} />In stock</label>
              <label className="sw"><input type="checkbox" checked={f.visible} onChange={set("visible")} />Visible in shop</label>
            </div>
          </div>
          <div className="err">{err}</div>
          <button className="btn btn-red" disabled={busy}>{busy ? "Saving…" : isNew ? "Add product" : "Save changes"}</button>
        </div>
      </form>
    </>
  );
}

export default function ProductsPanel({ token, notify, onAuthError, refreshStats }) {
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState(null);
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("");
  const [editing, setEditing] = useState(null);
  const [confirmDel, setConfirmDel] = useState(null);

  const load = useCallback(() => {
    const p = new URLSearchParams(); if (q) p.set("q", q); if (cat) p.set("category", cat);
    api.get(`/api/admin/products?${p}`, { token }).then(setProducts).catch(onAuthError);
  }, [q, cat, token, onAuthError]);
  useEffect(() => { api.get("/api/categories").then(setCategories); }, []);
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t); }, [load]);

  const patch = async (p, changes) => {
    try {
      const body = { category: p.category, name: p.name, description: p.description, price: p.price, old_price: p.old_price,
        badge: p.badge, in_stock: p.in_stock, visible: p.visible, sort_order: p.sort_order, ...changes };
      const saved = await api.put(`/api/admin/products/${p.id}`, body, { token });
      setProducts((list) => list.map((x) => (x.id === p.id ? saved : x)));
    } catch (e) { onAuthError(e); }
  };
  const remove = async (p) => {
    if (confirmDel !== p.id) { setConfirmDel(p.id); setTimeout(() => setConfirmDel(null), 3000); return; }
    try { await api.del(`/api/admin/products/${p.id}`, { token }); notify("Product deleted"); load(); refreshStats(); } catch (e) { onAuthError(e); }
  };

  if (editing) return <Editor product={editing} categories={categories} token={token} notify={notify} onAuthError={onAuthError}
    onDone={(changed) => { setEditing(null); if (changed) { load(); refreshStats(); } }} />;
  return (
    <>
      <div className="toolbar">
        <input placeholder="Search products…" value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={cat} onChange={(e) => setCat(e.target.value)} style={{ height: 42, border: "1px solid var(--line)", borderRadius: 999, padding: "0 14px" }}>
          <option value="">All categories</option>{categories.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}</select>
        <button className="btn btn-sm btn-red" onClick={() => setEditing({ category: cat || categories[0]?.slug })}>+ Add product</button>
      </div>
      {products && <p className="note" style={{ margin: "0 0 10px" }}>{products.length} products · {products.filter((p) => p.image_url).length} with photos · tap <b>Edit</b> to upload a photo or change details.</p>}
      <div className="plist">
        {!products ? <p>Loading…</p> : !products.length ? <div className="empty">No products match.</div> : products.map((p) => (
          <div className="prow" key={p.id}>
            <div className="th" style={{ background: catStyle(p.category).bg }}><ProductImage p={p} /></div>
            <div><b>{p.name}</b><br /><small>{p.category_name} · <b style={{ color: "var(--red)" }}>{naira(p.price)}</b>{p.old_price && <> <s>{naira(p.old_price)}</s></>}</small></div>
            <label className="sw hide-sm"><input type="checkbox" checked={p.in_stock} onChange={(e) => patch(p, { in_stock: e.target.checked })} />In stock</label>
            <label className="sw hide-sm"><input type="checkbox" checked={p.visible} onChange={(e) => patch(p, { visible: e.target.checked })} />Visible</label>
            <div style={{ display: "flex", gap: 6 }}>
              <button className="mini-btn" onClick={() => setEditing(p)}>Edit</button>
              <button className="mini-btn del" onClick={() => remove(p)}>{confirmDel === p.id ? "Confirm?" : "Delete"}</button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
