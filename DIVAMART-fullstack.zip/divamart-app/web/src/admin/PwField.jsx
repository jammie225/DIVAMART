import { useState } from "react";

export function PwField({ id, label, value, onChange, autoComplete = "current-password", minLength }) {
  const [show, setShow] = useState(false);
  return (
    <div className="field"><label htmlFor={id}>{label}</label>
      <div className="pw"><input id={id} type={show ? "text" : "password"} required minLength={minLength} autoComplete={autoComplete} value={value} onChange={onChange} />
        <button type="button" onClick={() => setShow(!show)}>{show ? "Hide" : "Show"}</button></div></div>
  );
}
