import { lazy, StrictMode, Suspense } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import PaymentCallback from "./PaymentCallback.jsx";
import Shop from "./Shop.jsx";
import { ShopProvider } from "./lib/ShopContext.jsx";
import "./styles.css";
import "./extra.css";

const AdminApp = lazy(() => import("./admin/AdminApp.jsx"));   // admin code only loads for staff

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<ShopProvider><Shop /></ShopProvider>} />
        <Route path="/payment/callback" element={<PaymentCallback />} />
        <Route path="/admin/*" element={<Suspense fallback={<p style={{ padding: 40 }}>Loading…</p>}><AdminApp /></Suspense>} />
        <Route path="*" element={<ShopProvider><Shop /></ShopProvider>} />
      </Routes>
    </BrowserRouter>
  </StrictMode>,
);
