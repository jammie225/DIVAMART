import 'dart:convert';

import 'package:http/http.dart' as http;

/// Address of the DIVAMART Python API.
/// Android emulator: http://10.0.2.2:8000  ·  Real phone: your server, e.g. https://divamart.ng
/// Override at build time:  flutter run --dart-define=API_URL=https://divamart.ng
const String apiBase = String.fromEnvironment('API_URL', defaultValue: 'http://10.0.2.2:8000');

String imageUrl(String? path) =>
    path == null || path.isEmpty ? '' : (path.startsWith('http') ? path : '$apiBase$path');

class ApiException implements Exception {
  final String message;
  final int status;
  ApiException(this.message, this.status);
  @override
  String toString() => message;
}

class Api {
  String? token;

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  Future<dynamic> get(String path) => _send(() => http.get(Uri.parse('$apiBase$path'), headers: _headers));

  Future<dynamic> post(String path, Object body) =>
      _send(() => http.post(Uri.parse('$apiBase$path'), headers: _headers, body: jsonEncode(body)));

  Future<dynamic> _send(Future<http.Response> Function() call) async {
    http.Response res;
    try {
      res = await call().timeout(const Duration(seconds: 30));
    } catch (_) {
      throw ApiException("Can't reach the server. Check your internet connection.", 0);
    }
    final text = utf8.decode(res.bodyBytes);
    final data = text.isEmpty ? null : jsonDecode(text);
    if (res.statusCode >= 200 && res.statusCode < 300) return data;
    throw ApiException(_message(data, res.statusCode), res.statusCode);
  }

  static String _message(dynamic data, int status) {
    final d = data is Map ? data['detail'] : null;
    if (d is String) return d;
    if (d is List && d.isNotEmpty && d.first is Map) {
      final loc = (d.first['loc'] as List?)?.last?.toString().replaceAll('_', ' ');
      return loc != null ? '$loc: ${d.first['msg']}' : '${d.first['msg']}';
    }
    return status >= 500 ? 'Something went wrong on our side. Please try again.' : 'Request failed';
  }
}

String naira(num n) {
  final s = n.round().toString();
  final buf = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) buf.write(',');
    buf.write(s[i]);
  }
  return '₦$buf';
}
