class StoreInfo {
  final Map<String, dynamic> raw;
  StoreInfo(this.raw);
  String get name => raw['store_name'] ?? 'DIVAMART';
  String get address => raw['address'] ?? '';
  String get whatsapp => raw['whatsapp'] ?? '';
  String get whatsappDisplay => raw['whatsapp_display'] ?? '';
  String get hours => raw['support_hours'] ?? '';
  String get homeState => raw['home_state'] ?? 'Abia';
  String get bankDetails => raw['bank_details'] ?? '';
  String get heroImage => raw['hero_image'] ?? '';
  String get dealLine1 => raw['deal_line1'] ?? '';
  String get dealLine2 => raw['deal_line2'] ?? '';
  String get dealLine3 => raw['deal_line3'] ?? '';
  bool get cardPayments => raw['card_payments'] == true;
  List<String> get states => List<String>.from(raw['states'] ?? const []);
}

class Category {
  final int id;
  final String slug, name, subtitle;
  Category.fromJson(Map<String, dynamic> j)
      : id = j['id'],
        slug = j['slug'],
        name = j['name'],
        subtitle = j['subtitle'] ?? '';
}

class Product {
  final int id, price;
  final int? oldPrice;
  final String category, categoryName, name, description;
  final String? badge, imageUrl;
  final bool inStock;
  Product.fromJson(Map<String, dynamic> j)
      : id = j['id'],
        price = j['price'],
        oldPrice = j['old_price'],
        category = j['category'],
        categoryName = j['category_name'],
        name = j['name'],
        description = j['description'] ?? '',
        badge = j['badge'],
        imageUrl = j['image_url'],
        inStock = j['in_stock'] ?? true;
}

class Customer {
  final int id;
  final String email, fullName, phone;
  final String? state, city, address;
  Customer.fromJson(Map<String, dynamic> j)
      : id = j['id'],
        email = j['email'],
        fullName = j['full_name'],
        phone = j['phone'],
        state = j['state'],
        city = j['city'],
        address = j['address'];
  String get firstName => fullName.split(' ').first;
}

class OrderItem {
  final String productName;
  final int unitPrice, quantity;
  OrderItem.fromJson(Map<String, dynamic> j)
      : productName = j['product_name'],
        unitPrice = j['unit_price'],
        quantity = j['quantity'];
}

class Order {
  final String number, status, paymentStatus, paymentMethod, state, city, address, deliveryEstimate, fullName, phone;
  final int total, subtotal, deliveryFee;
  final DateTime createdAt;
  final List<OrderItem> items;
  Order.fromJson(Map<String, dynamic> j)
      : number = j['order_number'],
        status = j['status'],
        paymentStatus = j['payment_status'],
        paymentMethod = j['payment_method'],
        state = j['state'],
        city = j['city'],
        address = j['address'],
        fullName = j['full_name'],
        phone = j['phone'],
        deliveryEstimate = j['delivery_estimate'] ?? '',
        total = j['total'],
        subtotal = j['subtotal'],
        deliveryFee = j['delivery_fee'] ?? 0,
        createdAt = DateTime.parse(j['created_at']).toLocal(),
        items = (j['items'] as List).map((e) => OrderItem.fromJson(e)).toList();
}

class ChatMessage {
  final String role, content;
  ChatMessage(this.role, this.content);
  Map<String, String> toJson() => {'role': role, 'content': content};
}

const orderSteps = ['received', 'confirmed', 'dispatched', 'delivered'];
const payLabels = {'pod': 'Pay on delivery', 'transfer': 'Bank transfer', 'card': 'Card (Paystack)'};
