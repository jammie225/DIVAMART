import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../api.dart';
import '../main.dart';
import '../models.dart';
import '../state.dart';
import 'auth_screen.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});
  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  Future<List<Order>>? future;

  void _load() => setState(() => future = context.read<ShopState>().myOrders());

  @override
  Widget build(BuildContext context) {
    final signedIn = context.watch<ShopState>().customer != null;
    if (!signedIn) future = null;
    if (signedIn && future == null) WidgetsBinding.instance.addPostFrameCallback((_) => _load());
    return Scaffold(
      appBar: AppBar(title: const Text('My orders', style: TextStyle(fontWeight: FontWeight.w900))),
      body: !signedIn
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.local_shipping_outlined, size: 64, color: kMuted),
                  const SizedBox(height: 12),
                  const Text('Sign in to track your orders', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: () async {
                      final ok = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const AuthScreen()));
                      if (ok == true) _load();
                    },
                    child: const Text('Sign in'),
                  ),
                ]),
              ),
            )
          : RefreshIndicator(
              color: kRed,
              onRefresh: () async => _load(),
              child: FutureBuilder<List<Order>>(
                future: future,
                builder: (_, snap) {
                  if (snap.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator(color: kRed));
                  if (snap.hasError) return ListView(children: [Padding(padding: const EdgeInsets.all(24), child: Text('${snap.error}'))]);
                  final orders = snap.data!;
                  if (orders.isEmpty) return ListView(children: const [SizedBox(height: 120), Center(child: Text("You haven't placed any orders yet."))]);
                  return ListView.builder(padding: const EdgeInsets.all(16), itemCount: orders.length, itemBuilder: (_, i) => OrderCard(order: orders[i]));
                },
              ),
            ),
    );
  }
}

class OrderCard extends StatelessWidget {
  final Order order;
  const OrderCard({super.key, required this.order});

  @override
  Widget build(BuildContext context) {
    final o = order;
    final step = orderSteps.indexOf(o.status);
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(border: Border.all(color: const Color(0xFFEBDCDD)), borderRadius: BorderRadius.circular(16)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(o.number, style: const TextStyle(fontWeight: FontWeight.w900)),
              Text('${o.createdAt.day}/${o.createdAt.month}/${o.createdAt.year}', style: const TextStyle(color: kMuted, fontSize: 12)),
            ]),
          ),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(naira(o.total), style: const TextStyle(fontWeight: FontWeight.w900)),
            Text(o.paymentStatus, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: o.paymentStatus == 'paid' ? Colors.green : kRed)),
          ]),
        ]),
        const SizedBox(height: 14),
        if (o.status == 'cancelled')
          const Text('This order was cancelled.', style: TextStyle(color: kRed, fontWeight: FontWeight.w800))
        else
          Row(children: [
            for (var i = 0; i < orderSteps.length; i++) ...[
              Column(children: [
                AnimatedContainer(
                  duration: Duration(milliseconds: 300 + i * 150),
                  width: 18,
                  height: 18,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: i <= step ? kRed : const Color(0xFFEBDCDD)),
                ),
                const SizedBox(height: 4),
                Text(orderSteps[i][0].toUpperCase() + orderSteps[i].substring(1),
                    style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: i <= step ? kRed : kMuted)),
              ]),
              if (i < orderSteps.length - 1)
                Expanded(child: Container(height: 2, margin: const EdgeInsets.only(bottom: 16), color: i < step ? kRed : const Color(0xFFEBDCDD))),
            ],
          ]),
        const SizedBox(height: 10),
        Text(o.items.map((i) => '${i.quantity} × ${i.productName}').join(' · '), style: const TextStyle(color: kMuted, fontSize: 13)),
        Text('📍 ${o.address}, ${o.city}, ${o.state} · 🚚 ${o.deliveryEstimate}', style: const TextStyle(color: kMuted, fontSize: 13)),
      ]),
    );
  }
}
