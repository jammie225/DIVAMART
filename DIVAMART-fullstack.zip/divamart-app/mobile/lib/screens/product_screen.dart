import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../api.dart';
import '../main.dart';
import '../models.dart';
import '../state.dart';
import '../widgets/product_widgets.dart';

class ProductScreen extends StatelessWidget {
  final Product product;
  const ProductScreen({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    final shop = context.read<ShopState>();
    final p = product;
    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar(
          expandedHeight: 360,
          pinned: true,
          backgroundColor: Colors.white,
          flexibleSpace: FlexibleSpaceBar(background: Hero(tag: 'p${p.id}', child: ProductImage(product: p, iconSize: 120))),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p.categoryName.toUpperCase(), style: const TextStyle(color: kRed2, fontWeight: FontWeight.w800, letterSpacing: 1.4, fontSize: 12)),
              const SizedBox(height: 6),
              Text(p.name, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, height: 1.15)),
              const SizedBox(height: 12),
              Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(naira(p.price), style: const TextStyle(fontSize: 26, color: kRed, fontWeight: FontWeight.w900)),
                if (p.oldPrice != null) ...[
                  const SizedBox(width: 10),
                  Text(naira(p.oldPrice!), style: const TextStyle(color: kMuted, decoration: TextDecoration.lineThrough)),
                ],
              ]),
              const SizedBox(height: 16),
              Text(p.description, style: const TextStyle(fontSize: 15, height: 1.6, color: kMuted)),
              const SizedBox(height: 18),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: kBlush, borderRadius: BorderRadius.circular(14)),
                child: Row(children: [
                  const Icon(Icons.local_shipping, color: kRed),
                  const SizedBox(width: 10),
                  Expanded(child: Text('24hrs within ${shop.info?.homeState ?? 'Abia'} · 3–5 days nationwide', style: const TextStyle(color: kRed, fontWeight: FontWeight.w700))),
                ]),
              ),
            ]),
          ),
        ),
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: Row(children: [
            Expanded(
              child: p.inStock
                  ? FilledButton.icon(
                      icon: const Icon(Icons.add_shopping_cart),
                      label: const Text('Add to cart'),
                      onPressed: () {
                        shop.addToCart(p);
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Added to cart ✓'), behavior: SnackBarBehavior.floating));
                      },
                    )
                  : const FilledButton(onPressed: null, child: Text('Out of stock')),
            ),
            const SizedBox(width: 10),
            SizedBox(
              height: 50,
              child: OutlinedButton.icon(
                style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFF1FAF56), shape: const StadiumBorder()),
                icon: const Icon(Icons.chat),
                label: const Text('WhatsApp'),
                onPressed: () => shop.openWhatsApp("Hello ${shop.info?.name}, I'd like to order: ${p.name} (${naira(p.price)})"),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
