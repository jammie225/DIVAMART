import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../api.dart';
import '../main.dart';
import '../state.dart';
import '../widgets/product_widgets.dart';
import 'auth_screen.dart';
import 'checkout_screen.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final shop = context.watch<ShopState>();
    final lines = shop.cartLines;
    return Scaffold(
      appBar: AppBar(title: const Text('Your cart', style: TextStyle(fontWeight: FontWeight.w900))),
      body: lines.isEmpty
          ? const Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.shopping_bag_outlined, size: 64, color: kMuted),
                SizedBox(height: 10),
                Text('Your cart is empty', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                Text('Browse the shop and add something lovely.', style: TextStyle(color: kMuted)),
              ]),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: lines.length,
              separatorBuilder: (_, __) => const Divider(height: 20),
              itemBuilder: (_, i) {
                final p = lines[i].key, q = lines[i].value;
                return Dismissible(
                  key: ValueKey(p.id),
                  direction: DismissDirection.endToStart,
                  background: Container(alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 20), color: kBlush, child: const Icon(Icons.delete, color: kRed)),
                  onDismissed: (_) => shop.setQty(p.id, 0),
                  child: Row(children: [
                    ClipRRect(borderRadius: BorderRadius.circular(12), child: SizedBox(width: 64, height: 64, child: ProductImage(product: p, iconSize: 28))),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(p.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                        Text('${naira(p.price)} each', style: const TextStyle(color: kMuted, fontSize: 12)),
                        Row(children: [
                          IconButton(icon: const Icon(Icons.remove_circle_outline, color: kRed), onPressed: () => shop.setQty(p.id, q - 1)),
                          Text('$q', style: const TextStyle(fontWeight: FontWeight.w800)),
                          IconButton(icon: const Icon(Icons.add_circle_outline, color: kRed), onPressed: () => shop.setQty(p.id, q + 1)),
                        ]),
                      ]),
                    ),
                    Text(naira(p.price * q), style: const TextStyle(fontWeight: FontWeight.w800)),
                  ]),
                );
              },
            ),
      bottomNavigationBar: lines.isEmpty
          ? null
          : SafeArea(
              child: Container(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                decoration: const BoxDecoration(color: kCream, border: Border(top: BorderSide(color: Color(0xFFEBDCDD)))),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Row(children: [
                    Text('Subtotal (${shop.cartCount} items)'),
                    const Spacer(),
                    Text(naira(shop.cartTotal), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                  ]),
                  const SizedBox(height: 10),
                  FilledButton(
                    onPressed: () async {
                      if (shop.customer == null) {
                        final ok = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const AuthScreen()));
                        if (ok != true || !context.mounted) return;
                      }
                      Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CheckoutScreen()));
                    },
                    child: const Text('Checkout securely'),
                  ),
                  const SizedBox(height: 6),
                  TextButton.icon(
                    style: TextButton.styleFrom(foregroundColor: const Color(0xFF1FAF56)),
                    icon: const Icon(Icons.chat),
                    label: const Text('Order cart via WhatsApp'),
                    onPressed: () => shop.openWhatsApp("Hello ${shop.info?.name}, I'd like to order:\n" +
                        lines.map((l) => '• ${l.value} × ${l.key.name} — ${naira(l.key.price * l.value)}').join('\n') +
                        '\nTotal: ${naira(shop.cartTotal)}'),
                  ),
                ]),
              ),
            ),
    );
  }
}
