import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../api.dart';
import '../main.dart';
import '../state.dart';

/// Sign up / log in with email. Pops with `true` when signed in.
class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool signup = true, busy = false, newsletter = true, hide = true;
  String error = '';
  final form = GlobalKey<FormState>();
  final name = TextEditingController(), email = TextEditingController(), phone = TextEditingController(), pass = TextEditingController();

  @override
  void dispose() {
    for (final c in [name, email, phone, pass]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> submit() async {
    if (!form.currentState!.validate()) return;
    setState(() {
      busy = true;
      error = '';
    });
    final shop = context.read<ShopState>();
    try {
      if (signup) {
        await shop.signup(name.text.trim(), email.text.trim(), phone.text.trim(), pass.text, newsletter);
      } else {
        await shop.login(email.text.trim(), pass.text);
      }
      if (mounted) Navigator.of(context).pop(true);
    } on ApiException catch (e) {
      setState(() => error = e.message);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    String? req(String? v) => (v == null || v.trim().isEmpty) ? 'Required' : null;
    return Scaffold(
      appBar: AppBar(title: Text(signup ? 'Create your account' : 'Welcome back', style: const TextStyle(fontWeight: FontWeight.w900))),
      body: Form(
        key: form,
        child: ListView(padding: const EdgeInsets.all(20), children: [
          SegmentedButton<bool>(
            segments: const [ButtonSegment(value: true, label: Text('Sign up')), ButtonSegment(value: false, label: Text('Log in'))],
            selected: {signup},
            onSelectionChanged: (s) => setState(() {
              signup = s.first;
              error = '';
            }),
          ),
          const SizedBox(height: 20),
          AnimatedSize(
            duration: const Duration(milliseconds: 250),
            child: Column(children: [
              if (signup) ...[
                TextFormField(controller: name, decoration: const InputDecoration(labelText: 'Full name'), validator: req, textCapitalization: TextCapitalization.words),
                const SizedBox(height: 12),
              ],
              TextFormField(
                controller: email,
                decoration: const InputDecoration(labelText: 'Email'),
                keyboardType: TextInputType.emailAddress,
                validator: (v) => (v == null || !v.contains('@')) ? 'Enter a valid email' : null,
              ),
              const SizedBox(height: 12),
              if (signup) ...[
                TextFormField(
                  controller: phone,
                  decoration: const InputDecoration(labelText: 'Phone number', hintText: '080…'),
                  keyboardType: TextInputType.phone,
                  validator: (v) => (v == null || v.replaceAll(RegExp(r'\D'), '').length < 10) ? 'Enter a valid phone number' : null,
                ),
                const SizedBox(height: 12),
              ],
              TextFormField(
                controller: pass,
                obscureText: hide,
                decoration: InputDecoration(
                  labelText: 'Password',
                  suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => hide = !hide)),
                ),
                validator: (v) => (v == null || v.length < 6) ? 'At least 6 characters' : null,
              ),
              if (signup)
                CheckboxListTile(
                  value: newsletter,
                  activeColor: kRed,
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Send me deals and new arrivals'),
                  onChanged: (v) => setState(() => newsletter = v ?? false),
                ),
            ]),
          ),
          if (error.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(error, style: const TextStyle(color: kRed2, fontWeight: FontWeight.w700))),
          const SizedBox(height: 16),
          FilledButton(onPressed: busy ? null : submit, child: Text(busy ? 'Please wait…' : signup ? 'Create account' : 'Log in')),
        ]),
      ),
    );
  }
}
