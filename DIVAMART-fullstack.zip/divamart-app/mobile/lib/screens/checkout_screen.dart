import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../api.dart';
import '../main.dart';
import '../models.dart';
import '../state.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});
  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final form = GlobalKey<FormState>();
  late final TextEditingController name, phone, city, address, note;
  String? state;
  String payment = 'pod', error = '';
  Map<String, dynamic>? estimate;
  bool busy = false;
  Order? done;

  @override
  void initState() {
    super.initState();
    final c = context.read<ShopState>().customer;
    name = TextEditingController(text: c?.fullName ?? '');
    phone = TextEditingController(text: c?.phone ?? '');
    city = TextEditingController(text: c?.city ?? '');
    address = TextEditingController(text: c?.address ?? '');
    note = TextEditingController();
    if (c?.state != null) _setState(c!.state!);
  }

  @override
  void dispose() {
    for (final t in [name, phone, city, address, note]) {
      t.dispose();
    }
    super.dispose();
  }

  Future<void> _setState(String s) async {
    setState(() => state = s);
    try {
      final e = await context.read<ShopState>().deliveryEstimate(s);
      if (mounted) setState(() => estimate = e);
    } catch (_) {}
  }

  Future<void> submit() async {
    if (!form.currentState!.validate()) return;
    final shop = context.read<ShopState>();
    setState(() {
      busy = true;
      error = '';
    });
    try {
      final order = await shop.placeOrder({
        'full_name': name.text.trim(),
        'phone': phone.text.trim(),
        'state': state,
        'city': city.text.trim(),
        'address': address.text.trim(),
        'note': note.text.trim(),
        'payment_method': payment,
      });
      if (payment == 'card') {
        final url = await shop.startCardPayment(order.number);
        await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      }
      setState(() => done = order);
    } on ApiException catch (e) {
      setState(() => error = e.message);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final shop = context.watch<ShopState>();
    final info = shop.info!;
    if (done != null) return _success(shop, info, done!);
    String? req(String? v) => (v == null || v.trim().length < 2) ? 'Required' : null;
    final fee = (estimate?['fee'] as int?) ?? 0;
    return Scaffold(
      appBar: AppBar(title: const Text('Checkout', style: TextStyle(fontWeight: FontWeight.w900))),
      body: Form(
        key: form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          TextFormField(controller: name, decoration: const InputDecoration(labelText: 'Full name'), validator: req),
          const SizedBox(height: 12),
          TextFormField(controller: phone, decoration: const InputDecoration(labelText: 'Phone'), keyboardType: TextInputType.phone, validator: req),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: state,
            isExpanded: true,
            decoration: const InputDecoration(labelText: 'State'),
            items: info.states.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
            onChanged: (s) => s == null ? null : _setState(s),
            validator: (v) => v == null ? 'Choose your state' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(controller: city, decoration: const InputDecoration(labelText: 'City / Town'), validator: req),
          const SizedBox(height: 12),
          TextFormField(controller: address, decoration: const InputDecoration(labelText: 'Delivery address', hintText: 'House number, street, landmark'), validator: req),
          const SizedBox(height: 12),
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: kBlush, borderRadius: BorderRadius.circular(14)),
            child: Text(estimate == null ? '🚚 Choose your state to see delivery time' : '🚚 Delivery ${estimate!['estimate']} to $state',
                style: const TextStyle(color: kRed, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(height: 16),
          const Text('Payment method', style: TextStyle(fontWeight: FontWeight.w800)),
          for (final m in ['pod', 'transfer', if (info.cardPayments) 'card'])
            RadioListTile<String>(value: m, groupValue: payment, activeColor: kRed, title: Text(payLabels[m]!), onChanged: (v) => setState(() => payment = v!)),
          TextFormField(controller: note, decoration: const InputDecoration(labelText: 'Order note (optional)', hintText: 'Size, colour, delivery time…')),
          const Divider(height: 32),
          for (final l in shop.cartLines)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(children: [Expanded(child: Text('${l.value} × ${l.key.name}')), Text(naira(l.key.price * l.value))]),
            ),
          Row(children: [const Expanded(child: Text('Delivery fee')), Text(fee > 0 ? naira(fee) : 'Confirmed by our team')]),
          const SizedBox(height: 6),
          Row(children: [
            const Expanded(child: Text('Total', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18))),
            Text(naira(shop.cartTotal + fee), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
          ]),
          if (error.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text(error, style: const TextStyle(color: kRed2, fontWeight: FontWeight.w700))),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: busy || shop.cartLines.isEmpty ? null : submit,
            child: Text(busy ? 'Placing order…' : payment == 'card' ? 'Continue to payment' : 'Place order'),
          ),
        ]),
      ),
    );
  }

  Widget _success(ShopState shop, StoreInfo info, Order o) {
    final msg = 'Hello ${info.name}, I just placed order ${o.number}.\n' +
        o.items.map((i) => '• ${i.quantity} × ${i.productName}').join('\n') +
        '\nTotal: ${naira(o.total)}\nPayment: ${payLabels[o.paymentMethod]}\nDeliver to: ${o.address}, ${o.city}, ${o.state}\nName: ${o.fullName} (${o.phone})';
    return Scaffold(
      appBar: AppBar(title: const Text('Order placed')),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: 1),
          duration: const Duration(milliseconds: 700),
          curve: Curves.elasticOut,
          builder: (_, v, __) => Transform.scale(scale: v, child: const Icon(Icons.check_circle, color: kRed, size: 96)),
        ),
        const SizedBox(height: 12),
        const Text('Order placed!', textAlign: TextAlign.center, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        Text(o.number, textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, color: kRed, fontWeight: FontWeight.w900)),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: kBlush, borderRadius: BorderRadius.circular(14)),
          child: Text('🚚 Delivery ${o.deliveryEstimate} to ${o.state}', textAlign: TextAlign.center, style: const TextStyle(color: kRed, fontWeight: FontWeight.w800)),
        ),
        if (o.paymentMethod == 'transfer' && info.bankDetails.isNotEmpty) ...[
          const SizedBox(height: 14),
          Text('Bank transfer details\n${info.bankDetails}\nUse ${o.number} as the payment reference.'),
        ],
        const SizedBox(height: 20),
        FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: const Color(0xFF1FAF56)),
          icon: const Icon(Icons.chat),
          label: const Text('Send order on WhatsApp'),
          onPressed: () => shop.openWhatsApp(msg),
        ),
        const SizedBox(height: 8),
        OutlinedButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Back to shop')),
      ]),
    );
  }
}
