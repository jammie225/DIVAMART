import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../api.dart';
import '../main.dart';
import '../state.dart';
import '../widgets/product_widgets.dart';

class HomeScreen extends StatefulWidget {
  final VoidCallback onOpenCart;
  const HomeScreen({super.key, required this.onOpenCart});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String category = '';
  String query = '';

  @override
  Widget build(BuildContext context) {
    final shop = context.watch<ShopState>();
    final info = shop.info;
    final q = query.trim().toLowerCase();
    final list = shop.products
        .where((p) => category.isEmpty || p.category == category)
        .where((p) => q.isEmpty || '${p.name} ${p.description} ${p.categoryName}'.toLowerCase().contains(q))
        .toList();

    return RefreshIndicator(
      color: kRed,
      onRefresh: shop.refresh,
      child: CustomScrollView(slivers: [
        SliverAppBar(
          pinned: true,
          expandedHeight: 250,
          backgroundColor: kRed,
          foregroundColor: Colors.white,
          title: const Text('DIVAMART', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 3)),
          actions: [
            if (info != null)
              IconButton(
                tooltip: 'Order on WhatsApp',
                icon: const Icon(Icons.chat),
                onPressed: () => shop.openWhatsApp("Hello ${info.name}, I'd like to place an order."),
              ),
          ],
          flexibleSpace: FlexibleSpaceBar(
            collapseMode: CollapseMode.parallax,
            background: Container(
              decoration: const BoxDecoration(gradient: LinearGradient(colors: [kWine, kRed, Color(0xFF5A0910)], begin: Alignment.topLeft, end: Alignment.bottomRight)),
              padding: const EdgeInsets.fromLTRB(20, 100, 20, 20),
              child: Stack(children: [
                if ((info?.heroImage ?? '').isNotEmpty)
                  Positioned(right: 0, top: 0, bottom: 0, child: ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.network(imageUrl(info!.heroImage), width: 110, fit: BoxFit.cover))),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Smell divine.\nLook radiant.\nLive easy.', style: TextStyle(color: Colors.white, fontSize: 28, height: 1.1, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 10),
                  Text('Nationwide delivery · 24hrs within ${info?.homeState ?? 'Abia'}', style: const TextStyle(color: kGold, fontWeight: FontWeight.w700)),
                ]),
              ]),
            ),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(64),
            child: Container(
              color: Colors.white,
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
              child: TextField(
                onChanged: (v) => setState(() => query = v),
                decoration: const InputDecoration(hintText: 'Search perfumes, creams, rice…', prefixIcon: Icon(Icons.search), isDense: true),
              ),
            ),
          ),
        ),
        if (info != null && info.dealLine2.isNotEmpty)
          SliverToBoxAdapter(
            child: Container(
              margin: const EdgeInsets.fromLTRB(16, 14, 16, 0),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1B0A0C), kWine, kRed]), borderRadius: BorderRadius.circular(18)),
              child: Row(children: [
                const Icon(Icons.local_offer, color: kGold),
                const SizedBox(width: 12),
                Expanded(child: Text('${info.dealLine1} ${info.dealLine2} ${info.dealLine3}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800))),
              ]),
            ),
          ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 58,
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.fromLTRB(12, 12, 12, 6), children: [
              _chip('All', '', Icons.apps),
              for (final c in shop.categories) _chip(c.name, c.slug, categoryIcon(c.slug)),
            ]),
          ),
        ),
        if (shop.loading && shop.products.isEmpty)
          const SliverFillRemaining(child: Center(child: CircularProgressIndicator(color: kRed)))
        else if (shop.loadError != null && shop.products.isEmpty)
          SliverFillRemaining(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Text(shop.loadError!, textAlign: TextAlign.center),
                  const SizedBox(height: 12),
                  FilledButton(onPressed: shop.refresh, child: const Text('Try again')),
                ]),
              ),
            ),
          )
        else if (list.isEmpty)
          const SliverFillRemaining(child: Center(child: Text('No products found')))
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(12, 6, 12, 90),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 240, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .62),
              delegate: SliverChildBuilderDelegate((_, i) => ProductCard(key: ValueKey('${list[i].id}-$category-$q'), product: list[i], index: i), childCount: list.length),
            ),
          ),
      ]),
    );
  }

  Widget _chip(String label, String slug, IconData icon) {
    final on = category == slug;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        avatar: Icon(icon, size: 16, color: on ? Colors.white : kRed),
        selected: on,
        showCheckmark: false,
        selectedColor: kRed,
        labelStyle: TextStyle(color: on ? Colors.white : kRed, fontWeight: FontWeight.w700),
        side: const BorderSide(color: Color(0xFFEBDCDD)),
        onSelected: (_) => setState(() => category = slug),
      ),
    );
  }
}
