import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../api.dart';
import '../main.dart';
import '../state.dart';
import 'auth_screen.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final shop = context.watch<ShopState>();
    final c = shop.customer;
    final info = shop.info;
    return Scaffold(
      appBar: AppBar(title: const Text('Account', style: TextStyle(fontWeight: FontWeight.w900))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (c == null)
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: kBlush, borderRadius: BorderRadius.circular(18)),
            child: Column(children: [
              const Text('Sign in to check out faster and track orders', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              FilledButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AuthScreen())), child: const Text('Sign up / Log in')),
            ]),
          )
        else
          ListTile(
            leading: CircleAvatar(backgroundColor: kRed, child: Text(c.fullName[0].toUpperCase(), style: const TextStyle(color: Colors.white))),
            title: Text(c.fullName, style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text('${c.email}\n${c.phone}'),
            isThreeLine: true,
            trailing: TextButton(onPressed: shop.logout, child: const Text('Sign out')),
          ),
        const SizedBox(height: 20),
        const _Heading('Delivery'),
        _InfoTile(Icons.bolt, 'Within ${info?.homeState ?? 'Abia'} State', 'Delivered within 24 hours'),
        const _InfoTile(Icons.local_shipping, 'Other states', 'Delivered in 3–5 days, nationwide'),
        const SizedBox(height: 16),
        const _Heading('Contact us'),
        if (info != null) ...[
          _InfoTile(Icons.location_on, 'Store', info.address),
          ListTile(
            leading: const Icon(Icons.chat, color: Color(0xFF1FAF56)),
            title: const Text('WhatsApp'),
            subtitle: Text(info.whatsappDisplay),
            onTap: () => shop.openWhatsApp('Hello ${info.name}!'),
          ),
          _InfoTile(Icons.schedule, 'Support hours', info.hours),
        ],
        ListTile(
          leading: const Icon(Icons.support_agent, color: kRed),
          title: const Text('Open a support ticket'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => const _TicketSheet()),
        ),
        const SizedBox(height: 16),
        const _Heading('Newsletter'),
        const _NewsletterBox(),
      ]),
    );
  }
}

class _Heading extends StatelessWidget {
  final String text;
  const _Heading(this.text);
  @override
  Widget build(BuildContext context) =>
      Padding(padding: const EdgeInsets.only(bottom: 4), child: Text(text.toUpperCase(), style: const TextStyle(color: kRed2, fontWeight: FontWeight.w800, letterSpacing: 1.4, fontSize: 12)));
}

class _InfoTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  const _InfoTile(this.icon, this.title, this.subtitle);
  @override
  Widget build(BuildContext context) => ListTile(leading: Icon(icon, color: kRed), title: Text(title), subtitle: Text(subtitle));
}

class _NewsletterBox extends StatefulWidget {
  const _NewsletterBox();
  @override
  State<_NewsletterBox> createState() => _NewsletterBoxState();
}

class _NewsletterBoxState extends State<_NewsletterBox> {
  final email = TextEditingController();
  @override
  void dispose() {
    email.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(child: TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(hintText: 'Your email for deals', isDense: true))),
      const SizedBox(width: 8),
      FilledButton(
        style: FilledButton.styleFrom(minimumSize: const Size(110, 48)),
        onPressed: () async {
          final m = ScaffoldMessenger.of(context);
          try {
            await context.read<ShopState>().subscribe(email.text.trim());
            email.clear();
            m.showSnackBar(const SnackBar(content: Text('Subscribed 💌')));
          } on ApiException catch (e) {
            m.showSnackBar(SnackBar(content: Text(e.message)));
          }
        },
        child: const Text('Subscribe'),
      ),
    ]);
  }
}

class _TicketSheet extends StatefulWidget {
  const _TicketSheet();
  @override
  State<_TicketSheet> createState() => _TicketSheetState();
}

class _TicketSheetState extends State<_TicketSheet> {
  final form = GlobalKey<FormState>();
  late final name = TextEditingController(text: context.read<ShopState>().customer?.fullName ?? '');
  late final email = TextEditingController(text: context.read<ShopState>().customer?.email ?? '');
  final orderNo = TextEditingController(), message = TextEditingController();
  String topic = 'Order issue', error = '';
  bool busy = false;

  @override
  void dispose() {
    for (final c in [name, email, orderNo, message]) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    String? req(String? v) => (v == null || v.trim().length < 2) ? 'Required' : null;
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 20, 16, MediaQuery.of(context).viewInsets.bottom + 20),
      child: Form(
        key: form,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('Open a support ticket', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 14),
            TextFormField(controller: name, decoration: const InputDecoration(labelText: 'Name'), validator: req),
            const SizedBox(height: 10),
            TextFormField(controller: email, decoration: const InputDecoration(labelText: 'Email'), validator: (v) => (v ?? '').contains('@') ? null : 'Enter a valid email'),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: topic,
              decoration: const InputDecoration(labelText: 'Topic'),
              items: ['Order issue', 'Delivery', 'Payment', 'Returns & refunds', 'Product question', 'Other'].map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
              onChanged: (v) => setState(() => topic = v!),
            ),
            const SizedBox(height: 10),
            TextFormField(controller: orderNo, decoration: const InputDecoration(labelText: 'Order number (optional)')),
            const SizedBox(height: 10),
            TextFormField(controller: message, maxLines: 4, decoration: const InputDecoration(labelText: 'Message'), validator: (v) => (v ?? '').trim().length < 5 ? 'Tell us a bit more' : null),
            if (error.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(error, style: const TextStyle(color: kRed2))),
            const SizedBox(height: 14),
            FilledButton(
              onPressed: busy
                  ? null
                  : () async {
                      if (!form.currentState!.validate()) return;
                      setState(() => busy = true);
                      final nav = Navigator.of(context), m = ScaffoldMessenger.of(context);
                      try {
                        final no = await context.read<ShopState>().openTicket({
                          'name': name.text.trim(),
                          'email': email.text.trim(),
                          'topic': topic,
                          'order_number': orderNo.text.trim().isEmpty ? null : orderNo.text.trim(),
                          'message': message.text.trim(),
                        });
                        nav.pop();
                        m.showSnackBar(SnackBar(content: Text('Ticket $no received — we\'ll reply soon')));
                      } on ApiException catch (e) {
                        setState(() {
                          error = e.message;
                          busy = false;
                        });
                      }
                    },
              child: Text(busy ? 'Sending…' : 'Submit ticket'),
            ),
          ]),
        ),
      ),
    );
  }
}
