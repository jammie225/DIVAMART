import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../main.dart';
import '../state.dart';

/// Customer-care chat. Replies come from the backend: AI when configured, otherwise built-in answers.
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final input = TextEditingController();
  final scroll = ScrollController();
  bool waiting = false;

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  Future<void> send(String text) async {
    text = text.trim();
    if (text.isEmpty || waiting) return;
    input.clear();
    setState(() => waiting = true);
    _scrollDown();
    await context.read<ShopState>().sendChat(text);
    if (!mounted) return;
    setState(() => waiting = false);
    _scrollDown();
  }

  void _scrollDown() => WidgetsBinding.instance.addPostFrameCallback((_) {
        if (scroll.hasClients) scroll.animateTo(scroll.position.maxScrollExtent + 80, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      });

  @override
  Widget build(BuildContext context) {
    final shop = context.watch<ShopState>();
    final msgs = shop.chat;
    return Scaffold(
      backgroundColor: kCream,
      appBar: AppBar(
        backgroundColor: kRed,
        foregroundColor: Colors.white,
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Customer Care', style: TextStyle(fontWeight: FontWeight.w900)),
          Text('Usually replies instantly', style: TextStyle(fontSize: 12, color: Colors.white70)),
        ]),
        actions: [
          IconButton(tooltip: 'WhatsApp', icon: const Icon(Icons.chat), onPressed: () => shop.openWhatsApp('Hello, I need help.')),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: ListView.builder(
            controller: scroll,
            padding: const EdgeInsets.all(16),
            itemCount: msgs.length + 1 + (waiting ? 1 : 0),
            itemBuilder: (_, i) {
              if (i == 0) return _bubble("Hi there 👋 I'm the ${shop.info?.name ?? 'DIVAMART'} assistant. Ask me about products, delivery, payment or your order.", false);
              if (i > msgs.length) return _bubble('…', false);
              final m = msgs[i - 1];
              return _bubble(m.content, m.role == 'user');
            },
          ),
        ),
        SizedBox(
          height: 44,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
            for (final q in ['Delivery time', 'Payment options', 'Track my order', 'Talk to a person'])
              Padding(padding: const EdgeInsets.only(right: 6), child: ActionChip(label: Text(q), onPressed: () => send(q))),
          ]),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: input,
                  maxLength: 1500,
                  textInputAction: TextInputAction.send,
                  onSubmitted: send,
                  decoration: const InputDecoration(hintText: 'Type a message…', counterText: '', isDense: true),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                style: IconButton.styleFrom(backgroundColor: kRed),
                icon: const Icon(Icons.send, color: Colors.white),
                onPressed: waiting ? null : () => send(input.text),
              ),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _bubble(String text, bool me) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 280),
      builder: (_, v, child) => Opacity(opacity: v, child: Transform.translate(offset: Offset(0, 10 * (1 - v)), child: child)),
      child: Align(
        alignment: me ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .78),
          decoration: BoxDecoration(
            color: me ? kRed : Colors.white,
            border: me ? null : Border.all(color: const Color(0xFFEBDCDD)),
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(16),
              topRight: const Radius.circular(16),
              bottomLeft: Radius.circular(me ? 16 : 4),
              bottomRight: Radius.circular(me ? 4 : 16),
            ),
          ),
          child: Text(text, style: TextStyle(color: me ? Colors.white : const Color(0xFF1B0A0C), height: 1.4)),
        ),
      ),
    );
  }
}
