import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'api.dart';
import 'models.dart';

/// App-wide state: catalogue, signed-in customer, cart, chat.
class ShopState extends ChangeNotifier {
  final Api api = Api();
  late SharedPreferences _prefs;

  StoreInfo? info;
  List<Category> categories = [];
  List<Product> products = [];
  Customer? customer;
  final Map<int, int> cart = {}; // productId -> quantity
  final List<ChatMessage> chat = [];
  late final String chatSession;
  String? loadError;
  bool loading = true;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    api.token = _prefs.getString('token');
    chatSession = _prefs.getString('chat_session') ??
        's${Random().nextInt(1 << 31).toRadixString(36)}${DateTime.now().millisecondsSinceEpoch.toRadixString(36)}';
    await _prefs.setString('chat_session', chatSession);
    final saved = _prefs.getString('cart');
    if (saved != null) {
      (jsonDecode(saved) as Map<String, dynamic>).forEach((k, v) => cart[int.parse(k)] = v as int);
    }
    await refresh();
    if (api.token != null) {
      try {
        customer = Customer.fromJson(await api.get('/api/auth/me'));
      } on ApiException catch (e) {
        if (e.status == 401) await _setToken(null);
      }
    }
    notifyListeners();
  }

  Future<void> refresh() async {
    loading = true;
    notifyListeners();
    try {
      final results = await Future.wait([api.get('/api/store'), api.get('/api/categories'), api.get('/api/products?limit=200')]);
      info = StoreInfo(results[0] as Map<String, dynamic>);
      categories = (results[1] as List).map((e) => Category.fromJson(e)).toList();
      products = ((results[2] as Map)['items'] as List).map((e) => Product.fromJson(e)).toList();
      loadError = null;
    } on ApiException catch (e) {
      loadError = e.message;
    }
    loading = false;
    notifyListeners();
  }

  Product? productById(int id) {
    for (final p in products) {
      if (p.id == id) return p;
    }
    return null;
  }

  // ---------- cart ----------
  List<MapEntry<Product, int>> get cartLines => cart.entries
      .map((e) => MapEntry(productById(e.key), e.value))
      .where((e) => e.key != null && e.key!.inStock)
      .map((e) => MapEntry(e.key!, e.value))
      .toList();
  int get cartCount => cartLines.fold(0, (s, l) => s + l.value);
  int get cartTotal => cartLines.fold(0, (s, l) => s + l.key.price * l.value);

  void addToCart(Product p) {
    cart[p.id] = min(99, (cart[p.id] ?? 0) + 1);
    _saveCart();
  }

  void setQty(int productId, int qty) {
    if (qty <= 0) {
      cart.remove(productId);
    } else {
      cart[productId] = min(99, qty);
    }
    _saveCart();
  }

  void clearCart() {
    cart.clear();
    _saveCart();
  }

  void _saveCart() {
    _prefs.setString('cart', jsonEncode(cart.map((k, v) => MapEntry('$k', v))));
    notifyListeners();
  }

  // ---------- auth ----------
  Future<void> _setToken(String? t) async {
    api.token = t;
    if (t == null) {
      await _prefs.remove('token');
    } else {
      await _prefs.setString('token', t);
    }
  }

  Future<void> signup(String name, String email, String phone, String password, bool newsletter) async {
    final r = await api.post('/api/auth/signup',
        {'full_name': name, 'email': email, 'phone': phone, 'password': password, 'newsletter': newsletter});
    await _setToken(r['token']);
    customer = Customer.fromJson(r['customer']);
    notifyListeners();
  }

  Future<void> login(String email, String password) async {
    final r = await api.post('/api/auth/login', {'email': email, 'password': password});
    await _setToken(r['token']);
    customer = Customer.fromJson(r['customer']);
    notifyListeners();
  }

  Future<void> logout() async {
    await _setToken(null);
    customer = null;
    notifyListeners();
  }

  // ---------- orders ----------
  Future<Map<String, dynamic>> deliveryEstimate(String state) async =>
      Map<String, dynamic>.from(await api.get('/api/delivery-estimate?state=${Uri.encodeQueryComponent(state)}'));

  Future<Order> placeOrder(Map<String, dynamic> details) async {
    final body = {
      ...details,
      'items': cartLines.map((l) => {'product_id': l.key.id, 'quantity': l.value}).toList(),
    };
    final order = Order.fromJson(await api.post('/api/orders', body));
    clearCart();
    return order;
  }

  Future<String> startCardPayment(String orderNumber) async =>
      (await api.post('/api/payments/paystack/$orderNumber', {}))['authorization_url'];

  Future<List<Order>> myOrders() async =>
      ((await api.get('/api/orders/mine')) as List).map((e) => Order.fromJson(e)).toList();

  // ---------- support ----------
  Future<void> subscribe(String email) => api.post('/api/newsletter', {'email': email});

  Future<String> openTicket(Map<String, dynamic> body) async =>
      (await api.post('/api/support/tickets', body))['ticket_number'];

  // ---------- AI customer-care chat ----------
  Future<void> sendChat(String text) async {
    chat.add(ChatMessage('user', text));
    notifyListeners();
    try {
      final history = chat.length > 12 ? chat.sublist(chat.length - 12) : chat;
      final r = await api.post('/api/chat', {'session_id': chatSession, 'messages': history.map((m) => m.toJson()).toList()});
      chat.add(ChatMessage('assistant', r['reply']));
    } on ApiException catch (e) {
      chat.add(ChatMessage('assistant', '${e.message} You can also reach us on WhatsApp: ${info?.whatsappDisplay ?? ''}'));
    }
    notifyListeners();
  }

  // ---------- WhatsApp ----------
  Future<void> openWhatsApp(String text) async {
    final uri = Uri.parse('https://wa.me/${info?.whatsapp}?text=${Uri.encodeComponent(text)}');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }
}
