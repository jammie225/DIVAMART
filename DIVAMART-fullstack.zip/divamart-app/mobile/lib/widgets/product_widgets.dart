import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../api.dart';
import '../main.dart';
import '../models.dart';
import '../screens/product_screen.dart';
import '../state.dart';

const _catIcons = {
  'perfumes': Icons.local_florist,
  'fragrances': Icons.air,
  'cosmetics': Icons.brush,
  'facecreams': Icons.spa,
  'bodyoils': Icons.water_drop,
  'clothing': Icons.checkroom,
  'groceries': Icons.shopping_basket,
  'household': Icons.cleaning_services,
};
IconData categoryIcon(String slug) => _catIcons[slug] ?? Icons.shopping_bag;

/// Product photo, or a category icon if no photo has been uploaded yet.
class ProductImage extends StatelessWidget {
  final Product product;
  final double iconSize;
  const ProductImage({super.key, required this.product, this.iconSize = 56});

  @override
  Widget build(BuildContext context) {
    final placeholder = Container(
      color: kBlush,
      alignment: Alignment.center,
      child: Icon(categoryIcon(product.category), size: iconSize, color: kRed.withAlpha(190)),
    );
    if ((product.imageUrl ?? '').isEmpty) return placeholder;
    return Image.network(imageUrl(product.imageUrl), fit: BoxFit.cover, errorBuilder: (_, __, ___) => placeholder,
        loadingBuilder: (c, child, progress) => progress == null ? child : placeholder);
  }
}

class ProductCard extends StatelessWidget {
  final Product product;
  final int index;
  const ProductCard({super.key, required this.product, this.index = 0});

  @override
  Widget build(BuildContext context) {
    final p = product;
    // Cards slide and fade in one after another.
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 350 + (index % 6) * 70),
      curve: Curves.easeOutCubic,
      builder: (_, v, child) => Opacity(opacity: v, child: Transform.translate(offset: Offset(0, 24 * (1 - v)), child: child)),
      child: Material(
        color: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFFEBDCDD))),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProductScreen(product: p))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(
              child: Stack(fit: StackFit.expand, children: [
                Hero(tag: 'p${p.id}', child: Opacity(opacity: p.inStock ? 1 : .55, child: ProductImage(product: p))),
                if (!p.inStock || p.badge != null)
                  Positioned(left: 10, top: 10, child: _Badge(text: p.inStock ? p.badge! : 'Out of stock', dark: !p.inStock || p.badge == 'New')),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(p.categoryName.toUpperCase(), style: const TextStyle(fontSize: 10, letterSpacing: 1.2, fontWeight: FontWeight.w800, color: kRed2)),
                const SizedBox(height: 3),
                Text(p.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14, height: 1.25)),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 6, 6),
              child: Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(naira(p.price), style: const TextStyle(color: kRed, fontWeight: FontWeight.w800, fontSize: 16)),
                    if (p.oldPrice != null)
                      Text(naira(p.oldPrice!), style: const TextStyle(color: kMuted, fontSize: 11, decoration: TextDecoration.lineThrough)),
                  ]),
                ),
                if (p.inStock) AddButton(product: p),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final String text;
  final bool dark;
  const _Badge({required this.text, this.dark = false});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
        decoration: BoxDecoration(color: dark ? const Color(0xFF1B0A0C) : kRed, borderRadius: BorderRadius.circular(99)),
        child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800)),
      );
}

/// Round "+" button with a little bounce when tapped.
class AddButton extends StatefulWidget {
  final Product product;
  const AddButton({super.key, required this.product});
  @override
  State<AddButton> createState() => _AddButtonState();
}

class _AddButtonState extends State<AddButton> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 380));

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: TweenSequence([
        TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.3), weight: 40),
        TweenSequenceItem(tween: Tween(begin: 1.3, end: 1.0), weight: 60),
      ]).animate(CurvedAnimation(parent: _c, curve: Curves.easeOut)),
      child: IconButton.filled(
        style: IconButton.styleFrom(backgroundColor: kRed, foregroundColor: Colors.white),
        icon: const Icon(Icons.add_shopping_cart, size: 20),
        tooltip: 'Add to cart',
        onPressed: () {
          context.read<ShopState>().addToCart(widget.product);
          _c.forward(from: 0);
          ScaffoldMessenger.of(context)
            ..hideCurrentSnackBar()
            ..showSnackBar(SnackBar(content: Text('${widget.product.name} added to cart'), duration: const Duration(seconds: 1), behavior: SnackBarBehavior.floating));
        },
      ),
    );
  }
}
