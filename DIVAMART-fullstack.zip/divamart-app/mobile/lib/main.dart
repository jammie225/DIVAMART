import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'screens/account_screen.dart';
import 'screens/cart_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/home_screen.dart';
import 'screens/orders_screen.dart';
import 'state.dart';

const kRed = Color(0xFF7A0C14);
const kRed2 = Color(0xFF9E1622);
const kWine = Color(0xFF3D0509);
const kGold = Color(0xFFD9A55B);
const kBlush = Color(0xFFF6E7E8);
const kCream = Color(0xFFFBF6F4);
const kMuted = Color(0xFF7B6466);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  final shop = ShopState();
  runApp(ChangeNotifierProvider.value(value: shop, child: const DivamartApp()));
  shop.init();
}

class DivamartApp extends StatelessWidget {
  const DivamartApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(seedColor: kRed, primary: kRed, secondary: kGold, surface: Colors.white);
    return MaterialApp(
      title: 'DIVAMART',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: scheme,
        useMaterial3: true,
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: kRed, elevation: 0, centerTitle: false),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: kRed,
            foregroundColor: Colors.white,
            minimumSize: const Size.fromHeight(50),
            shape: const StadiumBorder(),
            textStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFEBDCDD))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFEBDCDD))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: kRed2, width: 1.6)),
        ),
        pageTransitionsTheme: const PageTransitionsTheme(builders: {
          TargetPlatform.android: ZoomPageTransitionsBuilder(),
          TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
        }),
      ),
      home: const RootScreen(),
    );
  }
}

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});
  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    final count = context.select<ShopState, int>((s) => s.cartCount);
    final pages = [
      HomeScreen(onOpenCart: () => setState(() => tab = 1)),
      const CartScreen(),
      const OrdersScreen(),
      const AccountScreen(),
    ];
    return Scaffold(
      body: AnimatedSwitcher(duration: const Duration(milliseconds: 300), child: KeyedSubtree(key: ValueKey(tab), child: pages[tab])),
      floatingActionButton: FloatingActionButton(
        backgroundColor: kRed,
        foregroundColor: Colors.white,
        tooltip: 'Customer care',
        onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ChatScreen())),
        child: const Icon(Icons.chat_bubble_outline),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        indicatorColor: kBlush,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: [
          const NavigationDestination(icon: Icon(Icons.storefront_outlined), selectedIcon: Icon(Icons.storefront, color: kRed), label: 'Shop'),
          NavigationDestination(
            icon: Badge(isLabelVisible: count > 0, label: Text('$count'), backgroundColor: kRed, child: const Icon(Icons.shopping_cart_outlined)),
            selectedIcon: Badge(isLabelVisible: count > 0, label: Text('$count'), backgroundColor: kRed, child: const Icon(Icons.shopping_cart, color: kRed)),
            label: 'Cart',
          ),
          const NavigationDestination(icon: Icon(Icons.local_shipping_outlined), selectedIcon: Icon(Icons.local_shipping, color: kRed), label: 'Orders'),
          const NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person, color: kRed), label: 'Account'),
        ],
      ),
    );
  }
}
