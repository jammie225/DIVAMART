-- DIVAMART starting data (generated from backend/app/seed_data.py)
BEGIN;

INSERT INTO categories (slug, name, subtitle, sort_order) VALUES
  ('perfumes', 'Perfumes', 'Signature scents', 0),
  ('fragrances', 'Fragrances & Mists', 'Body sprays, oud, mists', 1),
  ('cosmetics', 'Cosmetics', 'Makeup & beauty', 2),
  ('facecreams', 'Face Creams', 'Skincare & glow', 3),
  ('bodyoils', 'Body Oils', 'Nourish & shine', 4),
  ('clothing', 'Clothing', 'Men & women', 5),
  ('groceries', 'Groceries', 'Food & pantry', 6),
  ('household', 'Household Needs', 'Clean & care', 7)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO products (category_id, name, description, price, old_price, badge, sort_order)
SELECT c.id, v.name, v.description, v.price, v.old_price, v.badge, v.sort_order FROM (VALUES
  ('perfumes', 'Rouge Noir Eau de Parfum', 'Warm amber, rose and oud. Long-lasting evening scent, 100ml.', 28500, 35000, '-19%', 0),
  ('perfumes', 'Blanc Musk Eau de Parfum', 'Clean white musk and soft vanilla. Everyday luxury, 100ml.', 24000, NULL::int, 'New', 1),
  ('perfumes', 'Gold Oud Intense', 'Rich oud, saffron and leather. For bold occasions, 80ml.', 32000, 40000, '-20%', 2),
  ('perfumes', 'Velvet Bloom for Her', 'Jasmine, peony and pear. Soft and feminine, 100ml.', 21500, NULL::int, NULL::text, 3),
  ('fragrances', 'Oud Body Mist', 'Light oud mist for all-day freshness, 250ml.', 6500, NULL::int, 'Bestseller', 4),
  ('fragrances', 'Vanilla Kiss Body Spray', 'Sweet vanilla and caramel body spray, 200ml.', 4500, 5500, '-18%', 5),
  ('fragrances', 'Fresh Aqua Deodorant Spray', 'Cool marine scent, 48-hour freshness, 150ml.', 3800, NULL::int, NULL::text, 6),
  ('fragrances', 'Rose Attar Oil Perfume', 'Alcohol-free concentrated rose perfume oil, 12ml.', 5000, NULL::int, 'New', 7),
  ('cosmetics', 'Matte Lipstick - Crimson', 'Long-wear matte finish, rich crimson red.', 4200, NULL::int, NULL::text, 8),
  ('cosmetics', 'Velvet Foundation', 'Medium coverage, natural finish. Shades for melanin skin.', 9500, 11000, '-14%', 9),
  ('cosmetics', 'Pressed Powder Compact', 'Oil-control setting powder with mirror.', 5500, NULL::int, NULL::text, 10),
  ('cosmetics', 'Nude Lip Gloss Set', 'Set of 3 glossy nude shades.', 6000, NULL::int, 'New', 11),
  ('facecreams', 'Glow Brightening Day Cream', 'Vitamin C day cream for an even, radiant tone, 50g.', 8500, NULL::int, 'Bestseller', 12),
  ('facecreams', 'Shea Night Repair Cream', 'Rich shea butter night cream, deep moisture, 50g.', 7500, 9000, '-17%', 13),
  ('facecreams', 'Hydrating Face Moisturiser', 'Light daily moisturiser with hyaluronic acid, 75ml.', 6800, NULL::int, NULL::text, 14),
  ('facecreams', 'Clear Skin Toning Cream', 'Gentle toning cream for dark spots, 100g.', 9000, NULL::int, 'New', 15),
  ('bodyoils', 'Pure Coconut Body Oil', 'Cold-pressed coconut oil for soft skin, 250ml.', 4500, NULL::int, NULL::text, 16),
  ('bodyoils', 'Cocoa Butter Glow Oil', 'Cocoa butter and vitamin E body oil, 200ml.', 5800, 6800, '-15%', 17),
  ('bodyoils', 'Gold Shimmer Body Oil', 'Lightweight oil with a subtle gold shimmer, 100ml.', 7200, NULL::int, 'New', 18),
  ('bodyoils', 'Black Seed Hair & Body Oil', 'Black seed and argan oil blend, 150ml.', 6000, NULL::int, NULL::text, 19),
  ('clothing', 'Ankara Flare Dress', 'Vibrant Ankara print, flared midi. Sizes S-XXL.', 18500, 22000, '-16%', 20),
  ('clothing', 'Men''s Senator Kaftan', 'Classic senator style, quality fabric. Sizes M-XXL.', 24000, NULL::int, 'Bestseller', 21),
  ('clothing', 'Classic Cotton Polo', 'Soft breathable cotton polo. Several colours.', 8500, NULL::int, NULL::text, 22),
  ('clothing', 'Evening Satin Gown', 'Elegant satin gown for occasions. Sizes S-XL.', 29500, NULL::int, 'New', 23),
  ('groceries', 'Premium Parboiled Rice 10kg', 'Stone-free long-grain parboiled rice.', 16500, NULL::int, 'Bestseller', 24),
  ('groceries', 'Vegetable Oil 3L', 'Pure vegetable cooking oil.', 7800, 8500, '-8%', 25),
  ('groceries', 'Spaghetti Pack (10 x 500g)', 'Durum wheat spaghetti, carton of 10.', 9200, NULL::int, NULL::text, 26),
  ('groceries', 'Breakfast Bundle', 'Tea, milk powder, sugar and cornflakes bundle.', 12500, NULL::int, 'New', 27),
  ('household', 'Laundry Detergent 2kg', 'Powerful stain removal, fresh scent.', 4800, NULL::int, NULL::text, 28),
  ('household', 'Multi-Surface Cleaner', 'Kills germs on kitchen and bathroom surfaces, 1L.', 2900, 3400, '-15%', 29),
  ('household', 'Air Freshener Spray', 'Long-lasting floral room spray, 300ml.', 2500, NULL::int, 'Bestseller', 30),
  ('household', 'Dishwashing Liquid 1L', 'Grease-cutting lemon dish soap.', 2200, NULL::int, NULL::text, 31)
) AS v(slug, name, description, price, old_price, badge, sort_order)
JOIN categories c ON c.slug = v.slug
WHERE NOT EXISTS (SELECT 1 FROM products);

INSERT INTO store_settings (key, value) VALUES
  ('store_name', 'DIVAMART'),
  ('address', '14/16 Brass Street'),
  ('whatsapp', '2340000000000'),
  ('whatsapp_display', '+234 000 000 0000'),
  ('support_hours', 'Mon - Sat, 8:00am - 8:00pm'),
  ('home_state', 'Abia'),
  ('delivery_fee_home', '0'),
  ('delivery_fee_other', '0'),
  ('deal_line1', 'Fragrance week -'),
  ('deal_line2', 'up to 25% off'),
  ('deal_line3', 'perfumes'),
  ('deal_category', 'perfumes'),
  ('deal_ends', ''),
  ('hero_image', ''),
  ('deal_image', ''),
  ('bank_details', '')
ON CONFLICT (key) DO NOTHING;

COMMIT;
