-- =====================================================================
--  DIVAMART — PostgreSQL schema
--  Built to hold 100,000+ customers: every lookup and list used by the
--  app is backed by an index, and admin lists are paginated.
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS pg_trgm;   -- fast "contains" search on names/emails

-- ---------- Catalogue ----------
CREATE TABLE IF NOT EXISTS categories (
    id          SERIAL PRIMARY KEY,
    slug        TEXT NOT NULL UNIQUE,
    name        TEXT NOT NULL,
    subtitle    TEXT NOT NULL DEFAULT '',
    sort_order  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS products (
    id           SERIAL PRIMARY KEY,
    category_id  INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
    name         TEXT NOT NULL,
    description  TEXT NOT NULL DEFAULT '',
    price        INTEGER NOT NULL CHECK (price >= 0),          -- whole naira
    old_price    INTEGER CHECK (old_price IS NULL OR old_price >= 0),
    badge        TEXT,
    image_url    TEXT,
    in_stock     BOOLEAN NOT NULL DEFAULT TRUE,
    visible      BOOLEAN NOT NULL DEFAULT TRUE,
    sort_order   INTEGER NOT NULL DEFAULT 0,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_products_category ON products (category_id, sort_order);
CREATE INDEX IF NOT EXISTS ix_products_name_trgm ON products USING gin (name gin_trgm_ops);

-- ---------- Customers ----------
CREATE TABLE IF NOT EXISTS customers (
    id             BIGSERIAL PRIMARY KEY,
    email          TEXT NOT NULL UNIQUE,                       -- stored lower-case
    full_name      TEXT NOT NULL,
    phone          TEXT NOT NULL,
    password_hash  TEXT NOT NULL,
    state          TEXT,
    city           TEXT,
    address        TEXT,
    newsletter     BOOLEAN NOT NULL DEFAULT FALSE,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_login_at  TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS ix_customers_created   ON customers (created_at DESC);
CREATE INDEX IF NOT EXISTS ix_customers_phone     ON customers (phone);
CREATE INDEX IF NOT EXISTS ix_customers_state     ON customers (state);
CREATE INDEX IF NOT EXISTS ix_customers_name_trgm ON customers USING gin (full_name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS ix_customers_email_trgm ON customers USING gin (email gin_trgm_ops);
CREATE INDEX IF NOT EXISTS ix_customers_phone_trgm ON customers USING gin (phone gin_trgm_ops);

-- ---------- Admins (owner / staff) ----------
CREATE TABLE IF NOT EXISTS admins (
    id               SERIAL PRIMARY KEY,
    email            TEXT NOT NULL UNIQUE,
    full_name        TEXT NOT NULL,
    role             TEXT NOT NULL DEFAULT 'staff' CHECK (role IN ('owner','staff')),
    password_hash    TEXT NOT NULL,
    disabled         BOOLEAN NOT NULL DEFAULT FALSE,
    failed_attempts  INTEGER NOT NULL DEFAULT 0,
    locked_until     TIMESTAMPTZ,
    last_login_at    TIMESTAMPTZ,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Orders ----------
CREATE TABLE IF NOT EXISTS orders (
    id                 BIGSERIAL PRIMARY KEY,
    order_number       TEXT NOT NULL UNIQUE,
    customer_id        BIGINT REFERENCES customers(id) ON DELETE SET NULL,
    full_name          TEXT NOT NULL,
    phone              TEXT NOT NULL,
    state              TEXT NOT NULL,
    city               TEXT NOT NULL,
    address            TEXT NOT NULL,
    note               TEXT NOT NULL DEFAULT '',
    payment_method     TEXT NOT NULL CHECK (payment_method IN ('pod','transfer','card')),
    payment_status     TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending','paid','failed')),
    payment_reference  TEXT,
    status             TEXT NOT NULL DEFAULT 'received'
                       CHECK (status IN ('received','confirmed','dispatched','delivered','cancelled')),
    subtotal           INTEGER NOT NULL,
    delivery_fee       INTEGER NOT NULL DEFAULT 0,
    total              INTEGER NOT NULL,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_orders_customer ON orders (customer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_orders_status   ON orders (status, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_orders_created  ON orders (created_at DESC);
CREATE INDEX IF NOT EXISTS ix_orders_payref   ON orders (payment_reference);

CREATE TABLE IF NOT EXISTS order_items (
    id            BIGSERIAL PRIMARY KEY,
    order_id      BIGINT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id    INTEGER REFERENCES products(id) ON DELETE SET NULL,
    product_name  TEXT NOT NULL,          -- copied so old orders keep their details
    unit_price    INTEGER NOT NULL,
    quantity      INTEGER NOT NULL CHECK (quantity > 0)
);
CREATE INDEX IF NOT EXISTS ix_order_items_order ON order_items (order_id);

-- ---------- Newsletter, support, chat ----------
CREATE TABLE IF NOT EXISTS subscribers (
    id          SERIAL PRIMARY KEY,
    email       TEXT NOT NULL UNIQUE,
    source      TEXT NOT NULL DEFAULT 'newsletter',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tickets (
    id             BIGSERIAL PRIMARY KEY,
    ticket_number  TEXT NOT NULL UNIQUE,
    customer_id    BIGINT REFERENCES customers(id) ON DELETE SET NULL,
    name           TEXT NOT NULL,
    email          TEXT NOT NULL,
    topic          TEXT NOT NULL,
    order_number   TEXT,
    message        TEXT NOT NULL,
    status         TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','resolved')),
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_tickets_status ON tickets (status, created_at DESC);

CREATE TABLE IF NOT EXISTS chat_logs (
    id           BIGSERIAL PRIMARY KEY,
    session_id   TEXT NOT NULL,
    customer_id  BIGINT REFERENCES customers(id) ON DELETE SET NULL,
    role         TEXT NOT NULL CHECK (role IN ('user','assistant')),
    content      TEXT NOT NULL,
    source       TEXT NOT NULL DEFAULT 'user',   -- user | ai | rules
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_chat_logs_session ON chat_logs (session_id, created_at);

-- ---------- Store settings (editable from the admin dashboard) ----------
CREATE TABLE IF NOT EXISTS store_settings (
    key    TEXT PRIMARY KEY,
    value  TEXT NOT NULL
);
