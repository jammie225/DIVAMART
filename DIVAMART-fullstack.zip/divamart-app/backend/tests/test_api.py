"""End-to-end API tests on a throwaway SQLite database. Run:  pytest -q"""
import io
import os
import tempfile

_tmp = tempfile.mkdtemp()
os.environ["DATABASE_URL"] = f"sqlite:///{_tmp}/test.db"
os.environ["UPLOAD_DIR"] = os.path.join(_tmp, "uploads")
os.environ["JWT_SECRET"] = "test-secret-test-secret-test-secret"
os.environ["ANTHROPIC_API_KEY"] = ""
os.environ["PAYSTACK_SECRET_KEY"] = ""

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from PIL import Image  # noqa: E402

from app.main import app  # noqa: E402


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def auth(token):
    return {"Authorization": f"Bearer {token}"}


def test_catalogue(client):
    cats = client.get("/api/categories").json()
    assert len(cats) == 8
    prods = client.get("/api/products", params={"category": "perfumes"}).json()
    assert prods["total"] == 4
    assert client.get("/api/products", params={"q": "rice"}).json()["total"] == 1


def test_customer_flow(client):
    r = client.post("/api/auth/signup", json={"full_name": "Ada Obi", "email": "Ada@Example.com",
                                              "phone": "08012345678", "password": "secret12", "newsletter": True})
    assert r.status_code == 201, r.text
    token = r.json()["token"]
    assert client.post("/api/auth/signup", json={"full_name": "X", "email": "ada@example.com",
                                                 "phone": "08012345678", "password": "secret12"}).status_code == 422
    assert client.post("/api/auth/login", json={"email": "ada@example.com", "password": "nope"}).status_code == 401
    assert client.post("/api/auth/login", json={"email": "ada@example.com", "password": "secret12"}).status_code == 200

    pid = client.get("/api/products").json()["items"][0]["id"]
    order = {"items": [{"product_id": pid, "quantity": 2}], "full_name": "Ada Obi", "phone": "08012345678",
             "state": "Abia", "city": "Aba", "address": "14 Brass Street", "payment_method": "pod"}
    assert client.post("/api/orders", json=order).status_code == 401
    r = client.post("/api/orders", json=order, headers=auth(token))
    assert r.status_code == 201, r.text
    o = r.json()
    assert o["total"] == o["subtotal"] == 28500 * 2      # price comes from the database
    assert o["delivery_estimate"] == "within 24 hours"
    assert client.get("/api/orders/mine", headers=auth(token)).json()[0]["order_number"] == o["order_number"]
    r = client.post("/api/orders", json={**order, "state": "Lagos", "payment_method": "card"}, headers=auth(token))
    assert r.status_code == 400                            # card disabled without Paystack key


def test_chat_rules_fallback(client):
    r = client.post("/api/chat", json={"session_id": "abc123", "messages": [
        {"role": "user", "content": "How long does delivery take to Lagos?"}]})
    assert r.status_code == 200
    assert r.json()["source"] == "rules" and "3-5 days" in r.json()["reply"]
    r = client.post("/api/chat", json={"session_id": "abc123", "messages": [{"role": "user", "content": "oud"}]})
    assert "Oud" in r.json()["reply"]


def test_newsletter_and_ticket(client):
    assert client.post("/api/newsletter", json={"email": "x@y.com"}).json()["already"] is False
    assert client.post("/api/newsletter", json={"email": "X@y.com"}).json()["already"] is True
    r = client.post("/api/support/tickets", json={"name": "Ada", "email": "a@b.com", "topic": "Delivery",
                                                  "message": "Where is my parcel?"})
    assert r.status_code == 201 and r.json()["ticket_number"].startswith("TKT-")


def test_admin_flow(client):
    assert client.get("/api/admin/setup-status").json()["needs_setup"] is True
    assert client.get("/api/admin/stats").status_code == 401
    r = client.post("/api/admin/setup", json={"full_name": "Owner", "email": "owner@divamart.ng",
                                              "password": "Divamart2026"})
    assert r.status_code == 201
    owner = r.json()["token"]
    assert client.post("/api/admin/setup", json={"full_name": "Xavier", "email": "x@x.com",
                                                 "password": "Another2026"}).status_code == 403
    # customer token can't open admin
    ctoken = client.post("/api/auth/login", json={"email": "ada@example.com", "password": "secret12"}).json()["token"]
    assert client.get("/api/admin/stats", headers=auth(ctoken)).status_code == 401

    s = client.get("/api/admin/stats", headers=auth(owner)).json()
    assert s["customers"] == 1 and s["orders"] == 1

    # products + image upload
    r = client.post("/api/admin/products", headers=auth(owner), json={
        "category": "groceries", "name": "Garri 5kg", "description": "White garri", "price": 5000})
    assert r.status_code == 201
    pid = r.json()["id"]
    buf = io.BytesIO()
    Image.new("RGB", (2400, 1800), (122, 12, 20)).save(buf, "PNG")
    r = client.post(f"/api/admin/products/{pid}/image", headers=auth(owner),
                    files={"file": ("photo.png", buf.getvalue(), "image/png")})
    assert r.status_code == 200, r.text
    url = r.json()["image_url"]
    assert client.get(url).status_code == 200
    assert client.post(f"/api/admin/products/{pid}/image", headers=auth(owner),
                       files={"file": ("x.png", b"not an image", "image/png")}).status_code == 400
    r = client.put(f"/api/admin/products/{pid}", headers=auth(owner), json={
        "category": "groceries", "name": "Garri 5kg", "price": 6000, "old_price": 5000})
    assert r.status_code == 422

    # settings
    r = client.put("/api/admin/settings", headers=auth(owner), json={"whatsapp": "+234 801 234 5678"})
    assert r.json()["whatsapp"] == "2348012345678"
    assert client.get("/api/store").json()["whatsapp"] == "2348012345678"

    # staff + lockout
    r = client.post("/api/admin/staff", headers=auth(owner), json={
        "full_name": "Staff One", "email": "staff@divamart.ng", "password": "Staffpass1"})
    assert r.status_code == 201
    staff = client.post("/api/admin/login", json={"email": "staff@divamart.ng", "password": "Staffpass1"}).json()["token"]
    assert client.put("/api/admin/settings", headers=auth(staff), json={"address": "x"}).status_code == 403
    assert client.get("/api/admin/customers", headers=auth(staff)).json()["total"] == 1
    for _ in range(5):
        client.post("/api/admin/login", json={"email": "staff@divamart.ng", "password": "wrong"})
    assert client.post("/api/admin/login", json={"email": "staff@divamart.ng",
                                                 "password": "Staffpass1"}).status_code == 429

    # order status + csv
    on = client.get("/api/admin/orders", headers=auth(owner)).json()["items"][0]["order_number"]
    assert client.patch(f"/api/admin/orders/{on}", headers=auth(owner),
                        json={"status": "dispatched"}).json()["status"] == "dispatched"
    csv = client.get("/api/admin/customers/export.csv", headers=auth(owner)).text
    assert "ada@example.com" in csv


def test_customer_scale(client):
    """Insert 100,000 customers and check the admin list/search stays quick."""
    import time

    from sqlalchemy import insert

    from app.db import engine
    from app.models import Customer
    rows = [{"email": f"user{i}@test.ng", "full_name": f"Customer {i}", "phone": f"080{i:08d}",
             "password_hash": "x", "state": "Abia" if i % 3 == 0 else "Lagos", "newsletter": False}
            for i in range(100_000)]
    with engine.begin() as conn:
        conn.execute(insert(Customer), rows)
    owner = client.post("/api/admin/login", json={"email": "owner@divamart.ng", "password": "Divamart2026"}).json()["token"]
    t = time.perf_counter()
    r = client.get("/api/admin/customers", headers=auth(owner), params={"page": 1500, "limit": 50})
    assert r.json()["total"] == 100_001 and len(r.json()["items"]) == 50
    r = client.get("/api/admin/customers", headers=auth(owner), params={"q": "user99999@"})
    assert r.json()["total"] == 1
    assert time.perf_counter() - t < 5


def test_chat_uses_ai_when_key_set(client, monkeypatch):
    """With an API key the chatbot calls Claude with real store facts; on failure it falls back to rules."""
    import httpx

    from app.config import settings
    sent = {}

    class Resp:
        def raise_for_status(self):
            pass

        def json(self):
            return {"content": [{"type": "text", "text": "Delivery to Lagos takes 3-5 days."}]}

    def fake_post(url, headers=None, json=None, timeout=None):
        sent.update(url=url, headers=headers, body=json)
        return Resp()

    monkeypatch.setattr(settings, "anthropic_api_key", "test-key")
    monkeypatch.setattr(httpx, "post", fake_post)
    r = client.post("/api/chat", json={"session_id": "ai-test-1", "messages": [
        {"role": "assistant", "content": "Hi! How can I help?"},
        {"role": "user", "content": "How much is the gold oud?"}]})
    assert r.json() == {"reply": "Delivery to Lagos takes 3-5 days.", "source": "ai"}
    assert sent["url"].endswith("/v1/messages") and sent["headers"]["x-api-key"] == "test-key"
    assert sent["body"]["messages"][0]["role"] == "user"          # greeting trimmed so history starts with the user
    assert "Gold Oud Intense" in sent["body"]["system"] and "N32,000" in sent["body"]["system"]

    def broken(*a, **k):
        raise httpx.ConnectError("down")
    monkeypatch.setattr(httpx, "post", broken)
    r = client.post("/api/chat", json={"session_id": "ai-test-1", "messages": [
        {"role": "user", "content": "What payment methods do you accept?"}]})
    assert r.json()["source"] == "rules"
