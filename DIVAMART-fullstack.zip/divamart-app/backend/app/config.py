from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """All settings come from environment variables or backend/.env (see .env.example)."""

    database_url: str = "postgresql+psycopg://divamart:divamart@localhost:5432/divamart"

    # Security
    jwt_secret: str = "CHANGE-ME-to-a-long-random-string"
    customer_token_hours: int = 72
    admin_token_hours: int = 8
    cors_origins: str = "http://localhost:5173"

    # Files
    upload_dir: str = "uploads"
    max_upload_mb: int = 10

    # AI chatbot (customer care only). Leave the key empty to use the built-in rule answers.
    anthropic_api_key: str = ""
    ai_model: str = "claude-haiku-5-5"
    chat_rate_per_minute: int = 20

    # Paystack card payments. Leave empty to disable card payment.
    paystack_secret_key: str = ""
    paystack_callback_url: str = "http://localhost:5173/payment/callback"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def cors_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


settings = Settings()
