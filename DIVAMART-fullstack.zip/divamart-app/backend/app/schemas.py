from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

from .seed_data import NIGERIAN_STATES


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# ---------- auth ----------
class SignupIn(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    phone: str = Field(min_length=10, max_length=20, pattern=r"^\+?[0-9][0-9\s-]{9,}$")
    password: str = Field(min_length=6, max_length=128)
    newsletter: bool = False


class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(max_length=128)


class CustomerOut(ORM):
    id: int
    email: str
    full_name: str
    phone: str
    state: str | None = None
    city: str | None = None
    address: str | None = None
    newsletter: bool
    created_at: datetime


class CustomerUpdate(BaseModel):
    full_name: str | None = Field(default=None, min_length=2, max_length=120)
    phone: str | None = Field(default=None, min_length=10, max_length=20)
    state: str | None = None
    city: str | None = Field(default=None, max_length=80)
    address: str | None = Field(default=None, max_length=300)


class TokenOut(BaseModel):
    token: str
    customer: CustomerOut


# ---------- catalogue ----------
class CategoryOut(ORM):
    id: int
    slug: str
    name: str
    subtitle: str
    sort_order: int


class ProductOut(BaseModel):
    id: int
    category: str
    category_name: str
    name: str
    description: str
    price: int
    old_price: int | None
    badge: str | None
    image_url: str | None
    in_stock: bool
    visible: bool
    sort_order: int


class ProductIn(BaseModel):
    category: str
    name: str = Field(min_length=2, max_length=150)
    description: str = Field(default="", max_length=2000)
    price: int = Field(ge=0, le=100_000_000)
    old_price: int | None = Field(default=None, ge=0)
    badge: str | None = Field(default=None, max_length=30)
    in_stock: bool = True
    visible: bool = True
    sort_order: int = 0


# ---------- orders ----------
class CartLine(BaseModel):
    product_id: int
    quantity: int = Field(ge=1, le=99)


class OrderIn(BaseModel):
    items: list[CartLine] = Field(min_length=1, max_length=50)
    full_name: str = Field(min_length=2, max_length=120)
    phone: str = Field(min_length=10, max_length=20)
    state: str
    city: str = Field(min_length=2, max_length=80)
    address: str = Field(min_length=5, max_length=300)
    note: str = Field(default="", max_length=500)
    payment_method: Literal["pod", "transfer", "card"]

    @field_validator("state")
    @classmethod
    def valid_state(cls, v: str) -> str:
        if v not in NIGERIAN_STATES:
            raise ValueError("Choose a Nigerian state")
        return v


class OrderItemOut(ORM):
    product_id: int | None
    product_name: str
    unit_price: int
    quantity: int


class OrderOut(ORM):
    order_number: str
    full_name: str
    phone: str
    state: str
    city: str
    address: str
    note: str
    payment_method: str
    payment_status: str
    status: str
    subtotal: int
    delivery_fee: int
    total: int
    created_at: datetime
    items: list[OrderItemOut]
    delivery_estimate: str = ""


# ---------- support / newsletter ----------
class TicketIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    topic: str = Field(min_length=2, max_length=60)
    order_number: str | None = Field(default=None, max_length=40)
    message: str = Field(min_length=5, max_length=3000)


class TicketOut(ORM):
    ticket_number: str
    name: str
    email: str
    topic: str
    order_number: str | None
    message: str
    status: str
    created_at: datetime


class SubscribeIn(BaseModel):
    email: EmailStr


# ---------- chat ----------
class ChatMsg(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=1500)


class ChatIn(BaseModel):
    session_id: str = Field(min_length=6, max_length=64)
    messages: list[ChatMsg] = Field(min_length=1, max_length=30)


class ChatOut(BaseModel):
    reply: str
    source: Literal["ai", "rules"]


# ---------- admin ----------
class AdminSetupIn(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class AdminOut(ORM):
    id: int
    email: str
    full_name: str
    role: str
    disabled: bool
    last_login_at: datetime | None
    created_at: datetime


class AdminTokenOut(BaseModel):
    token: str
    admin: AdminOut


class AdminCreateIn(AdminSetupIn):
    role: Literal["owner", "staff"] = "staff"


class AdminPatchIn(BaseModel):
    disabled: bool | None = None
    role: Literal["owner", "staff"] | None = None
    new_password: str | None = Field(default=None, min_length=8, max_length=128)


class PasswordChangeIn(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=128)


class OrderStatusIn(BaseModel):
    status: Literal["received", "confirmed", "dispatched", "delivered", "cancelled"] | None = None
    payment_status: Literal["pending", "paid", "failed"] | None = None


class Page(BaseModel):
    items: list
    total: int
    page: int
    pages: int
