"""Customer-care chatbot — the ONLY part of DIVAMART that uses AI.

How it answers:
1. If ANTHROPIC_API_KEY is set, it asks Claude, giving it the store's real facts
   (delivery rules, address, WhatsApp, matching products with live prices/stock,
   and the signed-in customer's recent orders) so it never has to guess.
2. If there is no key, or the AI service fails, it answers from fixed rules below.
Everything else on the site (prices, orders, payments, delivery) is ordinary code.
"""
import logging
import re

import httpx
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..config import settings
from ..models import Customer, Order, Product
from .store import delivery_estimate

log = logging.getLogger("divamart.assistant")
STOP = {"the", "a", "an", "do", "you", "have", "i", "want", "to", "is", "are", "for", "of", "and", "my",
        "me", "it", "how", "much", "what", "please", "can", "get", "any", "in", "on", "with", "price"}


def _wa_link(store: dict) -> str:
    return f"https://wa.me/{store['whatsapp']}"


def _naira(n: int) -> str:
    return "N" + f"{n:,}"


def _matching_products(db: Session, text: str, limit: int = 8) -> list[Product]:
    words = [w for w in re.findall(r"[a-zA-Z]{3,}", text.lower()) if w not in STOP][:6]
    q = select(Product).where(Product.visible.is_(True))
    if words:
        q = q.where(or_(*[Product.name.ilike(f"%{w}%") | Product.description.ilike(f"%{w}%") for w in words]))
    return list(db.scalars(q.order_by(Product.sort_order).limit(limit)))


def _system_prompt(db: Session, store: dict, last_user: str, customer: Customer | None) -> str:
    products = _matching_products(db, last_user)
    plines = "\n".join(
        f"- {p.name} ({p.category.name}): {_naira(p.price)}"
        + (f", was {_naira(p.old_price)}" if p.old_price else "")
        + ("" if p.in_stock else " — OUT OF STOCK")
        for p in products) or "- (no close matches; suggest browsing the categories or asking on WhatsApp)"
    orders_txt = "Customer is not signed in — for order questions, ask them to sign in and open 'My orders', or share their order number on WhatsApp."
    if customer:
        orders = db.scalars(select(Order).where(Order.customer_id == customer.id)
                            .order_by(Order.created_at.desc()).limit(5)).all()
        orders_txt = f"Signed-in customer: {customer.full_name}.\n" + ("\n".join(
            f"- {o.order_number}: status {o.status}, payment {o.payment_status}, total {_naira(o.total)}, "
            f"to {o.state} (delivery {delivery_estimate(o.state, store)}), placed {o.created_at:%d %b %Y}"
            for o in orders) or "- No orders yet.")
    return f"""You are the friendly customer-care assistant for {store['store_name']}, an online store in Nigeria.
Answer in short, warm, clear sentences (2-4 sentences). Use plain text, no markdown headings.

STORE FACTS (only use these — never invent prices, products, discounts or policies):
- Sells perfumes, fragrances, cosmetics, face creams, body oils, clothing, groceries and household needs.
- Store address: {store['address']}. Support hours: {store['support_hours']}.
- WhatsApp: {store['whatsapp_display']} ({_wa_link(store)}).
- Delivery: nationwide. Within {store['home_state']} State: within 24 hours. Outside {store['home_state']}: 3-5 days.
- Payment: pay on delivery, bank transfer, or card (Paystack).
- Orders can be tracked under "My orders" after signing in.
- Refunds, returns, exchanges and complaints are handled by staff: direct the customer to open a support ticket on the Support section or message WhatsApp. Never promise a refund yourself.

PRODUCTS MATCHING THE CUSTOMER'S QUESTION (live prices and stock):
{plines}

ORDERS:
{orders_txt}

RULES:
- If you don't know something, say so and point to WhatsApp or a support ticket.
- Only discuss {store['store_name']} shopping topics. Politely decline anything else.
- Never ask for card numbers, PINs, OTPs or passwords.
- If the customer asks for a human, give the WhatsApp number."""


def ai_reply(db: Session, store: dict, messages: list[dict], customer: Customer | None) -> str | None:
    if not settings.anthropic_api_key:
        return None
    last_user = next((m["content"] for m in reversed(messages) if m["role"] == "user"), "")
    try:
        r = httpx.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": settings.anthropic_api_key, "anthropic-version": "2023-06-01",
                     "content-type": "application/json"},
            json={"model": settings.ai_model, "max_tokens": 400,
                  "system": _system_prompt(db, store, last_user, customer), "messages": messages},
            timeout=30,
        )
        r.raise_for_status()
        text = "".join(b.get("text", "") for b in r.json().get("content", []) if b.get("type") == "text").strip()
        return text or None
    except (httpx.HTTPError, ValueError, KeyError) as e:
        log.warning("AI chatbot unavailable, using rule answers: %s", e)
        return None


def rule_reply(db: Session, store: dict, text: str, customer: Customer | None) -> str:
    """Fallback answers without AI."""
    t = text.lower()
    has = lambda *ws: any(w in t for w in ws)  # noqa: E731
    if has("human", "agent", "person", "call", "speak", "whatsapp"):
        return f"Of course! Chat with our team on WhatsApp: {store['whatsapp_display']} ({_wa_link(store)})."
    if has("refund", "return", "damaged", "wrong item", "complain", "exchange"):
        return ("Sorry about that! Please open a support ticket in the Support section with your order number, "
                f"or message us on WhatsApp ({store['whatsapp_display']}), and our team will sort it out.")
    if has("track", "my order", "order status", "where is my", "dvm-"):
        if customer:
            o = db.scalars(select(Order).where(Order.customer_id == customer.id)
                           .order_by(Order.created_at.desc()).limit(1)).first()
            if o:
                return (f"Your latest order {o.order_number} is '{o.status}' (payment: {o.payment_status}). "
                        f"Delivery to {o.state} is {delivery_estimate(o.state, store)}. See all orders under My orders.")
        return "Sign in and open 'My orders' (the bag icon) to see your order status, or send your order number on WhatsApp."
    if has("deliver", "shipping", "how long", "days", "arrive", "dispatch"):
        return (f"We deliver nationwide! Within {store['home_state']} State it's within 24 hours; "
                "other states take 3-5 days.")
    if has("pay", "transfer", "card", "paystack", "cash"):
        return "You can pay on delivery, by bank transfer, or by card (Paystack) at checkout."
    if has("address", "located", "location", "where are you", "store", "shop"):
        return f"Our store is at {store['address']}. Support hours: {store['support_hours']}."
    if has("hello", "hi ", "hey", "good morning", "good afternoon", "good evening") or t.strip() in {"hi", "hello"}:
        return f"Hello! Welcome to {store['store_name']}. Ask me about products, delivery, payment or your order."
    products = _matching_products(db, text, 4)
    if products and len(text) > 2:
        lines = "; ".join(f"{p.name} — {_naira(p.price)}{'' if p.in_stock else ' (out of stock)'}" for p in products)
        return f"Here's what I found: {lines}. Tap Add to cart on the shop, or order on WhatsApp."
    return (f"I'm not sure about that one. Our team can help on WhatsApp ({store['whatsapp_display']}), "
            "or you can open a support ticket in the Support section.")
