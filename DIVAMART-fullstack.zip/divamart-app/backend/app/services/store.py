"""Shared store logic: settings, delivery rules, serialisers, seeding."""
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import Category, Order, Product, StoreSetting
from ..schemas import OrderOut, ProductOut
from ..seed_data import CATEGORIES, DEFAULT_SETTINGS, PRODUCTS


def get_settings(db: Session) -> dict[str, str]:
    data = dict(DEFAULT_SETTINGS)
    data.update({s.key: s.value for s in db.scalars(select(StoreSetting))})
    return data


def set_settings(db: Session, values: dict[str, str]) -> dict[str, str]:
    for key, value in values.items():
        if key not in DEFAULT_SETTINGS:
            continue
        row = db.get(StoreSetting, key)
        if row:
            row.value = str(value)
        else:
            db.add(StoreSetting(key=key, value=str(value)))
    db.commit()
    return get_settings(db)


def delivery_estimate(state: str, store: dict[str, str]) -> str:
    return "within 24 hours" if state == store["home_state"] else "in 3-5 days"


def delivery_fee(state: str, store: dict[str, str]) -> int:
    key = "delivery_fee_home" if state == store["home_state"] else "delivery_fee_other"
    try:
        return max(0, int(store.get(key) or 0))
    except ValueError:
        return 0


def product_out(p: Product) -> ProductOut:
    return ProductOut(id=p.id, category=p.category.slug, category_name=p.category.name, name=p.name,
                      description=p.description, price=p.price, old_price=p.old_price, badge=p.badge,
                      image_url=p.image_url, in_stock=p.in_stock, visible=p.visible, sort_order=p.sort_order)


def order_out(o: Order, store: dict[str, str]) -> OrderOut:
    out = OrderOut.model_validate(o)
    out.delivery_estimate = delivery_estimate(o.state, store)
    return out


def seed_if_empty(db: Session) -> None:
    """Loads the starting catalogue the first time the app runs (if schema.sql/seed.sql weren't used)."""
    if db.scalar(select(func.count()).select_from(Category)) == 0:
        for i, (slug, name, sub) in enumerate(CATEGORIES):
            db.add(Category(slug=slug, name=name, subtitle=sub, sort_order=i))
        db.flush()
    if db.scalar(select(func.count()).select_from(Product)) == 0:
        cats = {c.slug: c.id for c in db.scalars(select(Category))}
        for i, (slug, name, desc, price, old, badge) in enumerate(PRODUCTS):
            db.add(Product(category_id=cats[slug], name=name, description=desc, price=price,
                           old_price=old, badge=badge, sort_order=i))
    db.commit()
