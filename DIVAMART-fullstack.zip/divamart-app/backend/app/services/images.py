"""Image uploads: checked, resized and re-encoded as JPEG so any phone photo works and pages stay fast."""
import io
import os
import uuid

from fastapi import HTTPException, UploadFile
from PIL import Image, ImageOps, UnidentifiedImageError

from ..config import settings

Image.MAX_IMAGE_PIXELS = 40_000_000  # refuse absurdly large images ("decompression bombs")


def save_image(upload: UploadFile, folder: str, max_side: int = 1200) -> str:
    raw = upload.file.read(settings.max_upload_mb * 1024 * 1024 + 1)
    if len(raw) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(413, f"Image is larger than {settings.max_upload_mb} MB")
    try:
        img = Image.open(io.BytesIO(raw))
        img = ImageOps.exif_transpose(img)          # respect phone camera rotation
        img.thumbnail((max_side, max_side))
        if img.mode != "RGB":
            bg = Image.new("RGB", img.size, (255, 255, 255))
            bg.paste(img, mask=img.convert("RGBA").split()[-1])
            img = bg
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError):
        raise HTTPException(400, "Please upload a JPG, PNG or WebP image")
    target = os.path.join(settings.upload_dir, folder)
    os.makedirs(target, exist_ok=True)
    name = f"{uuid.uuid4().hex}.jpg"
    img.save(os.path.join(target, name), "JPEG", quality=85, optimize=True)
    return f"/uploads/{folder}/{name}"


def delete_image(url: str | None) -> None:
    if not url or not url.startswith("/uploads/"):
        return
    path = os.path.normpath(os.path.join(settings.upload_dir, url[len("/uploads/"):]))
    if path.startswith(os.path.normpath(settings.upload_dir)) and os.path.isfile(path):
        os.remove(path)
