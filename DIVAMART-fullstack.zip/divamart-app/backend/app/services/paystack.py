"""Paystack card payments: start a payment, verify it, and check webhook signatures."""
import hashlib
import hmac
import secrets

import httpx

from ..config import settings

API = "https://api.paystack.co"


def enabled() -> bool:
    return bool(settings.paystack_secret_key)


def _headers() -> dict[str, str]:
    return {"Authorization": f"Bearer {settings.paystack_secret_key}"}


def initialize(email: str, amount_naira: int, order_number: str) -> tuple[str, str]:
    """Returns (authorization_url, reference)."""
    reference = f"{order_number}-{secrets.token_hex(3)}"
    r = httpx.post(f"{API}/transaction/initialize", headers=_headers(), timeout=20, json={
        "email": email,
        "amount": amount_naira * 100,           # Paystack uses kobo
        "currency": "NGN",
        "reference": reference,
        "callback_url": settings.paystack_callback_url,
        "metadata": {"order_number": order_number},
    })
    r.raise_for_status()
    data = r.json()["data"]
    return data["authorization_url"], reference


def verify(reference: str) -> dict:
    r = httpx.get(f"{API}/transaction/verify/{reference}", headers=_headers(), timeout=20)
    r.raise_for_status()
    return r.json()["data"]


def valid_signature(body: bytes, signature: str | None) -> bool:
    if not signature or not settings.paystack_secret_key:
        return False
    expected = hmac.new(settings.paystack_secret_key.encode(), body, hashlib.sha512).hexdigest()
    return hmac.compare_digest(expected, signature)
