import secrets
import string
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt

from .config import settings

ALGO = "HS256"


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode()[:72], bcrypt.gensalt(rounds=12)).decode()


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode()[:72], hashed.encode())
    except ValueError:
        return False


def create_token(subject: int, kind: str, hours: int) -> str:
    """kind is 'customer' or 'admin' so a customer token can never open the admin API."""
    now = datetime.now(timezone.utc)
    payload = {"sub": str(subject), "kind": kind, "iat": now, "exp": now + timedelta(hours=hours)}
    return jwt.encode(payload, settings.jwt_secret, algorithm=ALGO)


def decode_token(token: str) -> dict | None:
    try:
        return jwt.decode(token, settings.jwt_secret, algorithms=[ALGO])
    except jwt.PyJWTError:
        return None


def strong_enough(password: str) -> bool:
    return len(password) >= 8 and any(c.isalpha() for c in password) and any(c.isdigit() for c in password)


_ALPHABET = string.ascii_uppercase + string.digits


def make_code(prefix: str) -> str:
    """Human-friendly unique reference such as DVM-7K2Q9XA4."""
    return f"{prefix}-" + "".join(secrets.choice(_ALPHABET) for _ in range(8))
