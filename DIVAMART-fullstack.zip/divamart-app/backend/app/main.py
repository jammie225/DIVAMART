import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from .config import settings
from .db import Base, SessionLocal, engine
from .routers import admin, shop
from .services.store import seed_if_empty

logging.basicConfig(level=logging.INFO)


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(engine)       # no-op when database/schema.sql already created the tables
    with SessionLocal() as db:
        seed_if_empty(db)
    if settings.jwt_secret.startswith("CHANGE-ME"):
        logging.warning("JWT_SECRET is still the default — set a long random value in backend/.env before going live!")
    yield


os.makedirs(os.path.join(settings.upload_dir, "products"), exist_ok=True)
app = FastAPI(title="DIVAMART API", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_list, allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])
app.mount("/uploads", StaticFiles(directory=settings.upload_dir), name="uploads")
app.include_router(shop.router)
app.include_router(admin.router)


@app.get("/api/health")
def health():
    return {"ok": True}
