from fastapi import Depends, Header, HTTPException, status
from sqlalchemy.orm import Session

from .db import get_db
from .models import Admin, Customer
from .security import decode_token


def _bearer(authorization: str | None) -> dict | None:
    if not authorization or not authorization.lower().startswith("bearer "):
        return None
    return decode_token(authorization[7:].strip())


def optional_customer(authorization: str | None = Header(default=None),
                      db: Session = Depends(get_db)) -> Customer | None:
    data = _bearer(authorization)
    if not data or data.get("kind") != "customer":
        return None
    return db.get(Customer, int(data["sub"]))


def current_customer(customer: Customer | None = Depends(optional_customer)) -> Customer:
    if customer is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Please sign in")
    return customer


def current_admin(authorization: str | None = Header(default=None), db: Session = Depends(get_db)) -> Admin:
    data = _bearer(authorization)
    if not data or data.get("kind") != "admin":
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Admin sign-in required")
    admin = db.get(Admin, int(data["sub"]))
    if admin is None or admin.disabled:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Admin account not active")
    return admin


def owner_only(admin: Admin = Depends(current_admin)) -> Admin:
    if admin.role != "owner":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only the store owner can do this")
    return admin
