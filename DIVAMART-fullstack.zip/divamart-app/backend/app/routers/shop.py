"""Public shop API: auth, catalogue, orders, payments, newsletter, support, chatbot."""
import math
import time
from collections import defaultdict, deque
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..deps import current_customer, optional_customer
from ..models import (Category, ChatLog, Customer, Order, OrderItem, Product, Subscriber, Ticket)
from ..schemas import (CategoryOut, ChatIn, ChatOut, CustomerOut, CustomerUpdate, LoginIn, OrderIn, OrderOut,
                       ProductOut, SignupIn, SubscribeIn, TicketIn, TicketOut, TokenOut)
from ..security import create_token, hash_password, make_code, verify_password
from ..seed_data import NIGERIAN_STATES
from ..services import assistant, paystack
from ..services.store import delivery_estimate, delivery_fee, get_settings, order_out, product_out

router = APIRouter(prefix="/api")


# ===================== store info =====================
@router.get("/store")
def store_info(db: Session = Depends(get_db)):
    s = get_settings(db)
    return {**s, "states": NIGERIAN_STATES, "card_payments": paystack.enabled()}


# ===================== customer auth =====================
@router.post("/auth/signup", response_model=TokenOut, status_code=201)
def signup(body: SignupIn, db: Session = Depends(get_db)):
    email = body.email.lower()
    if db.scalar(select(Customer.id).where(Customer.email == email)):
        raise HTTPException(409, "An account with this email already exists. Try logging in.")
    c = Customer(email=email, full_name=body.full_name.strip(), phone=body.phone.strip(),
                 password_hash=hash_password(body.password), newsletter=body.newsletter)
    db.add(c)
    if body.newsletter and not db.scalar(select(Subscriber.id).where(Subscriber.email == email)):
        db.add(Subscriber(email=email, source="signup"))
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "An account with this email already exists.")
    return TokenOut(token=create_token(c.id, "customer", settings.customer_token_hours),
                    customer=CustomerOut.model_validate(c))


@router.post("/auth/login", response_model=TokenOut)
def login(body: LoginIn, db: Session = Depends(get_db)):
    c = db.scalar(select(Customer).where(Customer.email == body.email.lower()))
    if not c or not verify_password(body.password, c.password_hash):
        raise HTTPException(401, "Email or password is incorrect")
    c.last_login_at = datetime.now(timezone.utc)
    db.commit()
    return TokenOut(token=create_token(c.id, "customer", settings.customer_token_hours),
                    customer=CustomerOut.model_validate(c))


@router.get("/auth/me", response_model=CustomerOut)
def me(c: Customer = Depends(current_customer)):
    return c


@router.patch("/auth/me", response_model=CustomerOut)
def update_me(body: CustomerUpdate, c: Customer = Depends(current_customer), db: Session = Depends(get_db)):
    data = body.model_dump(exclude_none=True)
    if "state" in data and data["state"] not in NIGERIAN_STATES:
        raise HTTPException(422, "Choose a Nigerian state")
    for k, v in data.items():
        setattr(c, k, v.strip() if isinstance(v, str) else v)
    db.commit()
    return c


# ===================== catalogue =====================
@router.get("/categories", response_model=list[CategoryOut])
def categories(db: Session = Depends(get_db)):
    return db.scalars(select(Category).order_by(Category.sort_order)).all()


@router.get("/products")
def products(db: Session = Depends(get_db), category: str | None = None, q: str | None = Query(None, max_length=80),
             page: int = Query(1, ge=1), limit: int = Query(60, ge=1, le=200)):
    stmt = select(Product).join(Category).where(Product.visible.is_(True))
    if category:
        stmt = stmt.where(Category.slug == category)
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(or_(Product.name.ilike(like), Product.description.ilike(like), Category.name.ilike(like)))
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.scalars(stmt.order_by(Category.sort_order, Product.sort_order, Product.id)
                      .offset((page - 1) * limit).limit(limit)).all()
    return {"items": [product_out(p) for p in rows], "total": total, "page": page,
            "pages": max(1, math.ceil(total / limit))}


@router.get("/products/{product_id}", response_model=ProductOut)
def product(product_id: int, db: Session = Depends(get_db)):
    p = db.get(Product, product_id)
    if not p or not p.visible:
        raise HTTPException(404, "Product not found")
    return product_out(p)


# ===================== orders =====================
@router.post("/orders", response_model=OrderOut, status_code=201)
def place_order(body: OrderIn, c: Customer = Depends(current_customer), db: Session = Depends(get_db)):
    store = get_settings(db)
    if body.payment_method == "card" and not paystack.enabled():
        raise HTTPException(400, "Card payment isn't available yet. Choose pay on delivery or bank transfer.")
    # Prices always come from the database, never from the browser.
    qty: dict[int, int] = defaultdict(int)
    for line in body.items:
        qty[line.product_id] += line.quantity
    found = {p.id: p for p in db.scalars(select(Product).where(Product.id.in_(qty.keys())))}
    items, subtotal = [], 0
    for pid, q in qty.items():
        p = found.get(pid)
        if not p or not p.visible:
            raise HTTPException(400, "One of the items in your cart is no longer available")
        if not p.in_stock:
            raise HTTPException(400, f"Sorry, {p.name} is out of stock")
        items.append(OrderItem(product_id=p.id, product_name=p.name, unit_price=p.price, quantity=q))
        subtotal += p.price * q
    fee = delivery_fee(body.state, store)
    order = Order(order_number=make_code("DVM"), customer_id=c.id, full_name=body.full_name.strip(),
                  phone=body.phone.strip(), state=body.state, city=body.city.strip(), address=body.address.strip(),
                  note=body.note.strip(), payment_method=body.payment_method, subtotal=subtotal,
                  delivery_fee=fee, total=subtotal + fee, items=items)
    db.add(order)
    # remember the address for next time
    c.state, c.city, c.address = body.state, body.city.strip(), body.address.strip()
    db.commit()
    return order_out(order, store)


@router.get("/orders/mine", response_model=list[OrderOut])
def my_orders(c: Customer = Depends(current_customer), db: Session = Depends(get_db)):
    store = get_settings(db)
    rows = db.scalars(select(Order).where(Order.customer_id == c.id).order_by(Order.created_at.desc()).limit(100))
    return [order_out(o, store) for o in rows]


@router.get("/orders/{order_number}", response_model=OrderOut)
def get_order(order_number: str, c: Customer = Depends(current_customer), db: Session = Depends(get_db)):
    o = db.scalar(select(Order).where(Order.order_number == order_number, Order.customer_id == c.id))
    if not o:
        raise HTTPException(404, "Order not found")
    return order_out(o, get_settings(db))


# ===================== card payments (Paystack) =====================
@router.post("/payments/paystack/{order_number}")
def start_card_payment(order_number: str, c: Customer = Depends(current_customer), db: Session = Depends(get_db)):
    if not paystack.enabled():
        raise HTTPException(400, "Card payment is not set up")
    o = db.scalar(select(Order).where(Order.order_number == order_number, Order.customer_id == c.id))
    if not o:
        raise HTTPException(404, "Order not found")
    if o.payment_status == "paid":
        raise HTTPException(400, "This order is already paid")
    try:
        url, ref = paystack.initialize(c.email, o.total, o.order_number)
    except Exception:
        raise HTTPException(502, "Couldn't reach Paystack. Please try again.")
    o.payment_reference = ref
    db.commit()
    return {"authorization_url": url, "reference": ref}


def _mark_paid(db: Session, reference: str, data: dict) -> Order | None:
    o = db.scalar(select(Order).where(Order.payment_reference == reference))
    if o and data.get("status") == "success" and int(data.get("amount", 0)) == o.total * 100:
        o.payment_status = "paid"
        if o.status == "received":
            o.status = "confirmed"
        db.commit()
    return o


@router.get("/payments/paystack/verify/{reference}")
def verify_card_payment(reference: str, db: Session = Depends(get_db)):
    if not paystack.enabled():
        raise HTTPException(400, "Card payment is not set up")
    try:
        data = paystack.verify(reference)
    except Exception:
        raise HTTPException(502, "Couldn't verify payment right now")
    o = _mark_paid(db, reference, data)
    if not o:
        raise HTTPException(404, "Order not found")
    return {"order_number": o.order_number, "payment_status": o.payment_status}


@router.post("/payments/paystack/webhook", include_in_schema=False)
async def paystack_webhook(request: Request, db: Session = Depends(get_db)):
    body = await request.body()
    if not paystack.valid_signature(body, request.headers.get("x-paystack-signature")):
        raise HTTPException(401, "Bad signature")
    event = await request.json()
    if event.get("event") == "charge.success":
        _mark_paid(db, event["data"]["reference"], event["data"])
    return {"ok": True}


# ===================== newsletter & support =====================
@router.post("/newsletter", status_code=201)
def subscribe(body: SubscribeIn, db: Session = Depends(get_db)):
    email = body.email.lower()
    if db.scalar(select(Subscriber.id).where(Subscriber.email == email)):
        return {"ok": True, "already": True}
    db.add(Subscriber(email=email))
    db.commit()
    return {"ok": True, "already": False}


@router.post("/support/tickets", response_model=TicketOut, status_code=201)
def open_ticket(body: TicketIn, c: Customer | None = Depends(optional_customer), db: Session = Depends(get_db)):
    t = Ticket(ticket_number=make_code("TKT"), customer_id=c.id if c else None, name=body.name.strip(),
               email=body.email.lower(), topic=body.topic, order_number=(body.order_number or "").strip() or None,
               message=body.message.strip())
    db.add(t)
    db.commit()
    return t


# ===================== AI customer-care chatbot =====================
_hits: dict[str, deque] = defaultdict(deque)


def _rate_limited(key: str) -> bool:
    now, q = time.monotonic(), _hits[key]
    while q and now - q[0] > 60:
        q.popleft()
    if len(q) >= settings.chat_rate_per_minute:
        return True
    q.append(now)
    return False


@router.post("/chat", response_model=ChatOut)
def chat(body: ChatIn, request: Request, c: Customer | None = Depends(optional_customer),
         db: Session = Depends(get_db)):
    if _rate_limited(request.client.host if request.client else "x"):
        raise HTTPException(429, "You're sending messages too fast. Please wait a moment.")
    msgs = [m.model_dump() for m in body.messages][-12:]
    while msgs and msgs[0]["role"] != "user":       # the AI API needs the history to start with the customer
        msgs.pop(0)
    if not msgs or msgs[-1]["role"] != "user":
        raise HTTPException(422, "The last message must be from the customer")
    store = get_settings(db)
    reply = assistant.ai_reply(db, store, msgs, c)
    source = "ai"
    if reply is None:
        reply, source = assistant.rule_reply(db, store, msgs[-1]["content"], c), "rules"
    db.add_all([
        ChatLog(session_id=body.session_id, customer_id=c.id if c else None, role="user",
                content=msgs[-1]["content"], source="user"),
        ChatLog(session_id=body.session_id, customer_id=c.id if c else None, role="assistant",
                content=reply, source=source),
    ])
    db.commit()
    return ChatOut(reply=reply, source=source)


@router.get("/delivery-estimate")
def estimate(state: str, db: Session = Depends(get_db)):
    store = get_settings(db)
    if state not in NIGERIAN_STATES:
        raise HTTPException(422, "Unknown state")
    return {"state": state, "estimate": delivery_estimate(state, store), "fee": delivery_fee(state, store)}
