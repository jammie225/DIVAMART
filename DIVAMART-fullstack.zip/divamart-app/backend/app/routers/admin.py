"""Admin API: login, dashboard stats, products & images, customers, orders, tickets,
subscribers, chat logs, store settings and staff accounts."""
import csv
import io
import math
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from fastapi.responses import StreamingResponse
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..deps import current_admin, owner_only
from ..models import (Admin, Category, ChatLog, Customer, Order, Product, Subscriber, Ticket)
from ..schemas import (AdminCreateIn, AdminOut, AdminPatchIn, AdminSetupIn, AdminTokenOut, CustomerOut, LoginIn,
                       OrderStatusIn, PasswordChangeIn, ProductIn, TicketOut)
from ..security import create_token, hash_password, strong_enough, verify_password
from ..seed_data import DEFAULT_SETTINGS
from ..services.images import delete_image, save_image
from ..services.store import get_settings, order_out, product_out, set_settings

router = APIRouter(prefix="/api/admin")
LOCK_AFTER, LOCK_MINUTES = 5, 5


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _aware(dt: datetime | None) -> datetime | None:
    return dt if dt is None or dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _page(db: Session, stmt, page: int, limit: int):
    total = db.scalar(select(func.count()).select_from(stmt.order_by(None).subquery()))
    rows = db.scalars(stmt.offset((page - 1) * limit).limit(limit)).all()
    return rows, total, max(1, math.ceil(total / limit))


def _token(a: Admin) -> AdminTokenOut:
    return AdminTokenOut(token=create_token(a.id, "admin", settings.admin_token_hours),
                         admin=AdminOut.model_validate(a))


# ===================== sign-in =====================
@router.get("/setup-status")
def setup_status(db: Session = Depends(get_db)):
    return {"needs_setup": db.scalar(select(func.count()).select_from(Admin)) == 0}


@router.post("/setup", response_model=AdminTokenOut, status_code=201)
def setup_owner(body: AdminSetupIn, db: Session = Depends(get_db)):
    """Creates the first (owner) account. Works only while no admin exists."""
    if db.scalar(select(func.count()).select_from(Admin)) > 0:
        raise HTTPException(403, "Setup is already complete")
    if not strong_enough(body.password):
        raise HTTPException(422, "Use at least 8 characters with letters and numbers")
    a = Admin(email=body.email.lower(), full_name=body.full_name.strip(), role="owner",
              password_hash=hash_password(body.password), last_login_at=_utcnow())
    db.add(a)
    db.commit()
    return _token(a)


@router.post("/login", response_model=AdminTokenOut)
def admin_login(body: LoginIn, db: Session = Depends(get_db)):
    a = db.scalar(select(Admin).where(Admin.email == body.email.lower()))
    if a and _aware(a.locked_until) and _aware(a.locked_until) > _utcnow():
        mins = math.ceil((_aware(a.locked_until) - _utcnow()).total_seconds() / 60)
        raise HTTPException(429, f"Too many attempts. Try again in {mins} min.")
    if not a or not verify_password(body.password, a.password_hash):
        if a:
            a.failed_attempts += 1
            if a.failed_attempts >= LOCK_AFTER:
                a.locked_until, a.failed_attempts = _utcnow() + timedelta(minutes=LOCK_MINUTES), 0
            db.commit()
        raise HTTPException(401, "Email or password is incorrect")
    if a.disabled:
        raise HTTPException(403, "This admin account has been disabled")
    a.failed_attempts, a.locked_until, a.last_login_at = 0, None, _utcnow()
    db.commit()
    return _token(a)


@router.get("/me", response_model=AdminOut)
def admin_me(a: Admin = Depends(current_admin)):
    return a


@router.post("/me/password")
def change_password(body: PasswordChangeIn, a: Admin = Depends(current_admin), db: Session = Depends(get_db)):
    if not verify_password(body.current_password, a.password_hash):
        raise HTTPException(400, "Current password is incorrect")
    if not strong_enough(body.new_password):
        raise HTTPException(422, "Use at least 8 characters with letters and numbers")
    a.password_hash = hash_password(body.new_password)
    db.commit()
    return {"ok": True}


# ===================== dashboard =====================
@router.get("/stats")
def stats(_: Admin = Depends(current_admin), db: Session = Depends(get_db)):
    week = _utcnow() - timedelta(days=7)
    by_status = dict(db.execute(select(Order.status, func.count()).group_by(Order.status)).all())
    return {
        "customers": db.scalar(select(func.count()).select_from(Customer)),
        "new_customers_7d": db.scalar(select(func.count()).select_from(Customer).where(Customer.created_at >= week)),
        "orders": db.scalar(select(func.count()).select_from(Order)),
        "revenue": db.scalar(select(func.coalesce(func.sum(Order.total), 0)).where(Order.status != "cancelled")),
        "orders_by_status": by_status,
        "open_tickets": db.scalar(select(func.count()).select_from(Ticket).where(Ticket.status == "open")),
        "subscribers": db.scalar(select(func.count()).select_from(Subscriber)),
        "products": db.scalar(select(func.count()).select_from(Product)),
    }


# ===================== products =====================
def _category_id(db: Session, slug: str) -> int:
    cid = db.scalar(select(Category.id).where(Category.slug == slug))
    if not cid:
        raise HTTPException(422, "Unknown category")
    return cid


def _check_prices(body: ProductIn):
    if body.old_price is not None and body.old_price <= body.price:
        raise HTTPException(422, "Old price should be higher than the price (or leave it empty)")


@router.get("/products")
def admin_products(_: Admin = Depends(current_admin), db: Session = Depends(get_db),
                   q: str | None = None, category: str | None = None):
    stmt = select(Product).join(Category)
    if category:
        stmt = stmt.where(Category.slug == category)
    if q:
        stmt = stmt.where(Product.name.ilike(f"%{q}%"))
    rows = db.scalars(stmt.order_by(Category.sort_order, Product.sort_order, Product.id)).all()
    return [product_out(p) for p in rows]


@router.post("/products", status_code=201)
def create_product(body: ProductIn, _: Admin = Depends(current_admin), db: Session = Depends(get_db)):
    _check_prices(body)
    data = body.model_dump(exclude={"category"})
    p = Product(category_id=_category_id(db, body.category), **data)
    db.add(p)
    db.commit()
    db.refresh(p)
    return product_out(p)


@router.put("/products/{pid}")
def update_product(pid: int, body: ProductIn, _: Admin = Depends(current_admin), db: Session = Depends(get_db)):
    p = db.get(Product, pid) or _404("Product")
    _check_prices(body)
    for k, v in body.model_dump(exclude={"category"}).items():
        setattr(p, k, v)
    p.category_id = _category_id(db, body.category)
    db.commit()
    db.refresh(p)
    return product_out(p)


@router.post("/products/{pid}/image")
def upload_product_image(pid: int, file: UploadFile = File(...), _: Admin = Depends(current_admin),
                         db: Session = Depends(get_db)):
    p = db.get(Product, pid) or _404("Product")
    old = p.image_url
    p.image_url = save_image(file, "products")
    db.commit()
    delete_image(old)
    return product_out(p)


@router.delete("/products/{pid}/image")
def remove_product_image(pid: int, _: Admin = Depends(current_admin), db: Session = Depends(get_db)):
    p = db.get(Product, pid) or _404("Product")
    delete_image(p.image_url)
    p.image_url = None
    db.commit()
    return product_out(p)


@router.delete("/products/{pid}", status_code=204)
def delete_product(pid: int, _: Admin = Depends(current_admin), db: Session = Depends(get_db)):
    p = db.get(Product, pid) or _404("Product")
    delete_image(p.image_url)
    db.delete(p)
    db.commit()


def _404(what: str):
    raise HTTPException(404, f"{what} not found")


# ===================== customers (built for 100k+) =====================
def _customer_query(q: str | None, state: str | None):
    stmt = select(Customer)
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(or_(Customer.email.ilike(like), Customer.full_name.ilike(like), Customer.phone.ilike(like)))
    if state:
        stmt = stmt.where(Customer.state == state)
    return stmt


@router.get("/customers")
def list_customers(_: Admin = Depends(current_admin), db: Session = Depends(get_db),
                   q: str | None = Query(None, max_length=80), state: str | None = None,
                   page: int = Query(1, ge=1), limit: int = Query(50, ge=1, le=200)):
    stmt = _customer_query(q, state).order_by(Customer.created_at.desc(), Customer.id.desc())
    rows, total, pages = _page(db, stmt, page, limit)
    ids = [c.id for c in rows]
    agg = dict((cid, (n, s)) for cid, n, s in db.execute(
        select(Order.customer_id, func.count(), func.coalesce(func.sum(Order.total), 0))
        .where(Order.customer_id.in_(ids), Order.status != "cancelled").group_by(Order.customer_id))) if ids else {}
    items = [{**CustomerOut.model_validate(c).model_dump(), "orders": agg.get(c.id, (0, 0))[0],
              "spent": agg.get(c.id, (0, 0))[1]} for c in rows]
    return {"items": items, "total": total, "page": page, "pages": pages}


@router.get("/customers/export.csv")
def export_customers(_: Admin = Depends(current_admin), db: Session = Depends(get_db),
                     q: str | None = None, state: str | None = None):
    stmt = _customer_query(q, state).order_by(Customer.id).execution_options(yield_per=2000)

    def rows():
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["id", "full_name", "email", "phone", "state", "city", "address", "newsletter", "joined"])
        yield buf.getvalue()
        for c in db.scalars(stmt):
            buf.seek(0)
            buf.truncate()
            w.writerow([c.id, c.full_name, c.email, c.phone, c.state or "", c.city or "", c.address or "",
                        "yes" if c.newsletter else "no", c.created_at.date().isoformat()])
            yield buf.getvalue()

    return StreamingResponse(rows(), media_type="text/csv",
                             headers={"Content-Disposition": "attachment; filename=divamart-customers.csv"})


# ===================== orders =====================
@router.get("/orders")
def list_orders(_: Admin = Depends(current_admin), db: Session = Depends(get_db), q: str | None = None,
                status: str | None = None, page: int = Query(1, ge=1), limit: int = Query(30, ge=1, le=100)):
    stmt = select(Order)
    if status:
        stmt = stmt.where(Order.status == status)
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(or_(Order.order_number.ilike(like), Order.full_name.ilike(like), Order.phone.ilike(like)))
    rows, total, pages = _page(db, stmt.order_by(Order.created_at.desc()), page, limit)
    store = get_settings(db)
    items = [{**order_out(o, store).model_dump(), "customer_email": o.customer.email if o.customer else None}
             for o in rows]
    return {"items": items, "total": total, "page": page, "pages": pages}


@router.patch("/orders/{order_number}")
def update_order(order_number: str, body: OrderStatusIn, _: Admin = Depends(current_admin),
                 db: Session = Depends(get_db)):
    o = db.scalar(select(Order).where(Order.order_number == order_number)) or _404("Order")
    if body.status:
        o.status = body.status
    if body.payment_status:
        o.payment_status = body.payment_status
    db.commit()
    return order_out(o, get_settings(db))


# ===================== support, newsletter, chat logs =====================
@router.get("/tickets")
def list_tickets(_: Admin = Depends(current_admin), db: Session = Depends(get_db), status: str | None = None,
                 page: int = Query(1, ge=1), limit: int = Query(30, ge=1, le=100)):
    stmt = select(Ticket)
    if status:
        stmt = stmt.where(Ticket.status == status)
    rows, total, pages = _page(db, stmt.order_by(Ticket.created_at.desc()), page, limit)
    return {"items": [TicketOut.model_validate(t) for t in rows], "total": total, "page": page, "pages": pages}


@router.patch("/tickets/{ticket_number}")
def toggle_ticket(ticket_number: str, _: Admin = Depends(current_admin), db: Session = Depends(get_db)):
    t = db.scalar(select(Ticket).where(Ticket.ticket_number == ticket_number)) or _404("Ticket")
    t.status = "resolved" if t.status == "open" else "open"
    db.commit()
    return TicketOut.model_validate(t)


@router.get("/subscribers")
def list_subscribers(_: Admin = Depends(current_admin), db: Session = Depends(get_db),
                     page: int = Query(1, ge=1), limit: int = Query(50, ge=1, le=200)):
    rows, total, pages = _page(db, select(Subscriber).order_by(Subscriber.created_at.desc()), page, limit)
    return {"items": [{"email": s.email, "source": s.source, "created_at": s.created_at} for s in rows],
            "total": total, "page": page, "pages": pages}


@router.get("/chats")
def recent_chats(_: Admin = Depends(current_admin), db: Session = Depends(get_db), limit: int = Query(100, le=500)):
    rows = db.scalars(select(ChatLog).order_by(ChatLog.created_at.desc()).limit(limit)).all()
    return [{"session_id": r.session_id, "role": r.role, "content": r.content, "source": r.source,
             "created_at": r.created_at} for r in rows]


# ===================== store settings (owner) =====================
@router.put("/settings")
def save_settings(body: dict[str, str], _: Admin = Depends(owner_only), db: Session = Depends(get_db)):
    if "whatsapp" in body:
        digits = "".join(ch for ch in body["whatsapp"] if ch.isdigit())
        if len(digits) < 10:
            raise HTTPException(422, "WhatsApp number needs the country code, e.g. 2348012345678")
        body["whatsapp"] = digits
    clean = {k: v for k, v in body.items() if k in DEFAULT_SETTINGS and k not in ("hero_image", "deal_image")}
    return set_settings(db, clean)


@router.post("/settings/image/{key}")
def upload_setting_image(key: str, file: UploadFile = File(...), _: Admin = Depends(owner_only),
                         db: Session = Depends(get_db)):
    if key not in ("hero_image", "deal_image"):
        raise HTTPException(404, "Unknown image slot")
    old = get_settings(db).get(key)
    url = save_image(file, "site", max_side=1600)
    delete_image(old)
    return set_settings(db, {key: url})


@router.delete("/settings/image/{key}")
def clear_setting_image(key: str, _: Admin = Depends(owner_only), db: Session = Depends(get_db)):
    if key not in ("hero_image", "deal_image"):
        raise HTTPException(404, "Unknown image slot")
    delete_image(get_settings(db).get(key))
    return set_settings(db, {key: ""})


# ===================== staff accounts (owner) =====================
@router.get("/staff", response_model=list[AdminOut])
def list_staff(_: Admin = Depends(owner_only), db: Session = Depends(get_db)):
    return db.scalars(select(Admin).order_by(Admin.created_at)).all()


@router.post("/staff", response_model=AdminOut, status_code=201)
def add_staff(body: AdminCreateIn, _: Admin = Depends(owner_only), db: Session = Depends(get_db)):
    if db.scalar(select(Admin.id).where(Admin.email == body.email.lower())):
        raise HTTPException(409, "That email is already an admin")
    if not strong_enough(body.password):
        raise HTTPException(422, "Use at least 8 characters with letters and numbers")
    a = Admin(email=body.email.lower(), full_name=body.full_name.strip(), role=body.role,
              password_hash=hash_password(body.password))
    db.add(a)
    db.commit()
    return a


@router.patch("/staff/{admin_id}", response_model=AdminOut)
def patch_staff(admin_id: int, body: AdminPatchIn, me: Admin = Depends(owner_only), db: Session = Depends(get_db)):
    a = db.get(Admin, admin_id) or _404("Admin")
    if a.id == me.id and (body.disabled or body.role == "staff"):
        raise HTTPException(400, "You can't disable or demote your own account")
    if body.disabled is not None:
        a.disabled = body.disabled
    if body.role:
        a.role = body.role
    if body.new_password:
        if not strong_enough(body.new_password):
            raise HTTPException(422, "Use at least 8 characters with letters and numbers")
        a.password_hash, a.failed_attempts, a.locked_until = hash_password(body.new_password), 0, None
    db.commit()
    return a
