"""SQLAlchemy models. These mirror database/schema.sql exactly."""
from datetime import datetime, timezone

from sqlalchemy import (BigInteger, Boolean, CheckConstraint, DateTime, ForeignKey, Index,
                        Integer, String, Text, func)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base

BigPK = BigInteger().with_variant(Integer, "sqlite")   # SQLite (tests) needs INTEGER for autoincrement


def now() -> datetime:
    return datetime.now(timezone.utc)


def ts(nullable: bool = False):
    return mapped_column(DateTime(timezone=True), nullable=nullable,
                         **({} if nullable else {"default": now, "server_default": func.now()}))


class Category(Base):
    __tablename__ = "categories"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    slug: Mapped[str] = mapped_column(Text, unique=True)
    name: Mapped[str] = mapped_column(Text)
    subtitle: Mapped[str] = mapped_column(Text, default="")
    sort_order: Mapped[int] = mapped_column(Integer, default=0)


class Product(Base):
    __tablename__ = "products"
    __table_args__ = (Index("ix_products_category", "category_id", "sort_order"),
                      CheckConstraint("price >= 0"))
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    category_id: Mapped[int] = mapped_column(ForeignKey("categories.id", ondelete="RESTRICT"))
    name: Mapped[str] = mapped_column(Text)
    description: Mapped[str] = mapped_column(Text, default="")
    price: Mapped[int] = mapped_column(Integer)
    old_price: Mapped[int | None] = mapped_column(Integer, nullable=True)
    badge: Mapped[str | None] = mapped_column(Text, nullable=True)
    image_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    in_stock: Mapped[bool] = mapped_column(Boolean, default=True)
    visible: Mapped[bool] = mapped_column(Boolean, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = ts()
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, onupdate=now,
                                                 server_default=func.now())
    category: Mapped[Category] = relationship(lazy="joined")


class Customer(Base):
    __tablename__ = "customers"
    __table_args__ = (Index("ix_customers_created", "created_at"), Index("ix_customers_phone", "phone"),
                      Index("ix_customers_state", "state"))
    id: Mapped[int] = mapped_column(BigPK, primary_key=True)
    email: Mapped[str] = mapped_column(Text, unique=True)
    full_name: Mapped[str] = mapped_column(Text)
    phone: Mapped[str] = mapped_column(Text)
    password_hash: Mapped[str] = mapped_column(Text)
    state: Mapped[str | None] = mapped_column(Text, nullable=True)
    city: Mapped[str | None] = mapped_column(Text, nullable=True)
    address: Mapped[str | None] = mapped_column(Text, nullable=True)
    newsletter: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = ts()
    last_login_at: Mapped[datetime | None] = ts(nullable=True)


class Admin(Base):
    __tablename__ = "admins"
    __table_args__ = (CheckConstraint("role IN ('owner','staff')"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(Text, unique=True)
    full_name: Mapped[str] = mapped_column(Text)
    role: Mapped[str] = mapped_column(Text, default="staff")
    password_hash: Mapped[str] = mapped_column(Text)
    disabled: Mapped[bool] = mapped_column(Boolean, default=False)
    failed_attempts: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = ts(nullable=True)
    last_login_at: Mapped[datetime | None] = ts(nullable=True)
    created_at: Mapped[datetime] = ts()


ORDER_STATUSES = ("received", "confirmed", "dispatched", "delivered", "cancelled")
PAYMENT_METHODS = ("pod", "transfer", "card")


class Order(Base):
    __tablename__ = "orders"
    __table_args__ = (
        Index("ix_orders_customer", "customer_id", "created_at"),
        Index("ix_orders_status", "status", "created_at"),
        Index("ix_orders_created", "created_at"),
        Index("ix_orders_payref", "payment_reference"),
        CheckConstraint("payment_method IN ('pod','transfer','card')"),
        CheckConstraint("payment_status IN ('pending','paid','failed')"),
        CheckConstraint("status IN ('received','confirmed','dispatched','delivered','cancelled')"),
    )
    id: Mapped[int] = mapped_column(BigPK, primary_key=True)
    order_number: Mapped[str] = mapped_column(Text, unique=True)
    customer_id: Mapped[int | None] = mapped_column(ForeignKey("customers.id", ondelete="SET NULL"), nullable=True)
    full_name: Mapped[str] = mapped_column(Text)
    phone: Mapped[str] = mapped_column(Text)
    state: Mapped[str] = mapped_column(Text)
    city: Mapped[str] = mapped_column(Text)
    address: Mapped[str] = mapped_column(Text)
    note: Mapped[str] = mapped_column(Text, default="")
    payment_method: Mapped[str] = mapped_column(Text)
    payment_status: Mapped[str] = mapped_column(Text, default="pending")
    payment_reference: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(Text, default="received")
    subtotal: Mapped[int] = mapped_column(Integer)
    delivery_fee: Mapped[int] = mapped_column(Integer, default=0)
    total: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = ts()
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, onupdate=now,
                                                 server_default=func.now())
    items: Mapped[list["OrderItem"]] = relationship(cascade="all, delete-orphan", lazy="selectin")
    customer: Mapped[Customer | None] = relationship(lazy="joined")


class OrderItem(Base):
    __tablename__ = "order_items"
    __table_args__ = (Index("ix_order_items_order", "order_id"), CheckConstraint("quantity > 0"))
    id: Mapped[int] = mapped_column(BigPK, primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"))
    product_id: Mapped[int | None] = mapped_column(ForeignKey("products.id", ondelete="SET NULL"), nullable=True)
    product_name: Mapped[str] = mapped_column(Text)
    unit_price: Mapped[int] = mapped_column(Integer)
    quantity: Mapped[int] = mapped_column(Integer)


class Subscriber(Base):
    __tablename__ = "subscribers"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(Text, unique=True)
    source: Mapped[str] = mapped_column(Text, default="newsletter")
    created_at: Mapped[datetime] = ts()


class Ticket(Base):
    __tablename__ = "tickets"
    __table_args__ = (Index("ix_tickets_status", "status", "created_at"),
                      CheckConstraint("status IN ('open','resolved')"))
    id: Mapped[int] = mapped_column(BigPK, primary_key=True)
    ticket_number: Mapped[str] = mapped_column(Text, unique=True)
    customer_id: Mapped[int | None] = mapped_column(ForeignKey("customers.id", ondelete="SET NULL"), nullable=True)
    name: Mapped[str] = mapped_column(Text)
    email: Mapped[str] = mapped_column(Text)
    topic: Mapped[str] = mapped_column(Text)
    order_number: Mapped[str | None] = mapped_column(Text, nullable=True)
    message: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(Text, default="open")
    created_at: Mapped[datetime] = ts()


class ChatLog(Base):
    __tablename__ = "chat_logs"
    __table_args__ = (Index("ix_chat_logs_session", "session_id", "created_at"),
                      CheckConstraint("role IN ('user','assistant')"))
    id: Mapped[int] = mapped_column(BigPK, primary_key=True)
    session_id: Mapped[str] = mapped_column(Text)
    customer_id: Mapped[int | None] = mapped_column(ForeignKey("customers.id", ondelete="SET NULL"), nullable=True)
    role: Mapped[str] = mapped_column(Text)
    content: Mapped[str] = mapped_column(Text)
    source: Mapped[str] = mapped_column(Text, default="user")
    created_at: Mapped[datetime] = ts()


class StoreSetting(Base):
    __tablename__ = "store_settings"
    key: Mapped[str] = mapped_column(Text, primary_key=True)
    value: Mapped[str] = mapped_column(Text)
