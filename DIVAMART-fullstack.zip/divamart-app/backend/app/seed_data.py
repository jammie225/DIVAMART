"""Starting catalogue and store settings. Edit these, or change everything later
from the admin dashboard. Prices are sample prices in whole naira."""

CATEGORIES = [
    # slug, name, subtitle
    ("perfumes", "Perfumes", "Signature scents"),
    ("fragrances", "Fragrances & Mists", "Body sprays, oud, mists"),
    ("cosmetics", "Cosmetics", "Makeup & beauty"),
    ("facecreams", "Face Creams", "Skincare & glow"),
    ("bodyoils", "Body Oils", "Nourish & shine"),
    ("clothing", "Clothing", "Men & women"),
    ("groceries", "Groceries", "Food & pantry"),
    ("household", "Household Needs", "Clean & care"),
]

PRODUCTS = [
    # category, name, description, price, old_price, badge
    ("perfumes", "Rouge Noir Eau de Parfum", "Warm amber, rose and oud. Long-lasting evening scent, 100ml.", 28500, 35000, "-19%"),
    ("perfumes", "Blanc Musk Eau de Parfum", "Clean white musk and soft vanilla. Everyday luxury, 100ml.", 24000, None, "New"),
    ("perfumes", "Gold Oud Intense", "Rich oud, saffron and leather. For bold occasions, 80ml.", 32000, 40000, "-20%"),
    ("perfumes", "Velvet Bloom for Her", "Jasmine, peony and pear. Soft and feminine, 100ml.", 21500, None, None),
    ("fragrances", "Oud Body Mist", "Light oud mist for all-day freshness, 250ml.", 6500, None, "Bestseller"),
    ("fragrances", "Vanilla Kiss Body Spray", "Sweet vanilla and caramel body spray, 200ml.", 4500, 5500, "-18%"),
    ("fragrances", "Fresh Aqua Deodorant Spray", "Cool marine scent, 48-hour freshness, 150ml.", 3800, None, None),
    ("fragrances", "Rose Attar Oil Perfume", "Alcohol-free concentrated rose perfume oil, 12ml.", 5000, None, "New"),
    ("cosmetics", "Matte Lipstick - Crimson", "Long-wear matte finish, rich crimson red.", 4200, None, None),
    ("cosmetics", "Velvet Foundation", "Medium coverage, natural finish. Shades for melanin skin.", 9500, 11000, "-14%"),
    ("cosmetics", "Pressed Powder Compact", "Oil-control setting powder with mirror.", 5500, None, None),
    ("cosmetics", "Nude Lip Gloss Set", "Set of 3 glossy nude shades.", 6000, None, "New"),
    ("facecreams", "Glow Brightening Day Cream", "Vitamin C day cream for an even, radiant tone, 50g.", 8500, None, "Bestseller"),
    ("facecreams", "Shea Night Repair Cream", "Rich shea butter night cream, deep moisture, 50g.", 7500, 9000, "-17%"),
    ("facecreams", "Hydrating Face Moisturiser", "Light daily moisturiser with hyaluronic acid, 75ml.", 6800, None, None),
    ("facecreams", "Clear Skin Toning Cream", "Gentle toning cream for dark spots, 100g.", 9000, None, "New"),
    ("bodyoils", "Pure Coconut Body Oil", "Cold-pressed coconut oil for soft skin, 250ml.", 4500, None, None),
    ("bodyoils", "Cocoa Butter Glow Oil", "Cocoa butter and vitamin E body oil, 200ml.", 5800, 6800, "-15%"),
    ("bodyoils", "Gold Shimmer Body Oil", "Lightweight oil with a subtle gold shimmer, 100ml.", 7200, None, "New"),
    ("bodyoils", "Black Seed Hair & Body Oil", "Black seed and argan oil blend, 150ml.", 6000, None, None),
    ("clothing", "Ankara Flare Dress", "Vibrant Ankara print, flared midi. Sizes S-XXL.", 18500, 22000, "-16%"),
    ("clothing", "Men's Senator Kaftan", "Classic senator style, quality fabric. Sizes M-XXL.", 24000, None, "Bestseller"),
    ("clothing", "Classic Cotton Polo", "Soft breathable cotton polo. Several colours.", 8500, None, None),
    ("clothing", "Evening Satin Gown", "Elegant satin gown for occasions. Sizes S-XL.", 29500, None, "New"),
    ("groceries", "Premium Parboiled Rice 10kg", "Stone-free long-grain parboiled rice.", 16500, None, "Bestseller"),
    ("groceries", "Vegetable Oil 3L", "Pure vegetable cooking oil.", 7800, 8500, "-8%"),
    ("groceries", "Spaghetti Pack (10 x 500g)", "Durum wheat spaghetti, carton of 10.", 9200, None, None),
    ("groceries", "Breakfast Bundle", "Tea, milk powder, sugar and cornflakes bundle.", 12500, None, "New"),
    ("household", "Laundry Detergent 2kg", "Powerful stain removal, fresh scent.", 4800, None, None),
    ("household", "Multi-Surface Cleaner", "Kills germs on kitchen and bathroom surfaces, 1L.", 2900, 3400, "-15%"),
    ("household", "Air Freshener Spray", "Long-lasting floral room spray, 300ml.", 2500, None, "Bestseller"),
    ("household", "Dishwashing Liquid 1L", "Grease-cutting lemon dish soap.", 2200, None, None),
]

DEFAULT_SETTINGS = {
    "store_name": "DIVAMART",
    "address": "14/16 Brass Street",
    "whatsapp": "2340000000000",           # international format, digits only
    "whatsapp_display": "+234 000 000 0000",
    "support_hours": "Mon - Sat, 8:00am - 8:00pm",
    "home_state": "Abia",
    "delivery_fee_home": "0",              # 0 = "confirmed by our team"
    "delivery_fee_other": "0",
    "deal_line1": "Fragrance week -",
    "deal_line2": "up to 25% off",
    "deal_line3": "perfumes",
    "deal_category": "perfumes",
    "deal_ends": "",
    "hero_image": "",
    "deal_image": "",
    "bank_details": "",                    # shown to customers who choose bank transfer
}

NIGERIAN_STATES = [
    "Abia", "Adamawa", "Akwa Ibom", "Anambra", "Bauchi", "Bayelsa", "Benue", "Borno",
    "Cross River", "Delta", "Ebonyi", "Edo", "Ekiti", "Enugu", "FCT - Abuja", "Gombe",
    "Imo", "Jigawa", "Kaduna", "Kano", "Katsina", "Kebbi", "Kogi", "Kwara", "Lagos",
    "Nasarawa", "Niger", "Ogun", "Ondo", "Osun", "Oyo", "Plateau", "Rivers", "Sokoto",
    "Taraba", "Yobe", "Zamfara",
]
